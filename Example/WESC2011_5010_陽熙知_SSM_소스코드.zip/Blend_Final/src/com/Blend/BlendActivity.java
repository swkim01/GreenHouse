package com.Blend;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

public class BlendActivity extends Activity {

	@Override 
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		final int displayTime = 2000; 
	
		Thread splash = new Thread() {
			int wait = 0;

			@Override
			public void run() {
				try {
					super.run();
					while(wait < displayTime){
						sleep(100);
						wait += 100;
					}
				} catch (Exception e) {
				} finally {
					Intent intent = new Intent(BlendActivity.this,
							PlayActivity.class);
					startActivity(intent);
					finish();
				}
			}
		};
		
		splash.start();
	}
}