package com.Blend;

import java.io.FileDescriptor; 
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.MWMCRFunction.MWMCRInf;
import com.MWMCRFunction.MWMCRPlay;
import com.MWMCRFunction.MWMCRTime;
import com.MWMCRFunction.MWMCRfFunction;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.DeadObjectException;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.RemoteCallbackList;
import android.os.RemoteException;

public class PlayService extends Service {

	private static List<String> songList; // = new ArrayList<String>();
	private int currentPosition;
	public static MediaPlayer mediaPlayer = new MediaPlayer();
	MWMCRTime infoTime = new MWMCRTime();
	public static MWMCRfFunction fFunction = new MWMCRfFunction();
	public static BlendInterface blendInterface;
	public static List<MWMCRInf> infor = new ArrayList<MWMCRInf>();

	final RemoteCallbackList<IRemoteServiceCallback> mCallbacks = new RemoteCallbackList<IRemoteServiceCallback>();

	@Override
	public void onCreate() {
		super.onCreate();
		songList = new ArrayList<String>();

	}

	@Override
	public void onDestroy() {
		mediaPlayer.stop();
		mediaPlayer.release();
		mCallbacks.kill();
		mHandler.removeMessages(REPORT_MSG);
	}

	@Override
	public IBinder onBind(Intent arg0) {

		return mBinder;
	}

	private boolean isMediaPlaying() {
		return mediaPlayer.isPlaying();

	}

	public void setBlendInfo() {
		try {
//			infor = MWMCRPlay.PlayInfo("\\mnt\\sdcard\\xxstart.conf");
			infor = MWMCRPlay.PlayInfo("//mnt//sdcard//xxstart.conf", PlayActivity.songName);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static boolean isBlend = false;
	
	private void playSong(String file) {
		try {
			FileInputStream fis = new FileInputStream(file);
			FileDescriptor fd = fis.getFD();

			mediaPlayer.reset();
			mediaPlayer.setDataSource(fd);
			mediaPlayer.prepare();
			mediaPlayer.start();
			mHandler.sendEmptyMessage(REPORT_MSG);
			
			mediaPlayer
					.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
						@Override
						public void onCompletion(MediaPlayer mp) {
							nextSong();

						}
					});

		} catch (IOException e) {
		}
	}

	private void nextSong() {
		if (++currentPosition >= songList.size()) {
			currentPosition = 0;
		} else {
			playSong(songList.get(currentPosition));
		}

		
		
	}

	private void prevSong() {
		if (mediaPlayer.getCurrentPosition() < 3000 && currentPosition >= 1) {
			playSong(songList.get(--currentPosition));
		} else {
			playSong(songList.get(currentPosition));
		}
	}

	private final BlendInterface.Stub mBinder = new BlendInterface.Stub() {

		public void setBlendFlag(boolean b){
			isBlend = b;
		}
		
		public void registerCallback(IRemoteServiceCallback cb) {
			if (cb != null)
				mCallbacks.register(cb);
		}

		public void unregisterCallback(IRemoteServiceCallback cb) {
			if (cb != null)
				mCallbacks.unregister(cb);
		}

		public boolean isPlaying() {
			return isMediaPlaying();
		}

		public void playFile(int position) throws DeadObjectException {
			try {
				currentPosition = position;
				playSong(songList.get(position));

			} catch (IndexOutOfBoundsException e) {
			}
		}

		public void addSongPlaylist(String song) throws DeadObjectException {
			songList.add(song);
		}

		public void clearPlaylist() throws DeadObjectException {
			mediaPlayer.pause ();
			songList.clear();
		}

		public int skipBack() throws DeadObjectException {
			prevSong();
			return currentPosition;
		}

		public int skipForward() throws DeadObjectException {
			nextSong();
			return currentPosition;
		}

		public void pause() throws DeadObjectException {
			if (mediaPlayer.isPlaying()) {
				mediaPlayer.pause();
			} else {
				mediaPlayer.start();
			}

		}

		public void stop() throws DeadObjectException {
			mediaPlayer.stop();
		}
		

	};

	
	
	
	int mValue = 0;
	private static final int REPORT_MSG = 1;
	private static final int REPORT_MSG_BLEND = 2;
	
	private final Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			switch (msg.what) {

			case REPORT_MSG: {
				final int N = mCallbacks.beginBroadcast();
				for (int i = 0; i < N; i++) {
					try {
						mCallbacks.getBroadcastItem(i).valueChanged(currentPosition);
					} catch (RemoteException e) {
					}
				}
				mCallbacks.finishBroadcast();
				break;
			}			
				
			case REPORT_MSG_BLEND: {
				final int N = mCallbacks.beginBroadcast();
				for (int i = 0; i < N; i++) {
					try {
						mCallbacks.getBroadcastItem(i).blendValueChanged(msg.arg1);
					} catch (RemoteException e) {
					}
				}
				mCallbacks.finishBroadcast();
				break;
			}
			default:
				super.handleMessage(msg);
			}
		}
	};
}
