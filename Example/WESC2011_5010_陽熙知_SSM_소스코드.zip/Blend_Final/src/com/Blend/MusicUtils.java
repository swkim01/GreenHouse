package com.Blend;

class Music {
	private String artist;
	private String title;
	private String album;
	private String albumId;
	private String path;

	public Music(String artist, String title, String album, String albumId,
			String path) {
		this.artist = artist;
		this.title = title;
		this.album = album;

		this.path = path;
		this.albumId = albumId;
	}

	public String getAlbumId() {
		return albumId;
	}

	public String getArtist() {
		return artist;
	}

	public String getTitle() {
		return title;
	}

	public String getAlbum() {
		return album;
	}

	public String getPath() {
		return path;
	}
}
