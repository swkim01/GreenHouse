package com.Blend;

import java.util.ArrayList;
import java.util.List;

import com.MWMCRFunction.MWMCRWR;

import android.app.Activity;
import android.content.ComponentName;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.RemoteException;
import android.provider.MediaStore;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;

class myList {
	public String title;
	public List<Music> musicList = new ArrayList<Music>();

	public myList(String title, List<Music> musicList) {
		this.title = title;
		this.musicList = musicList;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public List<Music> getMusicList() {
		return musicList;
	}

	public void setMusicList(List<Music> musicList) {
		this.musicList.addAll(musicList);
	}

}

public class PlayActivity extends Activity {

	public static BlendInterface blendInterface;
	private boolean isPlayFile;
	private ImageButton playButton;
	private ImageButton backButton;
	private ImageButton nextButton;
	private ImageButton listButton;
	private ImageButton blendButton;
	private ImageButton madebyButton;

	public static Context cont;
	
	private static TextView titleView;
	private static TextView artistView;
	private static CoverFlow coverFlow;

	private static TextView nowTitle;
	private static TextView nowArtist;
	private static TextView nowAlbum;
	private static ImageView nowImage;

	public static final String MEDIA_PATH = Environment
			.getExternalStorageDirectory().getPath();

	private boolean bound = false;

	public static int currentPosition = 0;
	public static int coverPosition = 0;
	public static List<Music> currentList = new ArrayList<Music>();
	public static List<Music> songList = new ArrayList<Music>();
	public static List<myList> playList = new ArrayList<myList>();
	public static List<String> playTitle = new ArrayList<String>();
	public static List<myList> blendList = new ArrayList<myList>();
	public static int listIndex = -1;
	public static MediaPlayer mediaPlayer = new MediaPlayer();
	public static List<String> songName = new ArrayList<String>();
	public static boolean firstEnter = false;

	private boolean extraction = false;

	private class UpdateJob extends AsyncTask<Boolean, Boolean, Boolean> {

		@Override
		protected Boolean doInBackground(Boolean... flag) {

			MWMCRWR mwmcrwr = new MWMCRWR();
			mwmcrwr.mwmcrWrite("//mnt//sdcard//xx.conf", songName, songName
					.size());

			publishProgress(true);

			return true;
		}

		@Override
		protected void onPostExecute(Boolean result) {
			super.onPostExecute(result);
			extraction = false;
		}

		@Override
		protected void onPreExecute() {
			extraction = true;
			super.onPreExecute();
		}

		@Override
		protected void onProgressUpdate(Boolean... values) {

			if (values[0] == true) {
				setBlendButton();
			}
		}

	}

	private void setBlendButton() {
		blendButton.setClickable(true);
		blendButton.setImageResource(R.drawable.button_blend_click);
		Toast toast = Toast.makeText(getBaseContext(), "BLEND FINISH",
				Toast.LENGTH_SHORT);
		toast.show();
	}

	private UpdateJob update;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.mainview);
		cont = this;
		isPlayFile = false;
		initItems();
		
		update = new UpdateJob();

		// Log.e("oncreate", "oncreate");
		if (bound == false) {
			this.startService(new Intent(this, PlayService.class));

		} else {
			try {
				updateSongList();
			} catch (RemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	@Override
	public void onStart() {
		super.onStart();
		if (bound == false) {
			this.bindService(new Intent(this, PlayService.class),
					serviceConnection, Context.BIND_AUTO_CREATE);
		} else {

		}
	}
	
	
	@Override
	protected void onRestart() {
		// TODO Auto-generated method stub
		super.onRestart();
		Log.e("on","restart");
		coverFlow.setAdapter(new ImageAdapter(this));
		setCoverFlow(currentPosition);
		setView(currentPosition);
		setNowView();
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		this.unbindService(serviceConnection);
	}

	@Override
	public void onPause() {
		super.onPause();

	}

	@Override
	public void onBackPressed() {
		Intent intent = new Intent();
		intent.setAction("android.intent.action.MAIN");
		intent.addCategory("android.intent.category.HOME");
		intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		startActivity(intent);
	}

	private void coverflow() {
		coverFlow = (CoverFlow) findViewById(R.id.Coverflow);
		coverFlow.setAdapter(new ImageAdapter(this));

		ImageAdapter coverImageAdapter = new ImageAdapter(this);
		coverFlow.setAdapter(coverImageAdapter);
		coverFlow.setSpacing(-50);
		coverFlow.setAnimationDuration(1000);
		coverFlow.setSelection(0, true);

		coverFlow.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,
					int position, long arg3) {
				// TODO Auto-generated method stub
				coverPosition = position;
				setTitleViews();
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub

			}

		});

		coverFlow.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1,
					int position, long arg3) {
				currentPosition = position;
				if (isPlayFile == false) {
					isPlayFile = true;
				}
				try {
					blendInterface.playFile(currentPosition);
					setNowView();
				} catch (RemoteException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});

	}

	public static void setCurrentPosition(int position) {
		currentPosition = position;
	}

	public static void setCoverFlow(int position) {
		coverFlow.setSelection(position, true);
	}

	public static void setTitleViews() {
		if (!currentList.isEmpty()) {
			titleView.setText(currentList.get(coverPosition).getTitle());
			artistView.setText(currentList.get(coverPosition).getArtist() + " / "
					+ currentList.get(coverPosition).getAlbum());
		} else {
			titleView.setText("음악이 없습니다.");
		}

	}

	public static void setNowView() {
		if (!currentList.isEmpty()) {
			nowTitle.setText(currentList.get(currentPosition).getTitle());
			nowArtist.setText(currentList.get(currentPosition).getArtist());
			nowAlbum.setText(currentList.get(currentPosition).getAlbum());

			Uri uri = ContentUris.withAppendedId(sArtworkUri, Integer
					.parseInt(currentList.get(currentPosition).getAlbumId()));
			nowImage.setImageURI(uri);
		}
	}

	private void initItems() {
		playButton = (ImageButton) findViewById(R.id.ImageButtonPlay);
		backButton = (ImageButton) findViewById(R.id.ImageButtonBack);
		nextButton = (ImageButton) findViewById(R.id.ImageButtonNext);
		listButton = (ImageButton) findViewById(R.id.ImageButtonList);
		blendButton = (ImageButton) findViewById(R.id.ImageButtonBlend);
		madebyButton = (ImageButton) findViewById(R.id.madeby);

		titleView = (TextView) findViewById(R.id.TitleText);
		artistView = (TextView) findViewById(R.id.ArtistText);

		nowAlbum = (TextView) findViewById(R.id.nowAlbum);
		nowArtist = (TextView) findViewById(R.id.nowArtist);
		nowTitle = (TextView) findViewById(R.id.nowTitle);

		nowAlbum.setSelected(true);
		nowArtist.setSelected(true);
		nowTitle.setSelected(true);

		nowImage = (ImageView) findViewById(R.id.albumimg);

		nowImage.setOnClickListener(buttonListener);
		playButton.setOnTouchListener(touchListener);
		backButton.setOnTouchListener(touchListener);
		nextButton.setOnTouchListener(touchListener);
		listButton.setOnClickListener(buttonListener);
		blendButton.setOnClickListener(buttonListener);
		madebyButton.setOnClickListener(buttonListener);
		blendButton.setClickable(false);

	}

	public static void setView(int position) {
		setCurrentPosition(position);
		coverPosition = position;
		setCoverFlow(currentPosition);
		setCoverFlow(position);
		setTitleViews();
	}

	private OnTouchListener touchListener = new OnTouchListener() {

		@Override
		public boolean onTouch(View v, MotionEvent event) {

			switch (v.getId()) {
			case R.id.ImageButtonBack: {
				if (event.getAction() == MotionEvent.ACTION_DOWN) {
					backButton
							.setBackgroundResource(R.drawable.button_back_shd);

				} else if (event.getAction() == MotionEvent.ACTION_UP) {
					backButton.setBackgroundResource(R.drawable.button_back);
					try {
						currentPosition = blendInterface.skipBack();
						setView(currentPosition);
						setNowView();
					} catch (RemoteException e) {
						e.printStackTrace();
					}
				}
				break;
			}
			case R.id.ImageButtonPlay: {
				if (event.getAction() == MotionEvent.ACTION_DOWN) {
					playButton
							.setBackgroundResource(R.drawable.button_play_shd);

				} else if (event.getAction() == MotionEvent.ACTION_UP) {
					playButton.setBackgroundResource(R.drawable.button_play);
					try {
						if (isPlayFile == false) {
							blendInterface.playFile(currentPosition);

						} else {
							blendInterface.pause();

						}
						isPlayFile = true;

					} catch (RemoteException e) {
						e.printStackTrace();
					}

				}
				break;
			}
			case R.id.ImageButtonNext: {
				if (event.getAction() == MotionEvent.ACTION_DOWN) {
					nextButton
							.setBackgroundResource(R.drawable.button_next_shd);

				} else if (event.getAction() == MotionEvent.ACTION_UP) {
					nextButton.setBackgroundResource(R.drawable.button_next);
					try {
						currentPosition = blendInterface.skipForward();
					} catch (RemoteException e) {
						e.printStackTrace();
					}

				}
				break;
			}

			}
			return false;
		}
	};

	private OnClickListener buttonListener = new OnClickListener() {

		@Override
		public void onClick(View v) {
			switch (v.getId()) {

			case R.id.ImageButtonList: {
				if (extraction == true) {
					Toast toast = Toast.makeText(getBaseContext(),
							"블렌딩 중입니다. 잠시만 기다려 주세요^^", Toast.LENGTH_SHORT);
					toast.show();
				} else {
					Intent intent = new Intent(PlayActivity.this,
							PlayList.class);
					startActivity(intent);
				}
				break;
			}
			case R.id.ImageButtonBlend: {
				try {
					blendInterface.stop();
				} catch (RemoteException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				Intent intent = new Intent(PlayActivity.this, Blending.class);
				startActivity(intent);
				break;
			}
			case R.id.albumimg: {
				setCoverFlow(currentPosition);
				break;
			}
			case R.id.madeby: {
				if (extraction == true) {
					Toast toast = Toast.makeText(getBaseContext(),
							"블렌딩 중입니다. 잠시만 기다려 주세요^^", Toast.LENGTH_SHORT);
					toast.show();
				} else {
					Intent intent = new Intent(PlayActivity.this, Madeby.class);
					startActivity(intent);
				}
				break;
			}

			}

		}

	};

	public ServiceConnection serviceConnection = new ServiceConnection() {

		@Override
		public void onServiceConnected(ComponentName name, IBinder service) {
			blendInterface = BlendInterface.Stub.asInterface((IBinder) service);

			bound = true;

			try {
				blendInterface.registerCallback(mCallback);
			} catch (RemoteException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			try {
				updateSongList();
			} catch (RemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		@Override
		public void onServiceDisconnected(ComponentName name) {
			bound = false;
			try {
				blendInterface.unregisterCallback(mCallback);
			} catch (RemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			blendInterface = null;
			if (isFinishing() == false) {
				finish();
			}

		}
	};

	public void updateSongList() throws RemoteException {

		Music music = null;

		songList.clear();

		String[] mCursorCols = new String[] { MediaStore.Audio.Media.ARTIST,
				MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ALBUM,
				MediaStore.Audio.Media.ALBUM_ID, MediaStore.Audio.Media.DATA, };

		Cursor cur = getContentResolver().query(
				MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, mCursorCols, null,
				null, null);

		if (cur.moveToFirst()) {

			String title, artist, album, path, id;

			int titleColumn = cur.getColumnIndex(MediaStore.Audio.Media.TITLE);
			int artistColumn = cur
					.getColumnIndex(MediaStore.Audio.Media.ARTIST);
			int albumColumn = cur.getColumnIndex(MediaStore.Audio.Media.ALBUM);
			int idColumn = cur.getColumnIndex(MediaStore.Audio.Media.ALBUM_ID);
			int pathColumn = cur.getColumnIndex(MediaStore.Audio.Media.DATA);

			do {

				title = cur.getString(titleColumn);
				artist = cur.getString(artistColumn);
				album = cur.getString(albumColumn);
				id = cur.getString(idColumn);
				path = cur.getString(pathColumn);

				music = new Music(artist, title, album, id, path);
				songList.add(music);
				songName.add(title);
				blendInterface.addSongPlaylist(music.getPath());

			} while (cur.moveToNext());
		}

		currentList.clear();
		currentList.addAll(songList);
		
		coverflow();
		setTitleViews();
		setNowView();
	//	FileManager.delete(getApplicationContext(), FileManager.pathPlaylist);
		playTitle = FileManager.load(getApplicationContext(),
				FileManager.pathPlaylist);
		loadPlayList();
		// 블렌드리스트
		

		update.execute(true);
	}

	private void loadPlayList() {
		if (songList.isEmpty()) {
			return;
		}
		List<String> list;
		for (String e : playTitle) {
			List<Music> music = new ArrayList<Music>();
			list = FileManager.load(getApplicationContext(), "/" + e + ".conf");
			for (String l : list) {
				for (int i = 0; i < songList.size(); i++) {
					if (songList.get(i).getTitle().contains(l)) {
						music.add(songList.get(i));
						break;
					}

				}
				

			}
			playList.add(new myList(e, music));
		}

	}

	private static final Uri sArtworkUri = Uri
			.parse("content://media/external/audio/albumart");

	public class ImageAdapter extends BaseAdapter {
		int mGalleryItemBackground;
		private Context mContext;

		private ImageView[] mImages;

		public ImageAdapter(Context c) {
			mContext = c;
			mImages = new ImageView[currentList.size()+1];
			Log.e("playcurrent", Integer.toString(currentList.size()));
		}

		public int getCount() {
			return currentList.size();
		}

		public Object getItem(int position) {
			return position;
		}

		public long getItemId(int position) {
			return position;
		}

		public View getView(final int position, View convertView,
				ViewGroup parent) {

			ImageView imageView = new ImageView(mContext);
			imageView.setImageResource(R.drawable.defaltimage);
			Uri uri = ContentUris.withAppendedId(sArtworkUri, Integer
					.parseInt(currentList.get(position).getAlbumId()));
			imageView.setImageURI(uri);
			imageView.setLayoutParams(new CoverFlow.LayoutParams(250, 250));
			mImages[position] = imageView;
			Log.e("mimage",Integer.toString(currentList.size()));
			return imageView;
		}

		/**
		 * Returns the size (0.0f to 1.0f) of the views depending on the
		 * 'offset' to the center.
		 */
		public float getScale(boolean focused, int offset) {
			return Math.max(0, 1.0f / (float) Math.pow(2, Math.abs(offset)));
		}

	}

	private IRemoteServiceCallback mCallback = new IRemoteServiceCallback.Stub() {
		/**
		 * This is called by the remote service regularly to tell us about new
		 * values. Note that IPC calls are dispatched through a thread pool
		 * running in each process, so the code executing here will NOT be
		 * running in our main thread like most other things -- so, to update
		 * the UI, we need to use a Handler to hop over there.
		 */
		public void valueChanged(int value) {
			mHandler.sendMessage(mHandler.obtainMessage(BUMP_MSG, value, 0));
		}

		public void blendValueChanged(int value) {
			mHandler.sendMessage(mHandler.obtainMessage(BUMP_MSG_BLEND, value,
					0));
		}
	};

	private static final int BUMP_MSG = 1;
	private static final int BUMP_MSG_BLEND = 2;

	private Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case BUMP_MSG:
				//
				coverFlow.setAdapter(new ImageAdapter(cont));
				setCoverFlow(currentPosition);
				setView(msg.arg1);
				setNowView();
				break;
			default:
				super.handleMessage(msg);
			}
		}
	};
}
