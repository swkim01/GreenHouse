package com.Blend;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import android.content.Context;

public class FileManager {
	public static String pathFileName = "/blend.conf";
	public static String pathPlaylist = "/playlist.conf";
	public static String pathBlendlist = "/blendlist.conf";
	
	public static void save(Context context,
			List<Music> Informations, String path) {

		File saveDir = context.getCacheDir();
		if (saveDir.exists() == false) {
			saveDir.mkdirs();
		}

		FileOutputStream out = null;
		String fileName = saveDir.getPath() + path;
		
		File file = new File(fileName);
		if (file.exists()) {
			file.delete();
		}

		try {
			out = new FileOutputStream(file);
			for (Music e : Informations) {
				out.write(e.getTitle().getBytes());
				out.write('\n');
			}

		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (out != null)
					out.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	public static void savePlayList(Context context,
			List<myList> Informations, String path) {

		File saveDir = context.getCacheDir();
		if (saveDir.exists() == false) {
			saveDir.mkdirs();
		}

		FileOutputStream out = null;
		String fileName = saveDir.getPath() + path;
		
		File file = new File(fileName);
		if (file.exists()) {
			file.delete();
		}

		try {
			out = new FileOutputStream(file);
			for (myList e : Informations) {
				out.write(e.getTitle().getBytes());
				out.write('\n');
				FileManager.save(context, e.getMusicList(), "/" + e.getTitle() + ".conf");
				
			}

		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (out != null)
					out.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	public static List<String> load(Context context, String path) {
		File saveDir = context.getCacheDir();
		if (saveDir.exists() == false) {
			saveDir.mkdirs();
		}

		String fileName = saveDir.getPath() + path;

		File file = new File(fileName);
		List<String> Informations = new ArrayList<String>();

		if (file.exists() == false) {
			return Informations;
		}

		FileInputStream in = null;
		BufferedReader dataIn = null;

		try {
			in = new FileInputStream(file);
			dataIn = new BufferedReader(new InputStreamReader(in));
			String line = dataIn.readLine();
			while (line != null) {
				Informations.add(line);
				line = dataIn.readLine();
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (dataIn != null)
					dataIn.close();
				if (in != null)
					in.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		return Informations;
	}
	
	

	public static void delete(Context context, String path) {
		File saveDir = context.getCacheDir();
		if (saveDir.exists() == false) {
			saveDir.mkdirs();
		}

		String fileName = saveDir.getPath() + path;
		File file = new File(fileName);
		if (file.exists()) {
			file.delete();
		}
	}
}
