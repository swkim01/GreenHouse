package com.Blend;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class SecMem extends Activity {
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.secmemweb);
		WebView web = (WebView)findViewById(R.id.webview);
		web.getSettings().setJavaScriptEnabled(true);
		web.loadUrl("http://www.secmem.org");
		web.setWebViewClient(new WebViewClient());
		
	}
}
