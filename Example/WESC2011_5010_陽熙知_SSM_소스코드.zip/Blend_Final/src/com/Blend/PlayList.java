package com.Blend;

import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.List;

//import javax.swing.text.Position;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.CompoundButton.OnCheckedChangeListener;



class Mp3Filter implements FilenameFilter {
	public boolean accept(File dir, String name) {
		return (name.endsWith(".mp3") || name.endsWith(".wma") || name.endsWith (".ogg") || name.endsWith ( "wav" ));
	}
}

public class PlayList extends Activity {
	
	class SongListAdapter extends ArrayAdapter<myList> {

		List<myList> list;

		public SongListAdapter(Context context, int textViewResourceId,
				List<myList> list) {
			super(context, textViewResourceId, list);
			this.list = list;
		}

		@Override
		public View getView(final int position, View convertView, ViewGroup parent) {
			View view = convertView;
			if (view == null) {
				LayoutInflater vi = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				view = vi.inflate(R.layout.listrow, null);
			}

			TextView TitleTextView = (TextView) view.findViewById(R.id.playtext);
			TitleTextView.setTextColor(Color.DKGRAY);
			TitleTextView.setText(list.get(position).getTitle());
			
			CheckBox check = (CheckBox)view.findViewById(R.id.listcheck);
			if (ch) {
				check.setVisibility(View.VISIBLE);
				check.setOnCheckedChangeListener(new OnCheckedChangeListener() {

					@Override
					public void onCheckedChanged(CompoundButton buttonView,
							boolean isChecked) {
						
						if (isChecked) {
							indexList.add(list.get(position));

						} else {
							if(indexList.contains ( list.get(position)))
								indexList.remove(list.get(position));
						}
					}
				});
				
				boolean isChecked = false;
				for( int i=0; i< indexList.size(); i++){
					if(indexList.get(i) == list.get(position)){
						check.setChecked(true);
						isChecked = true;
						break;
					}
				}
				
				if(!isChecked)
					check.setChecked(false);
				
			} else
				check.setVisibility(View.INVISIBLE);

			return view;
		}
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.playlist);
		initItems();		
		setAdapter();
		clickEvent();

	}
	
	@Override
	public void onPause() {
		super.onPause();
		list = PlayActivity.playList;
		songListAdapter = new SongListAdapter(this.getApplicationContext(),
				R.layout.listrow, list);
		listView.setAdapter(songListAdapter);	
	}

	public static boolean viewFlag = false;
	
	@Override
	public void onStart(){
		super.onStart();
		list = PlayActivity.playList;
		songListAdapter = new SongListAdapter(this.getApplicationContext(),
				R.layout.listrow, list);
		listView.setAdapter(songListAdapter);
		
		if(viewFlag == true){
			onBackPressed();
			viewFlag = false;
		}
		
	}
	
	private ListView listView;
	private ArrayAdapter<myList> songListAdapter;
	private ImageButton allsong;
	private ImageButton addlist;
	private ImageButton edit;
	private ImageView delete;
	private List<myList> list;
	private static boolean ch = false;
	private List<myList> indexList = new ArrayList<myList>();
	
	private OnClickListener buttonListener = new OnClickListener() {

		@Override
		public void onClick(View v) {
			switch (v.getId()) {

			case R.id.allSong: {
				PlayActivity.listIndex = -1;
				Intent intent = new Intent(PlayList.this, detailList.class);
				startActivity(intent);
				break;
				}
			case R.id.addlist: {
				PlayActivity.listIndex = -2;
				Intent intent = new Intent(PlayList.this, detailList.class);
				startActivity(intent);
				break;
				}
			case R.id.edit: {
				if(ch == false){
					indexList.clear();
					ch = true;
					setAdapter();
					edit.setBackgroundResource(R.drawable.savel);
					delete.setVisibility(View.VISIBLE);
				
				}
				else
				{
					ch = false;
					setAdapter();
					edit.setBackgroundResource(R.drawable.edit);
					delete.setVisibility(View.INVISIBLE);
					//save list - indexlist에 있는 index를 기준으로  체크된것 삭제후 파일저장
					for(int i=0; i<indexList.size ();i++)
					{
						Log.e("index",indexList.get ( i ).getTitle ());
						list.remove ( indexList.get (i) );
						PlayActivity.playList.remove ( indexList.get(i) );
					}
					setAdapter ();
					FileManager.savePlayList(getApplicationContext(), PlayActivity.playList, FileManager.pathPlaylist);
				}
				break;
				}
			
			}
		}
	};
	
	private void initItems() {
		listView = (ListView) findViewById(R.id.ListView);
		allsong = (ImageButton) findViewById(R.id.allSong);
		allsong.setOnClickListener(buttonListener);
		addlist = (ImageButton) findViewById(R.id.addlist);
		addlist.setOnClickListener(buttonListener);
		edit = (ImageButton)findViewById(R.id.edit);
		edit.setOnClickListener(buttonListener);
		delete = (ImageView)findViewById(R.id.delete);
		delete.setVisibility(View.INVISIBLE);
		ch = false;
			
	} 


	
	private void clickEvent() {
		
		
		
		listView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				PlayActivity.listIndex = position;
				Log.e(Integer.toString(position),Integer.toString(PlayActivity.listIndex));
				Intent intent = new Intent(PlayList.this, detailList.class);
				startActivity(intent);
			}

		});

	}
	
	

	private void setAdapter() {	
		list = PlayActivity.playList;
		songListAdapter = new SongListAdapter(this.getApplicationContext(),
				R.layout.listrow, list);
		listView.setAdapter(songListAdapter);	

	}

}
