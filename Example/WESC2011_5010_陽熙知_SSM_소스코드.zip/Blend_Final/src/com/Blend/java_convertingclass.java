/*
* MATLAB Compiler: 4.8 (R2008a)
* Date: Sun Feb 20 22:37:31 2011
* Arguments: "-B" "macro_default" "-W"
* "java:java_converting,java_convertingclass" "-d"
* "C:\\Users\\KIMDOOHYUN\\Documents\\MATLAB\\java_converting\\src" "-T"
* "link:lib" "-v"
* "class{java_convertingclass:C:\\Users\\KIMDOOHYUN\\Documents\\MATLAB\\wavreadt
* est.m}" 
*/

package com.Blend;

//import java.util.Arrays;
//import java.util.HashSet;
//import java.util.Iterator;
//import java.util.List;
//import java.util.Set;

//import com.mathworks.toolbox.javabuilder.Disposable;
//import com.mathworks.toolbox.javabuilder.MWComponentOptions;
//import com.mathworks.toolbox.javabuilder.MWCtfDirectorySource;
//import com.mathworks.toolbox.javabuilder.MWCtfExtractLocation;
//import com.mathworks.toolbox.javabuilder.MWException;
import com.mathworks.toolbox.javabuilder.internal.MWComponentInstance;
import com.mathworks.toolbox.javabuilder.internal.MWFunctionSignature;
import com.mathworks.toolbox.javabuilder.internal.MWMCR;

/**
 * The <code>java_convertingclass</code class provides a Java interface to the
 * M-functions from the files:
 * <pre>
 * C:\Users\KIMDOOHYUN\Documents\MATLAB\wavreadtest.m
 * </pre>
 * The {@link #dispose} method <b>must</b> be called on a
 * <code>java_convertingclass</code> instance when it is no longer needed to
 * ensure that native resources allocated by this class are properly freed.
 * @version 0.0
 */
public class java_convertingclass extends MWComponentInstance<java_convertingclass>
{
	
protected java_convertingclass (MWMCR arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
/**
   * Tracks all instances of this class to ensure their dispose method is
   * called on shutdown.
   */
//  private static Set<Disposable> sInstances = new HashSet<Disposable>();
  /**
   * Maintains information used in calling the <code>wavreadtest</code>
   * M-function.
   */
  private static final MWFunctionSignature swavreadtestSignature = new MWFunctionSignature(0, false, "wavreadtest", 0, false);
  /**
   * Constructs a new instance of the <code>java_convertingclass</code> class.
   */
//  public java_convertingclass() throws MWException
//  {
//	 
//    super(java_convertingMCRFactory.newInstance());
//	System.out.println ("1");
//    // add this to sInstances
//    synchronized(sInstances) {
//    	 System.out.println ("2");
//      sInstances.add(this);
//    }
//  }
//  private static MWComponentOptions getPathToComponentOptions(String path)
//  {
//	  System.out.println ("3");
//    MWComponentOptions options = new MWComponentOptions(new MWCtfExtractLocation(path), new MWCtfDirectorySource(path));
//    System.out.println ("4");
//    return options;
//    
//  }
//  /**
//   * Constructs a new instance of the <code>java_convertingclass</code> class.
//   * Use this constructor to specify a component directory other than the
//   * default location.
//   * @param pathToComponent Path to component directory.
//   */
//  public java_convertingclass(String pathToComponent) throws MWException
//  {
//    super(java_convertingMCRFactory.newInstance(getPathToComponentOptions(pathToComponent)));
//    System.out.println ("5");
//    // add this to sInstances
//    synchronized(sInstances){
//    	System.out.println ("6");
//      sInstances.add(this);
//    }
//  }
//  /**
//   * Constructs a new instance of the <code>java_convertingclass</code> class.
//   * Use this constructor to specify the options required to instantiate this
//   * component.
//   * The options will be specific to the instance of this component being
//   * created.
//   * @param componentOptions Options specific to the component.
//   */
//  public java_convertingclass(MWComponentOptions componentOptions) throws MWException
//  {
//    super(java_convertingMCRFactory.newInstance(componentOptions));
//    System.out.println ("7");
//    // add this to sInstances
//    synchronized(sInstances){
//    	System.out.println ("8");
//      sInstances.add(this);
//      
//    }
//  }
//  /** Frees native resources associated with this object */
//  public void dispose()
//  {
//    super.dispose();
//    System.out.println ("9");
//    synchronized(sInstances) {
//    	System.out.println ("10");
//      sInstances.remove(this);
//    }
//  }
  /**
   * Invokes the first m-function specified by MCC, with any arguments given on
   * the command line, and prints the result.
   */
  public static void main (String[] args)
  {
    try {
    	String[] tmp = new String[0];
//    	tmp[0] = "";
//    jar_testing00.main(tmp);	
//    	String[] aaa = {"[Ljava.lang.String;@1a758cd"};
//      System.out.println ("main start");
      
//      System.out.println ("MWMCR mcr = java_convertingMCRFactory.newInstance();  ���Խ���");
      MWMCR mcr = java_convertingMCRFactory.newInstance();
//      System.out.println ("MWMCR mcr = java_convertingMCRFactory.newInstance();  ���Գ���");
      
//      System.out.println ("args = " + args);
//      if(args == null) {  args = new String[0]; }
//      System.out.println ("args = " + tmp);
      
//      System.out.println("mcr.runMain( swavreadtestSignature, args);  ���Խ���");
      mcr.runMain( swavreadtestSignature, tmp);
//      System.out.println("mcr.runMain( swavreadtestSignature, args);  ���Գ���");
      //[Ljava.lang.String;@10b30a7
      //[Ljava.lang.String;@1b67f74
      //[Ljava.lang.String;@10b30a7
//      System.out.println ("mcr.dispose();  ���Խ���");
      mcr.dispose();
//      System.out.println ("mcr.dispose();  ���Գ���");
      
    } catch (Throwable t) {
      t.printStackTrace();
    }
  }
  /**
   * Install a shutdown hook to call disposeAllInstances.
   */
//  static
//  {
//    Runtime.getRuntime().addShutdownHook(new Thread() 
//    {
//    	public void run() 
//    	{
//    		java_convertingclass.disposeAllInstances();
//    		System.out.println("end 02");
//    	}
//    });
//  }
  /**
   * Helper for disposeAllInstances.
   */
//  private static java_convertingclass popInstance()
//  {
//	  System.out.println("end 01");
//    java_convertingclass o = null;
////    synchronized(sInstances) {
////    	  System.out.println("12");
////      Iterator i = sInstances.iterator();
////      if (i.hasNext()) {
////    	  System.out.println("13");
////        o = (java_convertingclass) i.next();
////        sInstances.remove(o);
////      }
////    }
//    return o;
//  }
  /**
   * Calls dispose method for each outstanding instance of this class.
   */
//  public static void disposeAllInstances()
//  {
////    if(null == sInstances) {
////    	System.out.println("14");
////      return;
////    }
//    synchronized(sInstances) {
//    	System.out.println("end 00");
////      java_convertingclass o = popInstance();
////      while (o != null) {
////    	  System.out.println("while (o != null) {");
////        o.dispose();
////        o = popInstance();
////      }
//    }
//  }
//  /**
//   * Provides the mlx interface for calling the <code>wavreadtest</code>
//   * M-function. 
//   * @param lhs List in which to return outputs. Number of outputs (nargout) is
//   * determined by allocated size of this List. Outputs are returned as
//   * sub-classes of <code>com.mathworks.toolbox.javabuilder.MWArray</code>.
//   * Each output array should be freed by calling its <code>dispose()</code>
//   * method. 
//   * @param rhs List containing inputs. Number of inputs (nargin) is determined
//   * by the allocated size of this List. Input arguments may be passed as
//   * sub-classes of <code>com.mathworks.toolbox.javabuilder.MWArray</code>, or
//   * as arrays of any supported Java type. Arguments passed as Java types are
//   * converted to MATLAB arrays according to default conversion rules. 
//   * @throws MWException An error has occured during the function call. 
//   */
//  public void wavreadtest(List lhs, List rhs) throws MWException
//  {
//	  System.out.println ("public void wavreadtest(List lhs, List rhs) throws MWException");
//    fMCR.invoke(lhs, rhs, swavreadtestSignature);
//  }
//  /**
//   * Provides the mlx interface for calling the <code>wavreadtest</code>
//   * M-function. 
//   * @param lhs array in which to return outputs. Number of outputs (nargout)
//   * is determined by allocated size of this array. Outputs are returned as
//   * sub-classes of <code>com.mathworks.toolbox.javabuilder.MWArray</code>.
//   * Each output array should be freed by calling its <code>dispose()</code>
//   * method. 
//   * @param rhs array containing inputs. Number of inputs (nargin) is
//   * determined by the allocated size of this array. Input arguments may be
//   * passed as sub-classes of
//   * <code>com.mathworks.toolbox.javabuilder.MWArray</code>, or as arrays of
//   * any supported Java type. Arguments passed as Java types are converted to
//   * MATLAB arrays according to default conversion rules. 
//   * @throws MWException An error has occured during the function call. 
//   */
//  public void wavreadtest(Object[] lhs, Object[] rhs) throws MWException
//  {
//	  System.out.println ("public void wavreadtest(Object[] lhs, Object[] rhs) throws MWException");
//    fMCR.invoke(Arrays.asList(lhs), Arrays.asList(rhs), swavreadtestSignature);
//  }
//  /**
//   * Provides the standard interface for calling the <code>wavreadtest</code>
//   * M-function with 0 input argument. 
//   * <pre>
//   * M-documentation:
//   * % fid = fopen('C:\Users\KIMDOOHYUN\Documents\MATLAB\info_mp3.txt');
//   * </pre>
//   * @param rhs The inputs to the M function.
//   * @throws MWException An error has occured during the function call.
//   */
//  public Object[] wavreadtest(Object... rhs) throws MWException
//  {
//	  System.out.println ("public Object[] wavreadtest(Object... rhs) throws MWException");
//    Object[] lhs = new Object[0];
//    fMCR.invoke(Arrays.asList(lhs), MWMCR.getRhsCompat(rhs, swavreadtestSignature), swavreadtestSignature);
//    return lhs;
//  }
}
