package com.Blend;

import com.mathworks.toolbox.javabuilder.pooling.Poolable;
//import java.util.List;
//import java.rmi.Remote;
//import java.rmi.RemoteException;

/**
 * The <code>java_convertingclass</code class provides a Java interface to the
 * M-functions from the files:
 * <pre>
 * C:\Users\KIMDOOHYUN\Documents\MATLAB\wavreadtest.m
 * </pre>
 * The {@link #dispose} method <b>must</b> be called on a
 * <code>java_convertingclass</code> instance when it is no longer needed to
 * ensure that native resources allocated by this class are properly freed.
 * @version 0.0
 */
//public interface java_convertingclassRemote extends Poolable
//{
  /**
   * Provides the standard interface for calling the <code>wavreadtest</code>
   * M-function with 0 input argument. 
   * <pre>
   * M-documentation:
   * % fid = fopen('C:\Users\KIMDOOHYUN\Documents\MATLAB\info_mp3.txt');
   * </pre>
   * @param rhs The inputs to the M function.
   * @throws MWException An error has occured during the function call.
   */
//  public Object[] wavreadtest(Object... rhs) throws RemoteException;
  
  /** Frees native resources associated with the remote server object */
//  void dispose() throws RemoteException;
//}
