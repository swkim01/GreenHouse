package com.Blend;

import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.MWMCRFunction.MWMCRAnalysisCode;
import com.MWMCRFunction.MWMCRInf;
import com.MWMCRFunction.MWMCRPlay;
import com.MWMCRFunction.MWMCRTime;
import com.MWMCRFunction.MWMCRfFunction;

import android.app.Activity;
import android.content.ComponentName;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.RemoteException;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class Blending extends Activity {
	public static String nowSong;
	public static double startTime;
	public static double loopTime;
	public static double currentTime;
	public static boolean counting = false;
	public static boolean backMain = false;
	public static boolean pauseClick;
	private static final Uri sArtworkUri = Uri
			.parse("content://media/external/audio/albumart");
	public static List<MWMCRInf> blendinfo = new ArrayList<MWMCRInf>();

	// ***************************************************************************************************************************
	// ***************************************************************************************************************************
	public static List<Music> blendListContent = new ArrayList<Music>();
	// ***************************************************************************************************************************
	// ***************************************************************************************************************************

	private BlendInterface blend;
	public static boolean isPause = false;
	private boolean bound;

	public static int staticIndex = 0;

	public static int staticFirstIndex = 0;
	public static int staticSecondIndex = 0;
	// public static double staticStart = 0;
	// public static double staticLoop = 0;
	public static int staticBlendinfoSize = 0;
	public static int firstSongNum = 0;
	public static int secondSongNum = 0;
	public static boolean lastEntering = true;
	public static boolean Ending = false;
	// public static double firstMeasureTime = 0;
	// public static double secondMeasureTime = 0;
	// public static double gap = 0;

	public static boolean indexNext = true;

	public static MediaPlayer firstMediaPlayer = new MediaPlayer();
	public static MediaPlayer secondMediaPlayer = new MediaPlayer();
	public static MWMCRfFunction fFunction = new MWMCRfFunction(); //doooooooooooooooooooooooooooooo

	public static int currentVolumeFirst = 0;
	public static int currentVolumeSecond = 0;

	public static int increaseFirstNumber = 0;
	public static int increaseSecondNumber = 0;
	public static int increaseLastNumber = 0;

	public static boolean firstSongStart = true;
	public static boolean getOutOfHere = false;

	public class PlayJob extends AsyncTask<List<MWMCRInf>, Integer, Boolean> {

		// 11
		public PlayJob () {
		};
		public AudioManager audio = (AudioManager) getSystemService(AUDIO_SERVICE);

		public void playBlendSong(MediaPlayer firstMedia, String songName1,
				double firstStart, double firstLoop, MediaPlayer secondMedia,
				String songName2, double secondStart, double secondLoop,
				boolean indexNext) {

			try {
				if (getOutOfHere == true)
					return;

				// Log.e ( "doo", "playBlendSong(" + songName1 + ", " +
				// songName2 + ")");
				if (indexNext == true) {
					publishProgress(staticFirstIndex++);
					increaseFirstNumber = 0;
					increaseSecondNumber = 0;
					increaseLastNumber = 0;
				}

				backMain = false;
				FileInputStream fis = new FileInputStream(songName1);
				FileDescriptor fd = fis.getFD();
				firstMedia.reset();
				firstMedia.setDataSource(fd);
				firstMedia.prepare();
				firstMedia.seekTo((int) (firstStart));
				firstMedia.start();

				FileInputStream fis2 = new FileInputStream(songName2);
				FileDescriptor fd2 = fis2.getFD();
				secondMedia.reset();
				secondMedia.setDataSource(fd2);
				secondMedia.prepare();

				while (true) {
					if (backMain == true)
						break;

					double currtime = firstMedia.getCurrentPosition();
					nowSong = songName1;
					startTime = firstStart;
					loopTime = firstLoop;
					currentTime = currtime;
					// Log.e("doo", "currentTime : " + currentTime);

					if (pauseClick == true) {
						firstMedia.pause();
						while (true) {
							if (backMain == true)
								break;

							if (pauseClick == false) {
								indexNext = false;
								playBlendSong(firstMedia, nowSong, currentTime,
										loopTime - (currentTime - startTime),
										secondMedia, songName2, secondStart,
										secondLoop, indexNext);
								break;
							}
						}
						break;
					}

					else if (pauseClick == false) {
						// 리블랜딩 후 첫곡은 항상 볼륨 안커짐......
						if (firstSongStart == true) {

						} else if (firstSongStart == false) {
							if (increaseFirstNumber >= 3) {
							} else if (increaseFirstNumber < 3) {
								audio.adjustVolume(1, 0);
								increaseFirstNumber++;
							}
						}

						if (currentTime >= (startTime + loopTime - 2000)) {

							secondMedia.seekTo((int) secondStart);
							secondMedia.start();
							// Log.e("doo", "secondMedia.start()");

							// while............................................................................................
							while (true) {

								if (backMain == true)
									break;

								if (pauseClick == true) {
									firstMedia.pause();
									secondMedia.pause();

									double pauseTimeFirst = firstMedia
											.getCurrentPosition();
									double pauseTimeSecond = secondMedia
											.getCurrentPosition();

									while (true) {
										if (backMain == true)
											break;

										if (pauseClick == false) {
											indexNext = false;
											playBlendSong(
													firstMedia,
													nowSong, /* currentTime */
													pauseTimeFirst,
													loopTime
															- (currentTime - startTime),
													secondMedia, songName2, /* secondStart */
													pauseTimeSecond,
													secondLoop, indexNext);
											break;
										}
									}
									break;
								}

								else if (pauseClick == false) {
									// 다음곡(겹치는 부분끝나고 다음곡으로)으로 넘어가는 부분은 볼륨을 다시
									// 서서히 키워줘야됨
									if (increaseSecondNumber >= 3) {
									}

									else if (increaseSecondNumber < 3) {
										audio.adjustVolume(-1, 0);
										increaseSecondNumber++;
									}
									double currtime2 = firstMedia
											.getCurrentPosition();
									// Log.e("doo", "currentTime2 : " +
									// currtime2);
									if ((firstStart + firstLoop - currtime2) <= 0) {
										// Log.e("doo",
										// "firstStart + firstLoop - currtime2 < 0");
										firstMedia.stop();
										// Log.e("doo", "firstMedia.stop()");
										break;
									}
								}
								fFunction.Thread(500);

							}
							// while
							// ending............................................................................................

							if ((staticSecondIndex < staticBlendinfoSize)
									&& (lastEntering == true)) {
								// double currtime22 =
								// secondMedia.getCurrentPosition(); //
								// 잠시만.....주석처리
								firstSongNum = blendinfo.get(staticSecondIndex)
										.getNum();
								// firstStart = currtime22 + 800;// 잠시만.....주석처리
								firstLoop = blendinfo.get(staticSecondIndex)
										.getLoopTime();

								++staticSecondIndex;
							}

							if ((staticSecondIndex == staticBlendinfoSize)
									&& (lastEntering == true)) { // 마지막 곡 재생할
																	// 경우......
							// Log.e("doo", "last song starting");
								publishProgress(staticFirstIndex);
								secondMedia.seekTo((int) firstStart);
								secondMedia.start();
								while (true) {
									// 마지막곡에서 페이드인 해줘야됨......점점 커지게...
									fFunction.Thread(600);
									if (increaseLastNumber >= 3) {
										// Log.e ( "doo",
										// "increaseLastNumber >= 3");
										// Log.e ( "doo", "break;");
										break;
									} else if (increaseLastNumber < 3) {
										audio.adjustVolume(1, 0);
										increaseLastNumber++;
										// Log.e ( "doo",
										// "increaseLastNumber < 3");
									}
								}
								// Log.e("doo", "마지막곡 볼륨 조절 끝...........");

								// backMain = true; //하면 안돼.......
								// counting = false; //하면 안돼.......
								// pauseClick = true; //하면 안돼.......
								lastEntering = true;
								Ending = false;
								indexNext = false; // 이거 바꿔야 리블랜드 하고 다시 시작하면 소리
													// 두배로 안커짐.....
								// lastEntering = false;
								// Ending = true;
								getOutOfHere = true;

								firstSongStart = true;
								// Log.e("doo", "마지막곡 종료 후 return;");
								return;
								// break;
							} else if (staticSecondIndex < staticBlendinfoSize) {
								// Log.e("doo",
								// "겹치는 구간 끝나고 다음곡으로 전환되는 시점.....");
								secondSongNum = blendinfo
										.get(staticSecondIndex).getNum();
								secondStart = blendinfo.get(staticSecondIndex)
										.getStartTime();
								secondLoop = blendinfo.get(staticSecondIndex)
										.getLoopTime();

								indexNext = true;
								firstSongStart = false;
								playBlendSongTrans(
										firstMediaPlayer,
										PlayActivity.songList.get(firstSongNum), /* firstStart */
										secondMedia.getCurrentPosition() + 1100,
										firstLoop, secondMediaPlayer,
										PlayActivity.songList
												.get(secondSongNum),
										secondStart, secondLoop, indexNext);

								// Log.e("doo",
								// "playBlendSongTrans() 탈출~~~~~~~~~~~~~~");
								// Log.e("doo",
								// "return으로 playBlendSong() 함수 나옴~~~~~~~~~~~~~~");
								// break;
								return;
							}
						}
					}
					// Log.e ( "doo", "가장 큰 while()문 돌고있음.....");
					fFunction.Thread(600);
				}
				// Log.e("doo",
				// "playBlendSong()에서 while문 끝나고 함수끝나는 시점.....----> 곧, playBlendSongTrans()도 끝나게 됨.................................");
			} catch (IOException e) {
			}
		}

		// 22
		public void playBlendSongTrans(MediaPlayer firstMedia,
				Music firstMusic, double firstStart, double firstLoop,
				MediaPlayer secondMedia, Music secondMusic, double secondStart,
				double secondLoop, boolean preplaycondition) {
			// Log.e ("doo", "playBlendSongTrans() 시작........");
			String songName1 = firstMusic.getPath();
			String songName2 = secondMusic.getPath();
			// Log.e ("doo", "playBlendSong()      시작........");
			playBlendSong(firstMedia, songName1, firstStart, firstLoop,
					secondMedia, songName2, secondStart, secondLoop,
					preplaycondition);

			// Log.e("doo",
			// "playBlendSongTrans()도 끝나게 됨......................................");

		}

		// 33
		@Override
		public Boolean doInBackground(List<MWMCRInf>... list) {
			// infolist = list[0];
			blendinfo = list[0];
			// Log.e("doo", "Blend Playlist 시작............");
			// originVolume = audio.getStreamVolume(3);
			firstSongStart = true;
			getOutOfHere = false;

			int i = 0;
			staticFirstIndex = i;
			staticSecondIndex = i + 1;

			// Log.e("doo", "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@" );
			// Log.e("doo", "int i = " + staticFirstIndex + ", blendinfo.get(" +
			// staticFirstIndex + ") = " +
			// blendinfo.get(staticFirstIndex).getNum());
			// Log.e("doo", "int i+1 = " + staticSecondIndex +
			// ", blendinfo.get(" + staticSecondIndex + ") = " +
			// blendinfo.get(staticSecondIndex).getNum());
			// Log.e("doo", "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@" );

			int firstSongNum = blendinfo.get(staticFirstIndex).getNum();
			double firstStart = blendinfo.get(staticFirstIndex).getStartTime();
			double firstLoop = blendinfo.get(staticFirstIndex).getLoopTime();

			int secondSongNum = blendinfo.get(staticSecondIndex).getNum();
			double secondStart = blendinfo.get(staticSecondIndex)
					.getStartTime();
			double secondLoop = blendinfo.get(staticSecondIndex).getLoopTime();

			// Log.e("doo",
			// "__________________________________________________________________________________________________________");
			// Log.e("doo", "first starting Info =>>  song index : " +
			// firstSongNum + ",  starting time : " + firstStart +
			// ",  loop time : " + firstLoop);
			// Log.e("doo", "PlayActivity.songList.get("+ firstSongNum + ") : "
			// + PlayActivity.songList.get(firstSongNum));
			// Log.e("doo", "second starting Info =>>  song index : " +
			// secondSongNum + ",  starting time : " + secondStart +
			// ",  loop time : " + secondLoop);
			// Log.e("doo", "PlayActivity.songList.get("+ secondSongNum + ") : "
			// + PlayActivity.songList.get(secondSongNum));
			// Log.e("doo",
			// "__________________________________________________________________________________________________________");

			staticBlendinfoSize = blendinfo.size();

			indexNext = true;
			playBlendSongTrans(firstMediaPlayer, PlayActivity.songList
					.get(firstSongNum), firstStart, firstLoop,
					secondMediaPlayer,
					PlayActivity.songList.get(secondSongNum), secondStart,
					secondLoop, indexNext);

			// Log.e("doo", "Blend Playlist 모두 종료..........");

			firstSongStart = true;
			lastEntering = true;
			Ending = false;

			return true;
		}

		@Override
		protected void onPostExecute(Boolean result) {
			super.onPostExecute(result);
		}

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
		}

		@Override
		protected void onProgressUpdate(Integer... values) {
			// setView(infolist.get(values[0]).getNum()); //원래 있던거
			// setImages(infolist, values[0]); //원래 있던거
			setView(blendinfo.get(values[0]).getNum());
			setImages(blendinfo, values[0]);
		}

	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.blendview);

		playJob = new PlayJob();

		initView();
		initBlendList();
		if (bound == false) {
			this.startService(new Intent(this, PlayService.class));

		}
	}

	public void initBlendList() {

		MWMCRAnalysisCode analysis = new MWMCRAnalysisCode();
		analysis.mwmcrAnalysisCode("//mnt//sdcard//xxcode.conf",
				PlayActivity.songName, PlayActivity.songName.size());

		MWMCRAnalysisCode analysis2 = new MWMCRAnalysisCode();
		analysis2.mwmcrStartTime("//mnt//sdcard//xxstart.conf",
				PlayActivity.songName, PlayActivity.songName.size(), 5);

		try {
			// blendinfo = MWMCRPlay.PlayInfo("//mnt//sdcard//xxstart.ini");
			// //pre Version...
			blendinfo = MWMCRPlay.PlayInfo("//mnt//sdcard//xxstart.conf",
					PlayActivity.songName);
		} catch (IOException e) {
			e.printStackTrace();
		}
		setView(blendinfo.get(0).getNum());
		setImages(blendinfo, 0);
	}

	private OnClickListener clicklistener = new OnClickListener() {

		@Override
		public void onClick(View v) {
			switch (v.getId()) {
			case R.id.returnbtn: {

				getOutOfHere = true;
				backMain = true;
				counting = false;
				pauseClick = true;
				lastEntering = true;
				Ending = false;
				indexNext = false; // 이거 바꿔야 리블랜드 하고 다시 시작하면 소리 두배로 안커짐.....

				//				
				// Log.e("doo", "re blending");
				if (firstMediaPlayer.isPlaying() == true
						|| secondMediaPlayer.isPlaying() == true) {
					firstMediaPlayer.stop();
					secondMediaPlayer.stop();
				}
				isPlay = false;

				playJob.cancel(true);
				//
				// if (playJob.getStatus() == AsyncTask.Status.RUNNING) {
				// playJob.cancel(true);
				// }
				// DialogProgress(); //원래 있던거
				playJob = new PlayJob();
				initView();
				initBlendList();
				break;
			}

			case R.id.bmadeby: {
				Intent i = new Intent(Blending.this, Madeby.class);
				startActivity(i);
				break;
			}
			case R.id.saveb: {
				//

				// *************************************************************************************************
				// *************************************************************************************************
				try {
					String defaultPath = "//mnt//sdcard//";
					Calendar cal = Calendar.getInstance();
					int year = cal.get(cal.YEAR);
					int month = cal.get(cal.MONTH) + 1;
					int date = cal.get(cal.DATE);
					int hour = cal.get(cal.HOUR);
					int minute = cal.get(cal.MINUTE);
					int second = cal.get(cal.SECOND);
					String str = defaultPath + "__" + year + month + date
							+ hour + minute + second + "__" + ".date";
					Music m = new Music("", str, "", "", "");
					blendListContent.add(m);
					// for (int i = 0 ; i < blendListContent.size() ; ++i) {
					// Log.e( "doo", "***************************" +
					// blendListContent.get(i) );
					// }
					// Log.e("doo", " ");

					FileOutputStream f = new FileOutputStream(str);
					PrintStream ps = new PrintStream(f);
					MWMCRTime time = new MWMCRTime();

					for (int i = 0; i < blendinfo.size(); ++i) {
						String path = blendinfo.get(i).getPath();
						ps.print(path + "^");
						ps.print(time.indexTime() + "^" + time.loopTime()
								+ "^\n");
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
				// *************************************************************************************************
				// *************************************************************************************************
				
				Toast toast = Toast.makeText(getBaseContext(), "저장되었습니다.",
						Toast.LENGTH_SHORT);
				toast.show();
				
				break;
			}
			case R.id.openb: {
				PlayActivity.listIndex = -3;
				Intent i = new Intent(Blending.this, detailList.class);
				startActivity(i);
				break;
			}
			case R.id.mainbutton: {
				backMain = true;
				counting = false;

				pauseClick = true;
				lastEntering = true;
				Ending = false;
				indexNext = true;
				getOutOfHere = true;

				finish();
				break;
			}
			}

		}
	};

	public static boolean isPlay = false;

	private OnTouchListener touchlistener = new OnTouchListener() {
		@Override
		public boolean onTouch(View v, MotionEvent event) {
			switch (v.getId()) {
			case R.id.blendplay: 
			{
				if (event.getAction() == MotionEvent.ACTION_DOWN) {
					playpause.setImageResource(R.drawable.blend_play_shd);

				} else if (event.getAction() == MotionEvent.ACTION_UP) {
					playpause.setImageResource(R.drawable.blend_play);

					if (firstMediaPlayer.isPlaying() == true
							&& secondMediaPlayer.isPlaying() == false) { // %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
					// Log.e("doo",
					// "if (firstMediaPlayer.isPlaying() == true && secondMediaPlayer.isPlaying() == false)");
						pauseClick = true;
						isPause = true;
					} else if (firstMediaPlayer.isPlaying() == true
							&& secondMediaPlayer.isPlaying() == true) { // 이경우는
																		// 발생되지만
																		// 안먹힘..........ㅠ.ㅠ
					// Log.e("doo",
					// "if (firstMediaPlayer.isPlaying() == true && secondMediaPlayer.isPlaying() == true)");
						pauseClick = true;
						isPause = true;
					} else if (firstMediaPlayer.isPlaying() == false
							&& secondMediaPlayer.isPlaying() == true) { // 사실
																		// 이경우는
																		// 발생하지
																		// 않음.......%%%%%%%%%%%%%%%%%%%%%%%%5
					// Log.e("doo",
					// "if (firstMediaPlayer.isPlaying() == false && secondMediaPlayer.isPlaying() == true)");
						pauseClick = true;
						isPause = true;
						if (secondMediaPlayer.isPlaying()) {
							secondMediaPlayer.pause();
						} else {
							secondMediaPlayer.start();
						}
					} else if (firstMediaPlayer.isPlaying() == false
							&& secondMediaPlayer.isPlaying() == false) {
						// Log.e("doo",
						// "if (firstMediaPlayer.isPlaying() == false && secondMediaPlayer.isPlaying() == false)");
						pauseClick = false;
						isPause = false;

						if (counting == true) {
							// Log.e("doo", "			counting == true");
							onRestart();
							// Log.e("doo",
							// "onRestart()                  ending........");
							// //joosuk ***********************
						} else if (counting == false) {
							// Log.e("doo", "			counting == false");
							playJob.execute(blendinfo);
							counting = true;
						}

						// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@222
						// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@222
						if (Ending == false && lastEntering == true) {
							if (secondMediaPlayer.isPlaying() == false)
								secondMediaPlayer.start();
						}
						// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@222
						// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@222
					}
				}
				break;
			}
			}
			return false;
		}
	};

	@Override
	public void onRestart() {
		super.onRestart();
	}

	@Override
	public boolean onSearchRequested() {
		return true;
	}

	private ImageButton reBlend;
	private ImageButton madeby;
	private ImageButton playpause;
	private ImageButton goMain;
	private ImageButton saveb;
	private ImageButton openb;

	private ImageView albumImg;
	private ImageView imglele;
	private ImageView imgle;
	private ImageView imgcenter;
	private ImageView imgri;
	private ImageView imgriri;

	private TextView title;
	private TextView albumArt;

	static PlayJob playJob;  //doooooooooooooooooooooooooooooooooooooo

	private void initView() {
		reBlend = (ImageButton) findViewById(R.id.returnbtn);
		madeby = (ImageButton) findViewById(R.id.bmadeby);
		playpause = (ImageButton) findViewById(R.id.blendplay);
		goMain = (ImageButton) findViewById(R.id.mainbutton);

		saveb = (ImageButton) findViewById(R.id.saveb);
		openb = (ImageButton) findViewById(R.id.openb);

		saveb.setOnClickListener(clicklistener);
		openb.setOnClickListener(clicklistener);
		reBlend.setOnClickListener(clicklistener);
		madeby.setOnClickListener(clicklistener);
		playpause.setOnTouchListener(touchlistener);
		goMain.setOnClickListener(clicklistener);

		albumImg = (ImageView) findViewById(R.id.imagealbum);
		imgcenter = (ImageView) findViewById(R.id.imgCenter);
		imgle = (ImageView) findViewById(R.id.imgleft);
		imglele = (ImageView) findViewById(R.id.imgleftleft);
		imgri = (ImageView) findViewById(R.id.imgright);
		imgriri = (ImageView) findViewById(R.id.imgrightright);

		title = (TextView) findViewById(R.id.bTitleText);
		albumArt = (TextView) findViewById(R.id.bArtistText);

	}

	void setView(int position) {
		title.setText(PlayActivity.songList.get(position).getTitle());
		albumArt.setText(PlayActivity.songList.get(position).getArtist()
				+ " / " + PlayActivity.songList.get(position).getAlbum());

		Uri uri = ContentUris.withAppendedId(sArtworkUri, Integer
				.parseInt(PlayActivity.songList.get(position).getAlbumId()));
		albumImg.setImageURI(uri);

	}

	private void setAllvisible() {
		imglele.setVisibility(View.VISIBLE);
		imgriri.setVisibility(View.VISIBLE);
		imgle.setVisibility(View.VISIBLE);
		imgri.setVisibility(View.VISIBLE);
		imgcenter.setVisibility(View.VISIBLE);
	}

	void setImages(List<MWMCRInf> infolist, int position) {
		setAllvisible();
		if (position == 0) {
			imglele.setVisibility(View.INVISIBLE);
			imgle.setVisibility(View.INVISIBLE);

			imageUriSet(imgriri, infolist.get(position + 2).getNum());
			imageUriSet(imgri, infolist.get(position + 1).getNum());
			imageUriSet(imgcenter, infolist.get(position).getNum());

		} else if (position == 1) {
			imglele.setVisibility(View.INVISIBLE);
			imageUriSet(imgle, infolist.get(position - 1).getNum());
			imageUriSet(imgriri, infolist.get(position + 2).getNum());
			imageUriSet(imgri, infolist.get(position + 1).getNum());
			imageUriSet(imgcenter, infolist.get(position).getNum());

		} else if (blendinfo.size() - position == 2) {
			imgriri.setVisibility(View.INVISIBLE);
			imageUriSet(imglele, infolist.get(position - 2).getNum());
			imageUriSet(imgle, infolist.get(position - 1).getNum());
			imageUriSet(imgri, infolist.get(position + 1).getNum());
			imageUriSet(imgcenter, infolist.get(position).getNum());

		} else if (blendinfo.size() - position == 1) {
			imgri.setVisibility(View.INVISIBLE);
			imgriri.setVisibility(View.INVISIBLE);
			imageUriSet(imglele, infolist.get(position - 2).getNum());
			imageUriSet(imgle, infolist.get(position - 1).getNum());
			imageUriSet(imgcenter, infolist.get(position).getNum());

		} else {
			imageUriSet(imglele, infolist.get(position - 2).getNum());
			imageUriSet(imgriri, infolist.get(position + 2).getNum());
			imageUriSet(imgle, infolist.get(position - 1).getNum());
			imageUriSet(imgri, infolist.get(position + 1).getNum());
			imageUriSet(imgcenter, infolist.get(position).getNum());

		}

	}

	private void imageUriSet(ImageView imgview, int location) {
		Uri uri = ContentUris.withAppendedId(sArtworkUri, Integer
				.parseInt(PlayActivity.songList.get(location).getAlbumId()));
		imgview.setImageURI(uri);
	}

	@Override
	public void onStart() {
		super.onStart();
		if (bound == false) {
			this.bindService(new Intent(this, PlayService.class),
					serviceConnection, Context.BIND_AUTO_CREATE);
		} else {

		}
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		this.unbindService(serviceConnection);
		// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
		// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
		firstMediaPlayer.stop();
		secondMediaPlayer.stop();
		// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
		// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
		isPause = true;
		playJob.cancel(true);
	}

	public ServiceConnection serviceConnection = new ServiceConnection() {

		@Override
		public void onServiceConnected(ComponentName name, IBinder service) {
			blend = BlendInterface.Stub.asInterface((IBinder) service);

			bound = true;

			try {
				blend.registerCallback(mCallback);
			} catch (RemoteException e1) {
				// TODO Auto-generated catch block
				// Log.e("e", "binding");
				e1.printStackTrace();
			}

		}

		@Override
		public void onServiceDisconnected(ComponentName name) {
			try {
				blend.unregisterCallback(mCallback);
			} catch (RemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			blend = null;
			if (isFinishing() == false) {
				finish();
			}

		}
	};

	private static final int BUMP_MSG = 1;
	private static final int BUMP_MSG_BLEND = 2;

	private IRemoteServiceCallback mCallback = new IRemoteServiceCallback.Stub() {
		/**
		 * This is called by the remote service regularly to tell us about new
		 * values. Note that IPC calls are dispatched through a thread pool
		 * running in each process, so the code executing here will NOT be
		 * running in our main thread like most other things -- so, to update
		 * the UI, we need to use a Handler to hop over there.
		 */

		public void valueChanged(int value) {
			mHandler.sendMessage(mHandler.obtainMessage(BUMP_MSG, value, 0));
		}

		public void blendValueChanged(int value) {
			mHandler.sendMessage(mHandler.obtainMessage(BUMP_MSG_BLEND, value,
					0));
		}

	};
	private Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case BUMP_MSG_BLEND:
				// Log.e("MSG", Integer.toString(msg.arg1));
				setView(blendinfo.get(msg.arg1).getNum());
				setImages(blendinfo, msg.arg1);
				break;
			default:
				super.handleMessage(msg);
			}
		}

	};

}
