package com.Blend;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.ContentUris;
import android.content.Context;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.RemoteException;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.Blend.Blending.PlayJob;
import com.MWMCRFunction.MWMCRPlay;

public class detailList extends Activity {

	private List<Integer> indexList = new ArrayList<Integer>();

	class SongListAdapter extends ArrayAdapter<Music> {

		List<Music> list;

		public SongListAdapter(Context context, int textViewResourceId,
				List<Music> list) {
			super(context, textViewResourceId, list);
			this.list = list;
		}

		@Override
		public View getView(final int position, View convertView,
				ViewGroup parent) {
			View view = convertView;
			if (view == null) {
				LayoutInflater vi = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				view = vi.inflate(R.layout.row, null);
			}
						
			TextView TitleTextView = (TextView) view.findViewById(R.id.Title);
			TextView ArtistTextView = (TextView) view.findViewById(R.id.Artist);
			ImageView imageView = (ImageView) view.findViewById(R.id.Image);

			TitleTextView.setSelected(true);
			TitleTextView.setTextColor(Color.DKGRAY);

			if(PlayActivity.listIndex == -3){
				TitleTextView.setText(list.get(position).getTitle());
			} else{
				TitleTextView.setText(list.get(position).getTitle() + " - "
						+ list.get(position).getArtist());
				ArtistTextView.setText(list.get(position).getAlbum());
				Uri uri = ContentUris.withAppendedId(sArtworkUri, Integer
						.parseInt(list.get(position).getAlbumId()));
				imageView.setImageURI(uri);
			}
			
			if (PlayActivity.listIndex == -2)
				TitleTextView.setPadding(10, 0, 70, 0);
			else
				TitleTextView.setPadding(10, 0, 0, 0);

			

			CheckBox check = (CheckBox) view.findViewById(R.id.checkBox1);
			if (PlayActivity.listIndex == -2) {
				check.setVisibility(View.VISIBLE);
				check.setOnCheckedChangeListener(new OnCheckedChangeListener() {

					@Override
					public void onCheckedChanged(CompoundButton buttonView,
							boolean isChecked) {

						if (isChecked) {
							indexList.add(position);

						} else {
							if (indexList.contains(position))
								indexList.remove(indexList.indexOf(position));

						}
					}
				});

				boolean isChecked = false;
				for (int i = 0; i < indexList.size(); i++) {
					if (indexList.get(i) == position) {
						check.setChecked(true);
						isChecked = true;
						break;
					}
				}

				if (!isChecked)
					check.setChecked(false);

			} else
				check.setVisibility(View.INVISIBLE);

			return view;
		}
	}

	private static final Uri sArtworkUri = Uri
			.parse("content://media/external/audio/albumart");

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.detaillist);
		initItems();
		setAdapter();
		clickEvent();

	}

	private ListView listView;
	private ArrayAdapter<Music> songListAdapter;
	private ImageButton savebtn;
	private EditText et;
	private TextView tv;

	private void initItems() {
		listView = (ListView) findViewById(R.id.playview);
		savebtn = (ImageButton) findViewById(R.id.imageButton1);
		et = (EditText) findViewById(R.id.editText1);
		tv = (TextView) findViewById(R.id.deTitle);

		if(PlayActivity.listIndex == -3){
			savebtn.setVisibility(View.INVISIBLE);
			et.setVisibility(View.INVISIBLE);
			tv.setText("BLEND LIST");
			
		} else if (PlayActivity.listIndex == -2) {
			indexList = new ArrayList<Integer>();
			savebtn.setVisibility(View.VISIBLE);
			et.setVisibility(View.VISIBLE);
			getWindow().setSoftInputMode(
					WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
			et.setImeOptions(EditorInfo.IME_ACTION_DONE);

			savebtn.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					if (indexList.size() == 0)
						return;
					String title = et.getText().toString();
					List<Music> list = new ArrayList<Music>();
					for (int i : indexList) {
						list.add(PlayActivity.songList.get(i));
					}
					PlayActivity.playList.add(new myList(title, list));
					FileManager.savePlayList(getApplicationContext(),
							PlayActivity.playList, FileManager.pathPlaylist);
					finish();
				}
			});

		} else if (PlayActivity.listIndex == -1) {
			savebtn.setVisibility(View.INVISIBLE);
			et.setVisibility(View.INVISIBLE);
			tv.setText("모든음악");
			PlayActivity.currentList.clear();
			PlayActivity.currentList.addAll(PlayActivity.songList);
		} else {
			savebtn.setVisibility(View.INVISIBLE);
			et.setVisibility(View.INVISIBLE);
			tv.setText(PlayActivity.playList.get(PlayActivity.listIndex)
					.getTitle());
		}
	}

	private void clickSet(int position) throws RemoteException {
		PlayActivity.blendInterface.playFile(position);
		PlayActivity.currentPosition = position;
		// PlayActivity.setView ( position );
		// PlayActivity.setNowView ();
	}

	private void clickEvent() {
		if (PlayActivity.listIndex == -2)
			return;

		listView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				try {
//					Log.e("detail", Integer.toString(position));
					finish();

					if (PlayActivity.listIndex == -3) {
						Log.e("doonew", "index == -3");
						Log.e("doonew", "++++++++++++++++");
						Log.e("doonew", ""+Blending.blendListContent.get(position).getTitle().toString());
						Log.e("doonew", "++++++++++++++++");

							
							Blending.blendinfo = MWMCRPlay.PlayInfo(Blending.blendListContent.get(position).getTitle().toString(),
									PlayActivity.songName);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
							///////////////////////////////////////////////////////////////////////////////////////
							Blending.pauseClick = false;
							Blending.isPause = false;

							if (Blending.counting == true) {
								Log.e("doonew", "counting == true");
								onRestart();
							} else if (Blending.counting == false) {
								Log.e("doonew", "counting == false");
								Blending.getOutOfHere = true;
								Blending.backMain = true;
								Blending.counting = false;
								Blending.pauseClick = true;
								Blending.lastEntering = true;
								Blending.Ending = false;
								Blending.indexNext = false; // 이거 바꿔야 리블랜드 하고 다시 시작하면 소리 두배로 안커짐.....

								if (Blending.firstMediaPlayer.isPlaying() == true
										|| Blending.secondMediaPlayer.isPlaying() == true) {
									Blending.firstMediaPlayer.stop();
									Blending.secondMediaPlayer.stop();
								}
								Blending.isPlay = false;

//								Blending.playJob.cancel(true);
//								Blending.playJob = new Blending.PlayJob();
								
								Blending.playJob.execute(Blending.blendinfo);
								Blending.counting = true;
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
								//////////////////////////////////////////////////////////////////////////////////
							}
					} 
					else if (PlayActivity.listIndex == -1) {
						PlayActivity.blendInterface.clearPlaylist();
						for (Music e : PlayActivity.songList) {
							PlayActivity.blendInterface.addSongPlaylist(e
									.getPath());
						}
						PlayActivity.currentList.clear();
						PlayActivity.currentList.addAll(PlayActivity.songList);
						clickSet(position);

					} else {
						PlayActivity.blendInterface.clearPlaylist();
						for (Music e : PlayActivity.playList.get(
								PlayActivity.listIndex).getMusicList()) {
							PlayActivity.blendInterface.addSongPlaylist(e
									.getPath());

						}
						PlayActivity.currentList.clear();
						PlayActivity.currentList.addAll(PlayActivity.playList
								.get(PlayActivity.listIndex).getMusicList());
						clickSet(position);
					}

				} catch (RemoteException e) {
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		});

	}

	private void setAdapter() {

		if(PlayActivity.listIndex == -3){
			songListAdapter = new SongListAdapter(this.getApplicationContext(),
					R.layout.row, Blending.blendListContent);
			listView.setAdapter(songListAdapter);
		} else if (PlayActivity.listIndex == -1){
			songListAdapter = new SongListAdapter(this.getApplicationContext(),
					R.layout.row, PlayActivity.currentList);
			listView.setAdapter(songListAdapter);
			
		} else if (PlayActivity.listIndex == -2) {
			songListAdapter = new SongListAdapter(this.getApplicationContext(),
					R.layout.row, PlayActivity.songList);
			listView.setAdapter(songListAdapter);
		}  else {
			songListAdapter = new SongListAdapter(this.getApplicationContext(),
					R.layout.row, PlayActivity.playList.get(
							PlayActivity.listIndex).getMusicList());
			listView.setAdapter(songListAdapter);
		}

	}

}
