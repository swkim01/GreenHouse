package test.primium;

import android.content.*;
import android.graphics.*;
import android.util.*;
import android.view.*;
import android.view.GestureDetector.OnDoubleTapListener;
import android.view.GestureDetector.OnGestureListener;

public class CustomView extends View {

	public String m_Text = null;

	public enum PALETTE {
		Color, Brush, Eraser, Size, Mozaic, Animation
	};

	public enum BRUSH {
		Normal, Pattern, Eraser_Brush, Eraser_Mozaic, Clear_Brush, Clear_Mozaic, Sand, Candy, Coin, Flower, Paste, ColorPaper, Button, Star, Fire, Fish_eye, Light, Rain
	};

	public static PALETTE palette;
	public static BRUSH brush;

	public DrawTool m_Draw;

	public GestureDetector m_Detector;

	public Canvas m_PaletteCanvas;
	public Canvas m_AnimationCanvas;
	public Canvas m_DrawCanvas;
	public Canvas m_PasteCanvas;
	public Canvas m_MozaicCanvas;
	public Canvas m_BrushCanvas;
	public Canvas m_BackgroundCanvas;
	public Canvas m_BGAnimationCanvas;

	boolean m_bVisible;
	boolean m_bStartApp;
	boolean m_bVisibleEdge;

	static boolean m_bCheckSide;
	static boolean m_bCheckCenter;

	public int m_nFindMode;
	public int JNI_Width;
	public int JNI_Height;
	public Palette m_PaletteMethods;

	public Context m_Context;
	private boolean StartFlag;

	MyColor m_MyColor;
	MyBrush m_MyBrush;
	MyEraser m_MyEraser;
	MySize m_MySize;
	MyMozaic m_MyMozaic;
	MyAnimation m_MyAnimation;

	ThreadFunction m_Thread;
	GalleryViewActivity m_GalleryViewActivity;

	// 속성이 없는 생성자는 소스상에서 직접 생성할때만 쓰인다.
	public CustomView(Context context) {
		super(context);
		StartFlag = false;
		m_Context = context;
	}

	/*
	 * 리소스 xml 파일에서 정의하면 이 생성자가 사용된다.
	 * 
	 * 대부분 this 를 이용해 3번째 생성자로 넘기고 모든 처리를 3번째 생성자에서 한다.
	 */
	public CustomView(Context context, AttributeSet attrs) {
		this(context, attrs, 0);

		m_Context = context;

		StartFlag = false;
		m_Draw = new DrawTool();
	}

	/*
	 * xml 에서 넘어온 속성을 멤버변수로 셋팅하는 역할을 한다.
	 */
	public CustomView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);

		m_Context = context;
		StartFlag = false;
		this.m_Text = attrs.getAttributeValue(null, "text");

		m_Draw = new DrawTool();
	}

	/*
	 * Initialazation
	 */
	// 브러쉬 관련 속성을 초기화
	// 이미지와 관련된 속성을 Layout에서 처리
	public void Initialazation() {
		m_bStartApp = false;
		m_bCheckSide = false;
		m_bCheckCenter = false;

		palette = PALETTE.Brush;
		brush = BRUSH.Normal;

		m_Detector = new GestureDetector(m_GestureListener);
		m_Detector.setOnDoubleTapListener(m_DoubleTapListener);

		m_Draw.m_BrushOption.m_Blur = new BlurMaskFilter(20,
				BlurMaskFilter.Blur.NORMAL);
		m_Draw.m_BrushOption.m_Emboss = new EmbossMaskFilter(new float[] { 2,
				2, 2 }, 0.5f, 6, 5);

		m_Draw.m_BrushOption.m_Path = new Path();

		m_Draw.m_BrushPaint.setAntiAlias(true);
		m_Draw.m_BrushPaint.setDither(true);

		m_Draw.m_BrushPaint.setAntiAlias(true);
		m_Draw.m_BrushPaint.setColor(0xC000FF00);
		m_Draw.m_BrushPaint.setStyle(Paint.Style.STROKE);
		m_Draw.m_BrushPaint.setStrokeJoin(Paint.Join.ROUND);
		m_Draw.m_BrushPaint.setStrokeCap(Paint.Cap.ROUND);
		m_Draw.m_BrushPaint.setStrokeWidth(30);

		m_Draw.m_BackgroundPaint = new Paint(Paint.DITHER_FLAG
				| Paint.FILTER_BITMAP_FLAG);

		m_Draw.m_SidePalettePaint.setAntiAlias(true);
		m_Draw.m_SidePalettePaint.setDither(true);

		m_Draw.m_CenterPalettePaint.setAntiAlias(true);
		m_Draw.m_CenterPalettePaint.setDither(true);
		m_Draw.m_CenterPalettePaint.setColor(0xFFFFFFFF);

		m_Draw.m_SizePalettePaint.setAntiAlias(true);
		m_Draw.m_SizePalettePaint.setStrokeWidth(30);
		m_Draw.m_SizePalettePaint.setStyle(Paint.Style.FILL);
		m_Draw.m_SizePalettePaint.setColor(0xFF00FF00);

		m_Draw.m_ColorPaperPaint.setAntiAlias(true);
		m_Draw.m_ColorPaperPaint.setStrokeWidth(30);
		m_Draw.m_ColorPaperPaint.setStyle(Paint.Style.FILL_AND_STROKE);
		m_Draw.m_ColorPaperPaint.setColor(0xFF00FF00);

		m_Draw.m_PastePaint.setAntiAlias(true);
		m_Draw.m_PastePaint.setColor(0xA0FFFFFF);
		m_Draw.m_PastePaint.setStyle(Paint.Style.STROKE);
		m_Draw.m_PastePaint.setStrokeJoin(Paint.Join.ROUND);
		m_Draw.m_PastePaint.setStrokeCap(Paint.Cap.ROUND);
		m_Draw.m_PastePaint.setStrokeWidth(30);

		m_PaletteMethods = new Palette();

		BitmapFactory.Options Pallete_Option = new BitmapFactory.Options();
		m_Draw.m_PaletteImage = BitmapFactory.decodeResource(getResources(),
				R.drawable.pallete, Pallete_Option);
		m_Draw.m_EmptyPaletteImage = BitmapFactory.decodeResource(
				getResources(), R.drawable.pallete3, Pallete_Option);


		m_MyColor = new MyColor(m_Context);
		m_MyBrush = new MyBrush(m_Context);
		m_MyEraser = new MyEraser(m_Context);
		m_MySize = new MySize(m_Context);
		m_MyMozaic = new MyMozaic(m_Context);
		m_MyAnimation = new MyAnimation(m_Context);

		return;
	}

	// 브러쉬 변경 함수
	public Bitmap ChangeBrush(Bitmap OriginalBrush, int nAlpha, int nColor) {
		// 새로운 Brush를 생성
		Bitmap TempBrush = null;
		TempBrush = Bitmap.createBitmap(OriginalBrush.getWidth(),
				OriginalBrush.getHeight(), Bitmap.Config.ARGB_8888);

		// Brush의 해당 좌표의 Pixel을 얻기 위한 변수 생성
		int nTempPixel = 0x00000000;

		// Brush의 모든 좌표에 대한 Pixel을 연산
		for (int y = 0; y < OriginalBrush.getHeight(); y++) {
			for (int x = 0; x < OriginalBrush.getWidth(); x++) {
				// OriginalBrush의 해당 좌표의 Pixel을 얻음
				nTempPixel = OriginalBrush.getPixel(x, y);

				// 해당 좌표의 Pixel을 변형
				TempBrush.setPixel(x, y, (nTempPixel & nAlpha)
						| (0x00FFFFFF & nColor));
			}
		}
		return TempBrush;
	}

	/*
	 * xml 로 부터 모든 뷰를 inflate 를 끝내고 실행된다.
	 * 
	 * 대부분 이 함수에서는 각종 변수 초기화가 이루어 진다.
	 * 
	 * super 메소드에서는 아무것도 하지않기때문에 쓰지 않는다.
	 */
	@Override
	protected void onFinishInflate() {
		if (!StartFlag) {
			setClickable(true);
	
			Initialazation();
	
			if (m_Draw.m_BrushBitmap != null) // ( && m_Background == null)
			{
			}
		}
	}

	/*
	 * 넘어오는 파라메터는 부모뷰로부터 결정된 치수제한을 의미한다. 또한 파라메터에는 bit 연산자를 사용해서 모드와 크기를 같이
	 * 담고있다. 모드는 MeasureSpec.getMode(spec) 형태로 얻어오며 다음과 같은 3종류가 있다.
	 * MeasureSpec.AT_MOST : wrap_content (뷰 내부의 크기에 따라 크기가 달라짐)
	 * MeasureSpec.EXACTLY : fill_parent, match_parent (외부에서 이미 크기가 지정되었음)
	 * MeasureSpec.UNSPECIFIED : MODE 가 셋팅되지 않은 크기가 넘어올때 (대부분 이 경우는 없다)
	 * 
	 * fill_parent, match_parent 를 사용하면 윗단에서 이미 크기가 계산되어 EXACTLY 로 넘어온다. 이러한 크기는
	 * MeasureSpec.getSize(spec) 으로 얻어낼 수 있다.
	 * 
	 * 이 메소드에서는 setMeasuredDimension(measuredWidth,measuredHeight) 를 호출해 주어야 하는데
	 * super.onMeasure() 에서는 기본으로 이를 기본으로 계산하는 함수를 포함하고 있다.
	 * 
	 * 만약 xml 에서 크기를 wrap_content 로 설정했다면 이 함수에서 크기를 계산해서 셋팅해 줘야한다. 그렇지 않으면 무조껀
	 * fill_parent 로 나오게 된다.
	 */
	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		// height 진짜 크기 구하기
		int heightMode = MeasureSpec.getMode(heightMeasureSpec);
		int heightSize = 0;
		switch (heightMode) {
		case MeasureSpec.UNSPECIFIED: // mode 가 셋팅되지 않은 크기가 넘어올때
			heightSize = heightMeasureSpec;
			break;
		case MeasureSpec.AT_MOST: // wrap_content (뷰 내부의 크기에 따라 크기가 달라짐)
			heightSize = 20;
			break;
		case MeasureSpec.EXACTLY: // fill_parent, match_parent (외부에서 이미 크기가
									// 지정되었음)
			heightSize = MeasureSpec.getSize(heightMeasureSpec);
			break;
		}

		// width 진짜 크기 구하기
		int widthMode = MeasureSpec.getMode(widthMeasureSpec);
		int widthSize = 0;
		switch (widthMode) {
		case MeasureSpec.UNSPECIFIED: // mode 가 셋팅되지 않은 크기가 넘어올때
			widthSize = widthMeasureSpec;
			break;
		case MeasureSpec.AT_MOST: // wrap_content (뷰 내부의 크기에 따라 크기가 달라짐)
			widthSize = 100;
			break;
		case MeasureSpec.EXACTLY: // fill_parent, match_parent (외부에서 이미 크기가
									// 지정되었음)
			widthSize = MeasureSpec.getSize(widthMeasureSpec);
			break;
		}
		setMeasuredDimension(widthSize, heightSize);

	}

	/*
	 * onMeasure() 메소드에서 결정된 width 와 height 을 가지고 어플리케이션 전체 화면에서 현재 뷰가 그려지는
	 * bound 를 돌려준다.
	 * 
	 * 이 메소드에서는 일반적으로 이 뷰에 딸린 children 들을 위치시키고 크기를 조정하는 작업을 한다. 유의할점은 넘어오는
	 * 파라메터가 어플리케이션 전체를 기준으로 위치를 돌려준다.
	 * 
	 * super 메소드에서는 아무것도 하지않기때문에 쓰지 않는다.
	 */
	@Override
	protected void onLayout(boolean changed, int left, int top, int right,
			int bottom) {
		if (!StartFlag) {
//			m_PaletteCanvas = new Canvas(m_Draw.m_PaletteBitmap);
//			m_Draw.m_PaletteBitmap.eraseColor(0x00000000);

			m_AnimationCanvas = new Canvas(m_Draw.m_AnimationBitmap);
			m_Draw.m_AnimationBitmap.eraseColor(0x00000000);

			m_DrawCanvas = new Canvas(m_Draw.m_DrawBitmap);
			m_Draw.m_DrawBitmap.eraseColor(0x00000000);

			m_PasteCanvas = new Canvas(m_Draw.m_PasteBitmap);
			m_Draw.m_PasteBitmap.eraseColor(0x00000000);

			m_MozaicCanvas = new Canvas(m_Draw.m_MozaicBitmap);
			m_Draw.m_MozaicBitmap.eraseColor(0x00000000);

			m_BrushCanvas = new Canvas(m_Draw.m_BrushBitmap);
			m_Draw.m_BrushBitmap.eraseColor(0x00000000);

			m_BackgroundCanvas = new Canvas(m_Draw.m_BackgroundBitmap);
			m_Draw.m_BackgroundBitmap.eraseColor(0x00000000);

			// ///////////////////////////////////////////////////////////////////
			if (m_bVisibleEdge) {
				m_BGAnimationCanvas = new Canvas(m_Draw.m_BGAnimationBitmap);
				m_Draw.m_BGAnimationBitmap.eraseColor(0xFFFFFFFF);
			}

//			m_PaletteCanvas.drawBitmap(m_Draw.m_PaletteImage,
//					m_PaletteMethods.m_CenterPoint.x,
//					m_PaletteMethods.m_CenterPoint.y, null);
			StartFlag = true;
		}
	}

	/*
	 * 이 뷰의 크기가 변경되었을때 호출된다.
	 * 
	 * super 메소드에서는 아무것도 하지않기때문에 쓰지 않는다.
	 */
	@Override
	protected void onSizeChanged(int w, int h, int oldw, int oldh) {


		if (oldw == 0 && oldh == 0) {
			SetLength(w, h);
			StartFlag = false;
		} else {
			StartFlag = true;
		}

	}

	public void SetLength(int w, int h) {


		m_Draw.m_nDisplayWidth = w;
		m_Draw.m_nDisplayHeight = h;
		MakeBitmap(m_Draw.m_nDisplayWidth, m_Draw.m_nDisplayHeight);

		m_PaletteMethods.m_CenterPoint.x = w - m_Draw.m_PaletteImage.getWidth()
				/ 2;
		m_PaletteMethods.m_CenterPoint.y = h
				- m_Draw.m_PaletteImage.getHeight() / 2;
	}

	// 실제로 Bitmap을 Create하는 함수
	// 너비와 높이를 얻어와 생성
	public void MakeBitmap(int nWidth, int nHeight) {
		// 처음 화면 호출시 이미지 생성
			
		if (m_bStartApp) {
			Bitmap recycleBitmap;
			recycleBitmap = m_Draw.m_BackgroundBitmap;

			if (recycleBitmap.getWidth() > recycleBitmap.getHeight()) {
				m_Draw.m_BackgroundBitmap = Bitmap.createScaledBitmap(
						m_Draw.m_BackgroundBitmap, nWidth, nHeight, true);
			} else {
				m_Draw.m_BackgroundBitmap = Bitmap.createScaledBitmap(
						m_Draw.m_BackgroundBitmap, nHeight, nWidth, true);
			}

			if (m_nFindMode == Main.ServiceMode
					|| m_nFindMode == Main.SketchMode1
					|| m_nFindMode == Main.SketchMode2) {
				m_bVisibleEdge = true;
			} else {
				m_bVisibleEdge = false;
			}

			JNI_Width = nWidth;
			JNI_Height = nHeight;
			if(recycleBitmap != null)
				recycleBitmap.recycle();
			try {
//				m_Draw.m_PaletteBitmap = Bitmap.createBitmap(nWidth, nHeight,
//						Bitmap.Config.ARGB_8888);
	
				m_Draw.m_AnimationBitmap = Bitmap.createBitmap(nWidth, nHeight,
						Bitmap.Config.ARGB_8888);
	
				m_Draw.m_DrawBitmap = Bitmap.createBitmap(nWidth, nHeight,
						Bitmap.Config.ARGB_8888);
	
				m_Draw.m_PasteBitmap = Bitmap.createBitmap(nWidth, nHeight,
						Bitmap.Config.ARGB_8888);
	
				m_Draw.m_MozaicBitmap = Bitmap.createBitmap(nWidth, nHeight,
						Bitmap.Config.ARGB_8888);
	
				m_Draw.m_BrushBitmap = Bitmap.createBitmap(nWidth, nHeight,
						Bitmap.Config.ARGB_8888);
	
				if (m_bVisibleEdge) {
					m_Draw.m_BGAnimationBitmap = Bitmap.createBitmap(nWidth,
							nHeight, Bitmap.Config.ARGB_8888);
				}
	
				BitmapFactory.Options Pallete_Option = new BitmapFactory.Options();
				m_Draw.m_PaletteImage = BitmapFactory.decodeResource(
						getResources(), R.drawable.pallete, Pallete_Option);
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
				Intent intent = new Intent(m_Context, GalleryViewActivity.class);
				intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				m_Context.startActivity(intent);
			}
		}

//		m_Draw.m_PaletteBitmap.eraseColor(0x00000000);

	}

	public boolean isInside(float x, float y, CustomView CV) {
		boolean bInside = false;

		if (x >= 0 && x < CV.getWidth() && y >= 0 && y < CV.getHeight()) {
			bInside = true;
		} else {
			bInside = false;
		}

		return bInside;
	}

	/*
	 * 실제로 화면에 그리는 영역으로 View 를 상속하고 이 메소드만 구현해도 제대로 보여지게 된다.
	 * 
	 * 그릴 위치는 0,0 으로 시작해서 getMeasuredWidth(), getMeasuredHeight() 까지 그리면 된다.
	 * 
	 * super 메소드에서는 아무것도 하지않기때문에 쓰지 않는다.
	 */

	@Override
	protected void onDraw(Canvas canvas) {
		if (GalleryViewActivity.EndCheck)
			return;

		if (!m_bVisibleEdge) {
			canvas.drawBitmap(m_Draw.m_BackgroundBitmap, 0, 0, null);
		} else {
			canvas.drawBitmap(m_Draw.m_BGAnimationBitmap, 0, 0, null);
		}

		canvas.drawBitmap(m_Draw.m_BrushBitmap, 0, 0, null);

		if (m_Draw.m_BrushOption.m_bEraser) {
		} else {
			if (brush != BRUSH.Paste)
				canvas.drawPath(m_Draw.m_BrushOption.m_Path,
						m_Draw.m_BrushPaint);
		}

		if (m_MyMozaic.m_CurrentLinkedList.size() != 0)
			canvas.drawBitmap(m_Draw.m_MozaicBitmap, 0, 0, null);

		if (m_bVisibleEdge) {
			canvas.drawBitmap(m_Draw.m_BackgroundBitmap, 0, 0,
					m_Draw.m_BackgroundPaint);
		}

		canvas.drawBitmap(m_Draw.m_PasteBitmap, 0, 0, null);
		if (brush == BRUSH.Paste)
			canvas.drawPath(m_Draw.m_BrushOption.m_Path, m_Draw.m_PastePaint);

		canvas.drawBitmap(m_Draw.m_DrawBitmap, 0, 0, null);

		canvas.drawBitmap(m_Draw.m_AnimationBitmap, 0, 0, null);

		if (m_Draw.m_bVisiablePallete) {
			canvas.drawBitmap(m_Draw.m_PaletteBitmap, 0, 0, null);
		}

	}

	public float m_X, m_Y;

	/**
 */
	private void touch_start(float x, float y) {
		if (m_Draw.m_bVisiablePallete) {
			m_Draw.m_nGetPixel = m_Draw.m_PaletteBitmap.getPixel((int) x,
					(int) y);

			m_Draw.m_nAlpha = Color.alpha(m_Draw.m_nGetPixel);

			switch (palette) {
			case Color:
				m_MyColor.VisiablePallete(x, y, CustomView.this);
				break;
			case Brush:
				m_MyBrush.VisiablePallete(x, y, CustomView.this);
				break;
			case Eraser:
				m_MyEraser.VisiablePallete(x, y, CustomView.this);
				break;
			case Size:
				m_MySize.VisiablePallete(x, y, CustomView.this);
				break;
			case Mozaic:
				m_MyMozaic.VisiablePallete(x, y, CustomView.this);
				break;
			case Animation:
				m_MyAnimation.VisiablePallete(x, y, CustomView.this);
				break;
			}
		} else {
			switch (brush) {
			case Normal:
				m_MyBrush.TouchStart_Normal(x, y, CustomView.this);
				break;

			case Pattern:
				m_MyBrush.TouchStart_Pattern(x, y, CustomView.this);
				break;

			case Eraser_Brush:
				m_MyEraser.TouchStart_EraserBrush(x, y, CustomView.this);
				break;

			case Sand:
				m_MyMozaic.TouchStart_Sand(x, y, CustomView.this);
				break;

			case Paste:
				m_MyMozaic.TouchStart_Paste(x, y, CustomView.this);
				break;

			case Fire:
				m_MyAnimation.TouchStart_Fire(x, y, CustomView.this);
				break;
			}
		}
		return;
	}

	/**
 */
	private void touch_move(float x, float y) {
		if (m_Draw.m_bVisiablePallete) {
			if (m_Draw.m_bLongClickPallete) {
				m_PaletteMethods.PaletteDrag((int) x, (int) y,
						m_PaletteMethods, m_Draw, m_PaletteCanvas);
			}
			if (m_Draw.m_bSearchPallete) {
				m_PaletteMethods.PaletteSearch((int) x, (int) y,
						m_PaletteMethods, m_Draw, m_PaletteCanvas);
			}
		} else {
			switch (brush) {
			case Normal:
				m_MyBrush.TouchMove_Normal(x, y, CustomView.this);
				break;

			case Pattern:
				m_MyBrush.TouchMove_Pattern(x, y, CustomView.this);
				break;

			case Eraser_Brush:
				m_MyEraser.TouchMove_EraserBrush(x, y, CustomView.this);
				break;

			case Sand:
				m_MyMozaic.TouchMove_Sand(x, y, CustomView.this);
				break;

			case Paste:
				m_MyMozaic.TouchMove_Paste(x, y, CustomView.this);
				break;

			case Fire:
				m_MyAnimation.TouchMove_Fire(x, y, CustomView.this);
				break;
			}
		}
		return;
	}

	/**
 */
	private void touch_up(float x, float y) {
		if (m_Draw.m_bVisiablePallete) {
			m_Draw.m_bClickPallete = false;
			m_Draw.m_bDoubleClickPallete = false;
			m_Draw.m_bLongClickPallete = false;
			m_Draw.m_bDragPallete = false;
			m_Draw.m_bSearchPallete = false;
		} else {
			switch (brush) {
			case Normal:
				m_MyBrush.TouchUp_Normal(x, y, CustomView.this);
				break;

			case Pattern:
				m_MyBrush.TouchUp_Pattern(x, y, CustomView.this);
				break;

			case Eraser_Brush:
				m_MyEraser.TouchUp_EraserBrush(x, y, CustomView.this);
				break;

			case Eraser_Mozaic:
				m_MyEraser.TouchUp_EraserMozaic(CustomView.this);
				break;

			case Sand:
				m_MyMozaic.TouchUp_Sand(x, y, CustomView.this);
				break;

			case Candy:
				m_MyMozaic.TouchUp_Candy(x, y, CustomView.this);
				break;

			case Coin:
				m_MyMozaic.TouchUp_Coin(x, y, CustomView.this);
				break;

			case Flower:
				m_MyMozaic.TouchUp_Flower(x, y, CustomView.this);
				break;

			case Paste:
				m_MyMozaic.TouchUp_Paste(x, y, CustomView.this);
				break;

			case ColorPaper:
				m_MyMozaic.TouchUp_ColorPaper(x, y, CustomView.this);
				break;
			case Button:
				m_MyMozaic.TouchUp_Button(x, y, CustomView.this);
				break;
			case Star:
				m_MyMozaic.TouchUp_Star(x, y, CustomView.this);
				break;
			case Fire:
				m_MyAnimation.TouchUp_Fire(x, y, CustomView.this);
				break;

			case Fish_eye:
				m_MyAnimation.TouchUp_FishEye(x, y, CustomView.this);
				break;

			case Light:
				m_MyAnimation.TouchUp_Light(x, y, CustomView.this);
				break;

			case Rain:
				m_MyAnimation.TouchUp_Rain(x, y, CustomView.this);
				break;
			}
		}
		return;
	}

	/*
	 * 현재 view 가 focus 상태일때 key 를 누르면 이 메소드가 호출됨. 즉 이 메소드를 사용하려면
	 * setFocusable(true) 여야함.
	 * 
	 * 그리고 super 메소드에서는 기본적인 키 작업(예를들면 BACK 키 누르면 종료)을 처리하기 때문에 일반적으로 return 시에
	 * 호출하는게 좋다. 만약 기본적인 작업을 하지않게 하려면 super 함수를 호출하지 않아도 된다.
	 * 
	 * 다른 event 메소드들도 유사하게 동작한다.
	 */
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		return super.onKeyDown(keyCode, event);
	}

	/*
	 * 이 view 에 touch 가 일어날때 실행됨.
	 * 
	 * 기본적으로 touch up 이벤트가 일어날때만 잡아내며 setClickable(true) 로 셋팅하면 up,move,down 모두
	 * 잡아냄
	 */
	@Override
	public boolean onTouchEvent(MotionEvent event) {
		int action = event.getAction();
		float x = event.getX();
		float y = event.getY();

		switch (action) {
		case MotionEvent.ACTION_DOWN:
			touch_start(x, y);
			break;
		case MotionEvent.ACTION_MOVE:
			touch_move(x, y);
			break;
		case MotionEvent.ACTION_UP:
			touch_up(x, y);
			break;
		}

		invalidate();

		m_Detector.onTouchEvent(event);
		return super.onTouchEvent(event);
	}

	OnGestureListener m_GestureListener = new OnGestureListener() {
		@Override
		public boolean onDown(MotionEvent e) {
			// AppendText(String.format("Down : %d, %d", (int)e.getX(),
			// (int)e.getY()));
			return false;
		}

		@Override
		public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX,
				float velocityY) {
			// AppendText(String.format("Fling : (%d,%d)-(%d,%d) (%d,%d)",
			// (int)e1.getX(), (int)e1.getY(), (int)e2.getX(), (int)e2.getY(),
			// (int)velocityX, (int)velocityY));
			return false;
		}

		@Override
		public void onLongPress(MotionEvent e) {
			// AppendText("LongPress");
			if (m_Draw.m_bVisiablePallete)
				m_Draw.m_bLongClickPallete = true;
		}

		@Override
		public boolean onScroll(MotionEvent e1, MotionEvent e2,
				float distanceX, float distanceY) {
			// AppendText(String.format("Scroll : (%d,%d)-(%d,%d) (%d,%d)",
			// (int)e1.getX(), (int)e1.getY(), (int)e2.getX(), (int)e2.getY(),
			// (int)distanceX, (int)distanceY));
			if (m_Draw.m_bVisiablePallete)
				m_Draw.m_bSearchPallete = true;
			return false;
		}

		@Override
		public void onShowPress(MotionEvent e) {
		}

		@Override
		public boolean onSingleTapUp(MotionEvent e) {

			return false;
		}
	};

	OnDoubleTapListener m_DoubleTapListener = new OnDoubleTapListener() {

		@Override
		public boolean onDoubleTap(MotionEvent e) {

			if (m_Draw.m_bVisiablePallete) {
				switch (palette) {
				case Color:
					m_MyColor.DoubleTap(e, CustomView.this);
					break;
				}
				invalidate();
			}
			return false;
		}

		@Override
		public boolean onDoubleTapEvent(MotionEvent e) {
			// AppendText("DoubleTapEvent");
			return false;
		}

		@Override
		public boolean onSingleTapConfirmed(MotionEvent e) {
			if (m_Draw.m_bVisiablePallete) {
				// GalleryViewActivity.BrushBtn.setFocusable(false);
				// GalleryViewActivity.SizeChangeBtn.setFocusable(false);
				// GalleryViewActivity.EraseBtn.setFocusable(false);
				// GalleryViewActivity.MozaicBtn.setFocusable(false);
				// GalleryViewActivity.AniStickerBtn.setFocusable(false);
				// GalleryViewActivity.PalleteBtn.setFocusable(false);
				switch (palette) {
				case Color:
					if (m_bCheckCenter || m_bCheckSide) {
						m_MyColor.SingleTapConfirmed(e, CustomView.this);
						// GalleryViewActivity.PalleteBtn.setFocusable(true);
					}
					break;
				case Brush:
					if (m_bCheckCenter || m_bCheckSide) {
						m_MyBrush.SingleTapConfirmed(e, CustomView.this);
						// GalleryViewActivity.BrushBtn.setFocusable(true);
					}
					break;
				case Eraser:
					if (m_bCheckCenter || m_bCheckSide) {
						m_MyEraser.SingleTapConfirmed(e, CustomView.this);
						// GalleryViewActivity.EraseBtn.setFocusable(true);
					}
					break;
				case Size:
					if (m_bCheckCenter) {
						m_MySize.SingleTapConfirmed(e, CustomView.this);
						// GalleryViewActivity.SizeChangeBtn.setFocusable(true);
					}
					break;

				case Mozaic:
					if (m_bCheckCenter || m_bCheckSide) {
						m_MyMozaic.SingleTapConfirmed(e, CustomView.this);
						// GalleryViewActivity.MozaicBtn.setFocusable(true);
					}
					break;

				case Animation:
					if (m_bCheckCenter || m_bCheckSide) {
						m_MyAnimation.SingleTapConfirmed(e, CustomView.this);
						// GalleryViewActivity.AniStickerBtn.setFocusable(true);
					}
					break;
				}

				if (m_Draw.m_nAlpha != 0 && !(m_bCheckCenter || m_bCheckSide)) {
					m_Draw.m_bVisiablePallete = true;
				} else {
					m_Draw.m_bVisiablePallete = false;
				}
				invalidate();
			}
			return false;
		}
	};

	public String getText() {
		return m_Text;
	}

	public void setText(String text) {
		this.m_Text = text;
	}

	public void recycleBitmap() {
		m_Draw.recycleBitmap();
		m_MyBrush.recycleBitmap();
		m_MyColor.recycleBitmap();
		m_MyEraser.recycleBitmap();
		m_MyMozaic.recycleBitmap();
		m_MyAnimation.recycleBitmap();
		m_PaletteMethods.recycleBitmap();
	}

	public void onDestroy() {
		
		recycleBitmap();

		m_Draw = null;

		m_Detector = null;

		m_PaletteCanvas = null;
		m_DrawCanvas = null;
		m_PasteCanvas = null;
		m_MozaicCanvas = null;
		m_BrushCanvas = null;
		m_BGAnimationCanvas = null;

		m_PaletteMethods = null;

		m_Context = null;

		m_MyColor = null;
		m_MyBrush = null;
		m_MyEraser = null;
		m_MySize = null;
		m_MyMozaic = null;
		m_MyAnimation = null;

		System.gc();

		dalvik.system.VMRuntime.getRuntime().runFinalizationSync();

	}
}