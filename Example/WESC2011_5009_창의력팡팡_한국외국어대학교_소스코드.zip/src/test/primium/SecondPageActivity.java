package test.primium;

import java.io.File;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.LinearLayout;

public class SecondPageActivity extends Activity{
	
	private LinearLayout SecondLayout;
	private Button CameraBtn;
	private Button AlbumBtn;
	private BtnBackground mBtnBackground;
	private Drawable mBackgroundDrawable;
	private Drawable mDrawable;
	private Bitmap SecondBackground;
	private Intent intent;
	public Uri mImageCaptureUri;
	private WindowManager wm;
	private BitmapFactory.Options options;
	private Display disp;
	private boolean Process;
	private MediaPlayer mPlayer_Click;
	private boolean btnflag;
	@Override
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		System.out.println("SecondPageActivity onCreate()");
		setContentView(R.layout.second);
		
		
		
		mBtnBackground = new BtnBackground();
		SecondLayout = (LinearLayout) findViewById(R.id.secondView);
		
		CameraBtn = (Button) findViewById(R.id.CameraBtn);
		AlbumBtn = (Button) findViewById(R.id.AlbumBtn);
		
		wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
		disp = wm.getDefaultDisplay();
		options = new BitmapFactory.Options();
		BitmapOption.getSampleSize(options, disp, null, getResources(),
				R.drawable.background2);
		
		
		Process = true;
		mPlayer_Click = MediaPlayer.create(this, R.raw.click);
		mBtnBackground.albumBtnBackground(this, AlbumBtn);
		mBtnBackground.cameraBtnBackground(this, CameraBtn);
		SecondBackground = BitmapFactory.decodeResource(getResources(),
				R.drawable.background2, options);
		mBackgroundDrawable = new BitmapDrawable(SecondBackground);
		SecondLayout.setBackgroundDrawable(mBackgroundDrawable);
		btnflag = false;
	}
	
	public void onStart() {
		super.onStart();
		System.out.println("SecondPageActivity onStart()");

	}

	@Override
	public void onResume(){
		super.onResume();
		
		System.out.println("SecondPageActivity onResume()");
		getWindow()
		.addFlags(
				WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED);
		
		
		Intent svc = new Intent(this, BackgroundSoundService.class);
		startService(svc);
		final Animation BtnAnimation;
		BtnAnimation = AnimationUtils.loadAnimation(this,
				R.anim.mainbtn_in);
		if(Process){
			new Handler().postDelayed(new Runnable() {
				@Override
				public void run() {
					// TODO Auto-generated method stub
					AlbumBtn.startAnimation(BtnAnimation);
					CameraBtn.startAnimation(BtnAnimation);
					Process = false;
				}
			}, 20);
			new Handler().postDelayed(new Runnable() {
				@Override
				public void run() {
					// TODO Auto-generated method stub
					CameraBtn.setOnClickListener(BtnClickListener);
					AlbumBtn.setOnClickListener(BtnClickListener);
				}
			}, 700);
		}
	}
	
	
	@Override
	public void onPause(){
		super.onPause();
		System.out.println("SecondPagePageActivity onPause()");
		if(!Process && BackgroundSoundService.mp.isPlaying()){
			BackgroundSoundService.mp.pause();
			System.out.println("SecondPageActivity onPause BGM Stop");
		}
	}
	public void onStop(){
		super.onStop();
//		SecondLayout.setBackgroundDrawable(null);
//		AlbumBtn.setBackgroundDrawable(null);
//		CameraBtn.setBackgroundDrawable(null);
//		SecondBackground.recycle();
//		mBtnBackground.recycleBitmap1();
		System.out.println("SecondPagePageActivity onStop()");
	}
	
	public void onRestart(){
		super.onRestart();
		Process=false;
	}
	@Override
	public void onDestroy(){
		super.onDestroy();
		SecondLayout.setBackgroundDrawable(null);
		AlbumBtn.setBackgroundDrawable(null);
		CameraBtn.setBackgroundDrawable(null);
		mBtnBackground.recycleBitmap1();
		SecondBackground.recycle();
		
//		BackgroundSoundService.mp.stop();
//		stopService(FirstPageActivity.BackgoundMusic);
	}
	
	private Button.OnClickListener BtnClickListener = new View.OnClickListener(){
		@Override
		public void onClick(View v) {
			if(!btnflag){
				mPlayer_Click.start();
				switch(v.getId()){
					case R.id.CameraBtn:
						Process = true;
						intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
						String url = "tmp_"
								+ String.valueOf(System.currentTimeMillis())
								+ ".jpg";
						mImageCaptureUri = Uri.fromFile(new File(Environment
								.getExternalStorageDirectory(), url));
						intent.putExtra(android.provider.MediaStore.EXTRA_OUTPUT,
								mImageCaptureUri);
						intent.putExtra("return-data", true);
						startActivityForResult(intent, 1);
						break;
					case R.id.AlbumBtn:
						Process = true;
						intent = new Intent(SecondPageActivity.this,ThirdPageActivity.class);
						finish();
						startActivity(intent);
						break;
				}
				btnflag = true;
			}
		}
	};
	
	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		Process = false;
		btnflag = false;
		finishActivity(requestCode);
		if (resultCode == RESULT_OK && requestCode == 1) {
			Process = true;
			int position = 0;
			String strPath = mImageCaptureUri.getPath();

			intent = new Intent(this, FourthPageActivity.class);
			intent.putExtra("ImageNum", position);
			intent.putExtra("ImagePath", strPath);
			intent.putExtra("select", requestCode);
			finish();
			startActivity(intent);
		}
	}
	
	@Override
	public void onBackPressed() {
//		super.onBackPressed();
		finish();
		Intent i = new Intent(this , FirstPageActivity.class);
		startActivity(i);
		mPlayer_Click.start();
		Process = true;
	}
	
}
