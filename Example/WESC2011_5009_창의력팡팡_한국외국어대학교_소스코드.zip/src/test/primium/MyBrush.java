package test.primium;

import test.primium.CustomView.BRUSH;
import android.content.*;
import android.graphics.*;
import android.view.*;

public class MyBrush {
	Context m_Context;

	public static final int NUMBER = 6;

	public Bitmap[] m_SideBrushBMP = new Bitmap[NUMBER];
	public Bitmap m_CenterBrushBMP;
	public static final float RADIUS = 30;

	public static final int CENTER = -1;
	public static final int NORMAL = 0;
	public static final int EMBOSS = 1;
	public static final int BLUR = 2;
	public static final int PATTERN1 = 3;
	public static final int PATTERN2 = 4;
	public static final int PATTERN3 = 5;

	public static final int TOUCH_TOLERANCE = 4;

	float m_fCurX;
	float m_fCurY;
	float m_fPreX = 0;
	float m_fPreY = 0;
	float m_fdx;
	float m_fdy;
	float m_fGradient;
	float m_fSignX = 1;
	float m_fSignY = 1;
	float m_fMax = 0;

	int m_nFinalSelectItem = 0;

	public void recycleBitmap() {
		for (int i = 0; i < m_SideBrushBMP.length; i++) {
			m_SideBrushBMP[i].recycle();
			m_SideBrushBMP[i] = null;
		}
		m_CenterBrushBMP.recycle();
		m_CenterBrushBMP = null;

		m_SideBrushBMP = null;
	}

	public MyBrush(Context context) {
		m_Context = context;


		int resizeNum = 1;
		for (int n = 0; n < NUMBER; n++) {
			m_SideBrushBMP[n] = Main.ResizeOptions(m_Context, R.drawable.brush00 + n, resizeNum);
		}

		m_CenterBrushBMP = m_SideBrushBMP[0];
	}

	public void VisiablePallete(float x, float y, CustomView CV) {
		CustomView.m_bCheckCenter = CV.m_PaletteMethods.CheckCenter(x, y,
				CV.m_PaletteMethods.m_CenterPoint.x,
				CV.m_PaletteMethods.m_CenterPoint.y, RADIUS);

		if (CustomView.m_bCheckCenter) {
			CV.m_PaletteMethods.m_PrePoint.x = (int) x;
			CV.m_PaletteMethods.m_PrePoint.y = (int) y;

			CV.m_PaletteMethods.m_nSelectItemIndex = CENTER;

			return;
		}

		for (int n = 0; n < CV.m_PaletteMethods.m_nItemNum; n++) {
			if (CV.m_PaletteMethods.m_CurrentPoint[n].y > CV.m_PaletteMethods.m_CenterPoint.y)
				continue;
			CustomView.m_bCheckSide = CV.m_PaletteMethods.CheckCenter(x, y,
					CV.m_PaletteMethods.m_CurrentPoint[n].x,
					CV.m_PaletteMethods.m_CurrentPoint[n].y, RADIUS);

			if (CustomView.m_bCheckSide) {
				CV.m_PaletteMethods.m_nSelectItemIndex = n;
				break;
			}
		}

		CV.m_PaletteMethods.m_PrePoint.x = (int) x;
		CV.m_PaletteMethods.m_PrePoint.y = (int) y;

		return;
	}

	public void TouchStart_Normal(float x, float y, CustomView CV) {
		CV.m_Draw.m_BrushOption.m_Path.reset();
		CV.m_Draw.m_BrushOption.m_Path.moveTo(x, y);
		CV.m_X = x;
		CV.m_Y = y;

		return;
	}

	public void TouchMove_Normal(float x, float y, CustomView CV) {
		float dx = Math.abs(x - CV.m_X);
		float dy = Math.abs(y - CV.m_Y);
		if (dx >= TOUCH_TOLERANCE || dy >= TOUCH_TOLERANCE) {
			CV.m_Draw.m_BrushOption.m_Path.quadTo(CV.m_X, CV.m_Y,
					(x + CV.m_X) / 2, (y + CV.m_Y) / 2);

			CV.m_X = x;
			CV.m_Y = y;
		}

		return;
	}

	public void TouchUp_Normal(float x, float y, CustomView CV) {
		
		CV.m_Draw.m_BrushOption.m_Path.lineTo(CV.m_X, CV.m_Y);
		CV.m_BrushCanvas.drawPath(CV.m_Draw.m_BrushOption.m_Path,
				CV.m_Draw.m_BrushPaint);
		CV.m_Draw.m_BrushOption.m_Path.reset();
		return;
	}

	public void TouchStart_Pattern(float x, float y, CustomView CV) {
		CV.m_BrushCanvas
				.drawBitmap(
						CV.m_Draw.m_BrushOption.m_ChangeBrush,
						x
								- (CV.m_Draw.m_BrushOption.m_ChangeBrush
										.getWidth() / 2),
						y
								- (CV.m_Draw.m_BrushOption.m_ChangeBrush
										.getHeight() / 2), null);

		m_fPreX = x;
		m_fPreY = y;

		return;
	}

	public void TouchMove_Pattern(float x, float y, CustomView CV) {
		m_fCurX = x;
		m_fCurY = y;

		m_fdx = m_fCurX - m_fPreX;
		m_fdy = m_fCurY - m_fPreY;

		m_fGradient = Math.abs(m_fdy) / Math.abs(m_fdx);

		if (Math.abs(m_fdx) < Math.abs(m_fdy)) {
			m_fSignX = 1 / m_fGradient;
			m_fSignY = 1;
			m_fMax = Math.abs(m_fdy);
		} else {
			m_fSignX = 1;
			m_fSignY = m_fGradient;
			m_fMax = Math.abs(m_fdx);
		}

		if (m_fdx < 0)
			m_fSignX *= -1;

		if (m_fdy < 0)
			m_fSignY *= -1;

		for (int nConut = 0; nConut <= m_fMax; nConut += 1) {
			CV.m_BrushCanvas
					.drawBitmap(
							CV.m_Draw.m_BrushOption.m_ChangeBrush,
							m_fPreX
									+ (m_fSignX * nConut)
									- (CV.m_Draw.m_BrushOption.m_ChangeBrush
											.getWidth() / 2),
							m_fPreY
									+ (m_fSignY * nConut)
									- (CV.m_Draw.m_BrushOption.m_ChangeBrush
											.getHeight() / 2), null);
		}

		m_fPreX = x;
		m_fPreY = y;

		return;
	}

	public void TouchUp_Pattern(float x, float y, CustomView CV) {
		CV.m_BrushCanvas
				.drawBitmap(
						CV.m_Draw.m_BrushOption.m_ChangeBrush,
						x
								- (CV.m_Draw.m_BrushOption.m_ChangeBrush
										.getWidth() / 2),
						y
								- (CV.m_Draw.m_BrushOption.m_ChangeBrush
										.getHeight() / 2), null);

		return;
	}

	public void SingleTapConfirmed(MotionEvent e, CustomView CV) {

		if(CV.m_PaletteMethods.m_nSelectItemIndex > NUMBER)
		{
			return;
		}
		SelectBrush(CV.m_PaletteMethods.m_nSelectItemIndex, CV);

		if (CV.m_PaletteMethods.m_nSelectItemIndex != CENTER) {
			m_nFinalSelectItem = CV.m_PaletteMethods.m_nSelectItemIndex;
			m_CenterBrushBMP = m_SideBrushBMP[m_nFinalSelectItem];
		}
		CV.m_PaletteMethods.m_CenterBitmap = m_CenterBrushBMP;

		CV.m_Draw.m_bVisiablePallete = false;
		CV.m_Draw.m_BrushOption.m_bEraser = false;
		CV.m_Draw.m_BrushPaint.setXfermode(null);
		CV.invalidate();
		return;
	}

	public void SelectBrush(int nIndex, CustomView CV) {

		switch (nIndex) {
		case CENTER:
			SelectBrush(m_nFinalSelectItem, CV);
			break;
		case NORMAL:
			CustomView.brush = BRUSH.Normal;
			CV.m_Draw.m_BrushPaint.setMaskFilter(null);
			break;

		case EMBOSS:
			CustomView.brush = BRUSH.Normal;
			CV.m_Draw.m_BrushPaint
					.setMaskFilter(CV.m_Draw.m_BrushOption.m_Emboss);
			break;

		case BLUR:
			CustomView.brush = BRUSH.Normal;
			CV.m_Draw.m_BrushPaint
					.setMaskFilter(CV.m_Draw.m_BrushOption.m_Blur);
			// CV.m_PaletteMethods.m_CenterBitmap = m_SideBrushBMP[BLUR];
			break;

		case PATTERN1:
			CustomView.brush = BRUSH.Pattern;
			CV.m_Draw.m_BrushOption.m_ChangeBrush = CV.ChangeBrush(
					m_SideBrushBMP[PATTERN1], 0x0C000000,
					CV.m_Draw.m_BrushPaint.getColor());
			break;

		case PATTERN2:
			CustomView.brush = BRUSH.Pattern;
			CV.m_Draw.m_BrushOption.m_ChangeBrush = CV.ChangeBrush(
					m_SideBrushBMP[PATTERN2], 0x0C000000,
					CV.m_Draw.m_BrushPaint.getColor());
			break;

		case PATTERN3:
			CustomView.brush = BRUSH.Pattern;
			CV.m_Draw.m_BrushOption.m_ChangeBrush = CV.ChangeBrush(
					m_SideBrushBMP[PATTERN3], 0x0C000000,
					CV.m_Draw.m_BrushPaint.getColor());
			break;
		}
	}

	public void Initialization(CustomView CV) {
		CV.m_PaletteMethods.m_nItemNum = MyBrush.NUMBER;

		CV.m_PaletteMethods.m_SideBitmap = m_SideBrushBMP;
		CV.m_PaletteMethods.m_CenterBitmap = m_CenterBrushBMP;
	}
}
