package test.primium;
import android.content.res.Resources;
import android.graphics.BitmapFactory;
import android.view.Display;
import android.widget.Button;


public class BitmapOption {
	public static void getSampleSize(BitmapFactory.Options options ,Display disp, String strImagePath, Resources res,int id)
	{
		if(id == -1 && strImagePath != null){
			int DispLength = Math.max(disp.getHeight(), disp.getWidth());
			int BitmapLength = Math.max(getBitmapOfHeight(strImagePath),getBitmapOfWidth(strImagePath));
			options.inSampleSize = BitmapLength/DispLength + 1 ;
		}
		else
		{
			int DispLength = Math.max(disp.getHeight(), disp.getWidth());
			int BitmapLength = Math.max(getBitmapOfHeight(res, id),getBitmapOfWidth(res, id));
			options.inSampleSize = BitmapLength/DispLength + 1;
		}
	}
	public static BitmapFactory.Options getSampleSize(Button button, Resources res,int id)
	{
		BitmapFactory.Options options = new BitmapFactory.Options();
		
			int DispLength = Math.min(button.getHeight(), button.getWidth());
			int BitmapLength = Math.min(getBitmapOfHeight(res, id),getBitmapOfWidth(res, id));
			options.inSampleSize = BitmapLength/DispLength;
			return options;
	}
	
	public static BitmapFactory.Options buttonResize(Display disp, Resources res,int resId ,int resizeNum)
	{
		BitmapFactory.Options options  = new BitmapFactory.Options();
		int DispLength = Math.min(disp.getHeight(), disp.getWidth())/resizeNum;
		int BitmapLength = Math.min(getBitmapOfHeight(res, resId),getBitmapOfWidth(res, resId));
		options.inSampleSize = BitmapLength/DispLength;
		return options;
	}
	
	
	/** Get Bitmap's Width **/
	public static int getBitmapOfWidth( String strImagePath ){
	  try {
	    BitmapFactory.Options options = new BitmapFactory.Options();
	    options.inJustDecodeBounds = true;
	    BitmapFactory.decodeFile(strImagePath, options);
	    return options.outWidth;
	  } catch(Exception e) {
	    return 0;
	  }
	}
	 
	/** Get Bitmap's height **/
	public static int getBitmapOfHeight( String strImagePath ){
	  try {
	    BitmapFactory.Options options = new BitmapFactory.Options();
	    options.inJustDecodeBounds = true;
	    BitmapFactory.decodeFile(strImagePath, options);
	   
	  return options.outHeight;
	  } catch(Exception e) {
	    return 0;
	  }
	}
	
	/** Get Bitmap's Width **/
	public static int getBitmapOfWidth(Resources res, int id ){
	  try {
	    BitmapFactory.Options options = new BitmapFactory.Options();
	    options.inJustDecodeBounds = true;
	    BitmapFactory.decodeResource(res, id, options);
	    return options.outWidth;
	  } catch(Exception e) {
	    return 0;
	  }
	}
	 
	/** Get Bitmap's height **/
	public static int getBitmapOfHeight(Resources res,  int id  ){
	  try {
	    BitmapFactory.Options options = new BitmapFactory.Options();
	    options.inJustDecodeBounds = true;
	    BitmapFactory.decodeResource(res, id, options);
	   
	  return options.outHeight;
	  } catch(Exception e) {
	    return 0;
	  }
	}
}
