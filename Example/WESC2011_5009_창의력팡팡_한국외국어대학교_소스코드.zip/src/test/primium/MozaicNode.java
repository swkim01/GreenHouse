package test.primium;

import android.graphics.*;

public class MozaicNode {
	public MozaicNode()
	{
		m_nBrushType = MyMozaic.CANDY;
		m_fTouchPositionX = 0;
		m_fTouchPositionY = 0;
		
		m_bCheckPosition = false;
		m_PolygonPath = new Path();
	}

	public MozaicNode(int nPolygonNum)
	{
		m_nBrushType = MyMozaic.COLOR_PAPER;
		m_fTouchPositionX = 0;
		m_fTouchPositionY = 0;
		
		m_nVertexSize = nPolygonNum;
		
		m_nPolygonVertex = new Point[m_nVertexSize];
		
		m_bCheckPosition = false;
		m_PolygonPath = new Path();
	}
	
	public void VertexToPath(Point[] nPolygonVertex, int nVertexSize)
	{
		int nIndex;
		
		m_PolygonPath.moveTo(nPolygonVertex[0].x, nPolygonVertex[0].y);
		
		for(int n = 1; n <= nVertexSize; n++)
		{
			nIndex = n%nVertexSize;
			m_PolygonPath.lineTo(nPolygonVertex[nIndex].x, nPolygonVertex[nIndex].y);
		}
	}
	
	int m_nBrushType;
	int m_nBrushColor;
	
	float m_fTouchPositionX;
	float m_fTouchPositionY;
	
	int m_nVertexSize;
	Point[] m_nPolygonVertex;
	Path m_PolygonPath;
	
	boolean m_bCheckPosition;
}
