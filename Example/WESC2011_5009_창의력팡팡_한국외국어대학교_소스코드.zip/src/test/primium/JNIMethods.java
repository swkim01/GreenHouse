package test.primium;

import android.graphics.*;

public class JNIMethods {
	// public Bitmap Ret_Image;
	public static int width;
	public static int height;
	public static int[] ImageArray = null;
	public static int[] Array = null;
	public JNIMethods() {
//		Ret_Image = null;
		ImageArray = null;
	}

	static {
		System.loadLibrary("JNI");
	}

	private native int cvSketchEffect1(int[] ImageArray, int width, int height);
	private native int cvSketchEffect2(int[] ImageArray, int width, int height);

	private native int cvGrayEffect(int[] ImageArray, int width, int height);

	private native int cvOilPaintEffect(int[] ImageArray, int width,
			int height, int nRadius, int nDifferentlntensity);

	private native int cvWaterColorEffect(int[] ImageArray, int width,
			int height);
	

	
	private native void cvRainDropEffect(int[] ImageArray, int width,
			int height,int xPoint, int yPoint);

	private native void cvLightEffect(int[] ImageArray, int width,
			int height,int xPoint, int yPoint);
	private native void cvFisheyeEffect(int[] ImageArray, int width,
			int height,int xPoint, int yPoint);
	
	public Bitmap Noraml(Bitmap oriImage) {
		width = oriImage.getWidth();
		height = oriImage.getHeight();
		ImageArray = null;
		ImageArray = new int[width * height];

		oriImage.getPixels(ImageArray, 0, width, 0, 0, width, height);
		
		return oriImage;
	}
	
	public Bitmap SketchEffect1(Bitmap oriImage) {
		width = oriImage.getWidth();
		height = oriImage.getHeight();
		ImageArray = null;
		ImageArray = new int[width * height];

		oriImage.getPixels(ImageArray, 0, width, 0, 0, width, height);
		
		cvSketchEffect1(ImageArray, width, height);
		if(oriImage != null)
			oriImage.recycle();
		oriImage = null;
		
		
		oriImage = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);

		oriImage.setPixels(ImageArray, 0, width, 0, 0, width, height);
		
		
		return oriImage;
	}
	public Bitmap SketchEffect2(Bitmap oriImage) {
		width = oriImage.getWidth();
		height = oriImage.getHeight();
		
		ImageArray = null;
		ImageArray = new int[width * height];

		oriImage.getPixels(ImageArray, 0, width, 0, 0, width, height);
		
		cvSketchEffect2(ImageArray, width, height);
		if(oriImage != null)
			oriImage.recycle();
		oriImage = null;
		
		
		oriImage = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);

		oriImage.setPixels(ImageArray, 0, width, 0, 0, width, height);
		
		
		return oriImage;
	}

	public Bitmap GrayEffect(Bitmap oriImage) {
		Bitmap Image = oriImage;
		width = Image.getWidth();
		height = Image.getHeight();
		// if(Ret_Image == null){
		// Ret_Image = Bitmap.createBitmap(width, height,
		// Bitmap.Config.ARGB_8888);
		ImageArray = null;
		ImageArray = new int[width * height];
		// }
		Image.getPixels(ImageArray, 0, width, 0, 0, width, height);
		cvGrayEffect(ImageArray, width, height);
		if(Image != null)
			Image.recycle();
		Image = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);

		Image.setPixels(ImageArray, 0, width, 0, 0, width, height);
		if(oriImage != null)
			oriImage.recycle();
		return Image;
	}

	public Bitmap OilPaintEffect(Bitmap oriImage) {
		Bitmap Image = oriImage;
		width = Image.getWidth();
		height = Image.getHeight();
		// if(Ret_Image == null){
		// Ret_Image = Bitmap.createBitmap(width, height,
		// Bitmap.Config.ARGB_8888);
		ImageArray = null;
		ImageArray = new int[width * height];
		// }
		Image.getPixels(ImageArray, 0, width, 0, 0, width, height);
		cvOilPaintEffect(ImageArray, width, height, 2, 80);
		if(Image != null)
			Image.recycle();
		Image = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);

		Image.setPixels(ImageArray, 0, width, 0, 0, width, height);
		if(oriImage != null)
			oriImage.recycle();

		return Image;
	}

	public Bitmap WaterColorEffect(Bitmap oriImage) {
		Bitmap Image = oriImage;
		width = Image.getWidth();
		height = Image.getHeight();
		// if(Ret_Image == null){
		// Ret_Image = Bitmap.createBitmap(width, height,
		// Bitmap.Config.ARGB_8888);
		ImageArray = null;
		ImageArray = new int[width * height];
		// }
		Image.getPixels(ImageArray, 0, width, 0, 0, width, height);
		cvWaterColorEffect(ImageArray, width, height);
		if(Image != null)
			Image.recycle();
		Image = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
		Image.setPixels(ImageArray, 0, width, 0, 0, width, height);
		if(oriImage != null)
			oriImage.recycle();

		return Image;
	}
	
	public Bitmap RainDropEffect(CustomView CV , int xPoint,int yPoint) {//Bitmap oriImage , int xPoint,int yPoint) {
		Bitmap Image = CV.m_Draw.m_DrawBitmap;
		int Width = Image.getWidth();
		int Height = Image.getHeight();

		if(Array == null)
			Array = new int[Width * Height];

		if(Image != null)
		Image.getPixels(Array, 0, Width, 0, 0, Width, Height);
		cvRainDropEffect(Array, Width, Height, xPoint, yPoint);
			Image.eraseColor(0x00000000);
		
		Bitmap TempImage;
		if(CV.m_bVisibleEdge){
			TempImage = CV.m_Draw.m_BGAnimationBitmap; 
		}else{
			TempImage = CV.m_Draw.m_BackgroundBitmap; 
		}
		
		if(TempImage != null)
			TempImage.recycle();
		if(CV.m_bVisibleEdge){
			CV.m_Draw.m_BGAnimationBitmap = Bitmap.createBitmap(Width, Height, Bitmap.Config.ARGB_8888); 
			CV.m_Draw.m_BGAnimationBitmap.setPixels(Array, 0, Width, 0, 0, Width, Height);
			return CV.m_Draw.m_BGAnimationBitmap;
		}else{
			CV.m_Draw.m_BackgroundBitmap = Bitmap.createBitmap(Width, Height, Bitmap.Config.ARGB_8888);
			CV.m_Draw.m_BackgroundBitmap.setPixels(Array, 0, Width, 0, 0, Width, Height);
			return CV.m_Draw.m_BackgroundBitmap;
		}
	}
	
	public Bitmap LightEffect(CustomView CV , int xPoint,int yPoint) {//Bitmap oriImage , int xPoint,int yPoint) {
		
		Bitmap Image = CV.m_Draw.m_DrawBitmap;
		int Width = Image.getWidth();
		int Height = Image.getHeight();
		// if(Ret_Image == null){
		// Ret_Image = Bitmap.createBitmap(width, height,
		// Bitmap.Config.ARGB_8888);
		if(Array == null){
			Array = new int[Width * Height];
		}
		// }
		Image.getPixels(Array, 0, Width, 0, 0, Width, Height);
		cvLightEffect(Array, Width, Height, xPoint, yPoint);
		//Image.recycle();
		if(Image != null)
			Image.eraseColor(0x00000000);
		
		Bitmap TempImage;
		if(CV.m_bVisibleEdge){
			TempImage = CV.m_Draw.m_BGAnimationBitmap; 
		}else{
			TempImage = CV.m_Draw.m_BackgroundBitmap; 
		}
		
		if(TempImage != null)
			TempImage.recycle();
		if(CV.m_bVisibleEdge){
			CV.m_Draw.m_BGAnimationBitmap = Bitmap.createBitmap(Width, Height, Bitmap.Config.ARGB_8888); 
			CV.m_Draw.m_BGAnimationBitmap.setPixels(Array, 0, Width, 0, 0, Width, Height);
			return CV.m_Draw.m_BGAnimationBitmap;
		}else{
			CV.m_Draw.m_BackgroundBitmap = Bitmap.createBitmap(Width, Height, Bitmap.Config.ARGB_8888);
			CV.m_Draw.m_BackgroundBitmap.setPixels(Array, 0, Width, 0, 0, Width, Height);
			return CV.m_Draw.m_BackgroundBitmap;
		}
	}
	
public Bitmap FisheyeEffect(CustomView CV , int xPoint,int yPoint) {//Bitmap oriImage , int xPoint,int yPoint) {
		
		Bitmap Image = CV.m_Draw.m_DrawBitmap;
		int Width = Image.getWidth();
		int Height = Image.getHeight();
		// if(Ret_Image == null){
		// Ret_Image = Bitmap.createBitmap(width, height,
		// Bitmap.Config.ARGB_8888);
		if(Array == null)
			Array = new int[Width * Height];
		// }
		Image.getPixels(Array, 0, Width, 0, 0, Width, Height);
		cvFisheyeEffect(Array, Width, Height, xPoint, yPoint);
		//Image.recycle();
		if(Image != null)
			Image.eraseColor(0x00000000);

		Bitmap TempImage;
		if(CV.m_bVisibleEdge){
			TempImage = CV.m_Draw.m_BGAnimationBitmap; 
		}else{
			TempImage = CV.m_Draw.m_BackgroundBitmap; 
		}
		
		if(TempImage != null)
			TempImage.recycle();
		if(CV.m_bVisibleEdge){
			CV.m_Draw.m_BGAnimationBitmap = Bitmap.createBitmap(Width, Height, Bitmap.Config.ARGB_8888); 
			CV.m_Draw.m_BGAnimationBitmap.setPixels(Array, 0, Width, 0, 0, Width, Height);
			return CV.m_Draw.m_BGAnimationBitmap;
		}else{
			CV.m_Draw.m_BackgroundBitmap = Bitmap.createBitmap(Width, Height, Bitmap.Config.ARGB_8888);
			CV.m_Draw.m_BackgroundBitmap.setPixels(Array, 0, Width, 0, 0, Width, Height);
			return CV.m_Draw.m_BackgroundBitmap;
		}
//		ProcessImage = Bitmap.createBitmap(Width, Height, Bitmap.Config.ARGB_8888);

//		ProcessImage.setPixels(Array, 0, Width, 0, 0, Width, Height);
		
//		return ProcessImage;
	}
}
