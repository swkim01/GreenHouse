package test.primium;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;

public class FourthPageActivity extends Activity{
	
	private BtnBackground mBtnBackground;
	private LinearLayout SelectLayout;
	private Bitmap SelectBackground;
	private WindowManager wm;
	private BitmapFactory.Options options;
	private Display disp;
	private boolean Process;
	private Button NormalModeBtn;
	private Button SketchModeBtn1;
	private Button SketchModeBtn2;
	private Button GrayModeBtn;
	private Button OilPaintModeBtn;
	private Button WaterColorModeBtn;
	private Intent intent;
	private int Mode;
	private String StrPath;
	private int Position; 
	private int Select;
	private MediaPlayer mPlayer_Click;
	private boolean btnflag;
	@Override
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.selectmode);
		
		intent = getIntent();
		StrPath = intent.getStringExtra("ImagePath");
		Position = intent.getIntExtra("ImageNum", 0);
		Select = intent.getIntExtra("select",0);
		
		
		mBtnBackground = new BtnBackground();
		SelectLayout = (LinearLayout)findViewById(R.id.SelectMode);
		NormalModeBtn = (Button)findViewById(R.id.NormalMode);
		SketchModeBtn1 = (Button)findViewById(R.id.SketchMode1);
		SketchModeBtn2 = (Button)findViewById(R.id.SketchMode2);
		GrayModeBtn = (Button)findViewById(R.id.GrayMode);
		OilPaintModeBtn =(Button)findViewById(R.id.OilPaintingMode);
		WaterColorModeBtn = (Button)findViewById(R.id.WaterColorMode);
		
		NormalModeBtn.setOnClickListener(selectMode);
		SketchModeBtn1.setOnClickListener(selectMode);
		SketchModeBtn2.setOnClickListener(selectMode);
		GrayModeBtn.setOnClickListener(selectMode);
		OilPaintModeBtn.setOnClickListener(selectMode);
		WaterColorModeBtn.setOnClickListener(selectMode);
		mPlayer_Click = MediaPlayer.create(this, R.raw.click);
		Process = false;
		Mode = Main.None;
		
		System.out.println("FourthPageActivity.onCreate()" + disp);
		System.out.println("FourthPageActivity.onCreate()");
		btnflag = false;
		wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
		disp = wm.getDefaultDisplay();
		
		System.out.println("FourthPageActivity.onStart()"+ disp);
		options = new BitmapFactory.Options();
		BitmapOption.getSampleSize(options, disp, null, getResources(),
				R.drawable.selectbg);
		SelectBackground = BitmapFactory.decodeResource(getResources(),
				R.drawable.selectbg, options);
		SelectLayout.setBackgroundDrawable(new BitmapDrawable(SelectBackground));
		
		NormalModeBtn.setBackgroundDrawable(
				mBtnBackground.normalBtnBackground(this ,disp));
		SketchModeBtn1.setBackgroundDrawable(
				mBtnBackground.sketch1BtnBackground(this ,disp));
		SketchModeBtn2.setBackgroundDrawable(
				mBtnBackground.sketch2BtnBackground(this ,disp));
		GrayModeBtn.setBackgroundDrawable(
				mBtnBackground.grayBtnBackground(this ,disp));
		OilPaintModeBtn.setBackgroundDrawable(
				mBtnBackground.oilPaintBtnBackground(this ,disp));
		WaterColorModeBtn.setBackgroundDrawable(
				mBtnBackground.waterColorBtnBackground(this ,disp));
	}
	
	public void onStart(){
		super.onStart();
		
	}
	
	@Override
	public void onResume(){
		super.onResume();
		
		System.out.println("FourthPageActivity.onResume()"+ disp);
		
		Intent svc = new Intent(this, BackgroundSoundService.class);
		startService(svc);
		
//		try {
//			BackgroundSoundService.mp.start();
//		} catch (Exception e) {
//			Intent svc = new Intent(this , BackgroundSoundService.class);
//			startService(svc);
//			e.printStackTrace();
//		}
		
		intent = new Intent(FourthPageActivity.this,GalleryViewActivity.class);
	}
	
	@Override
	public void onPause(){
		super.onPause();
		
		System.out.println("FourthPageActivity.onPause()"+ disp);
		
		if(!Process && BackgroundSoundService.mp.isPlaying()){
			System.out.println("FourthPageActivity onPause BGM Stop");
			BackgroundSoundService.mp.pause();
		}
	}
	public void onStop(){
		super.onStop();
		
		System.out.println("FourthPageActivity.onStop()"+ disp);
		
	}
	@Override
	public void onDestroy(){
		super.onDestroy();
		
		SelectLayout.setBackgroundDrawable(null);
		SelectBackground.recycle();
		mBtnBackground.recycleBitmap3();
		System.out.println("FourthPageActivity.onDestroy()"+ disp);
	}
	
	private Button.OnClickListener selectMode = new View.OnClickListener() {

		@Override
		public void onClick(View v) {
			if(!btnflag){
				mPlayer_Click.start();
				switch (v.getId()) {
				case R.id.NormalMode:
					Mode = Main.NomalMode;
					break;
				case R.id.GrayMode:
					Mode = Main.GrayMode;
					break;
				case R.id.SketchMode1:
					Mode = Main.SketchMode1;
					break;
				case R.id.SketchMode2:
					Mode = Main.SketchMode2;
					break;
				case R.id.OilPaintingMode:
					Mode = Main.OilPaintingMode;
					break;
				case R.id.WaterColorMode:
					Mode = Main.WaterColorMode;
					break;
				}
				Process = true;
				intent = new Intent(FourthPageActivity.this,GalleryViewActivity.class);
				intent.putExtra("ImageNum", Position);
				intent.putExtra("ImagePath", StrPath);
				intent.putExtra("select", Select);
				intent.putExtra("Mode", Mode);
				finish();
				startActivity(intent);
				btnflag = true;
			}
		}
	};
	
	@Override
	public void onBackPressed() {
//		super.onBackPressed();
		finish();
		Intent i = null;
		if(Select == 1)
			i = new Intent(this , SecondPageActivity.class);
		else if(Select == 2)
			i = new Intent(this , ThirdPageActivity.class);
		startActivity(i);
		mPlayer_Click.start();
		Process = true;
	}
}
