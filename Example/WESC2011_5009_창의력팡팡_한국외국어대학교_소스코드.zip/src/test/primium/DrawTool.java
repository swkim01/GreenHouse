package test.primium;

import test.primium.CustomView.BRUSH;
import android.graphics.*;

public class DrawTool {
	public DrawTool() {
		
		m_PaletteBitmap 			= null;
		m_EmptyPaletteImage 	= null;
		m_AnimationBitmap 		= null;
		m_DrawBitmap 				= null;
		m_PasteBitmap 				= null;
		m_MozaicBitmap 			= null;
		m_BrushBitmap 				= null;
		m_BackgroundBitmap 		= null;
		m_BGAnimationBitmap 	= null;
		
		m_PaletteImage 			= null;
		
		m_BrushOption = new BrushOption();
		
		m_bVisiablePallete = false;
		m_bClickPallete = false;
		m_bDoubleClickPallete = false;
		m_bLongClickPallete = false;
		m_bDragPallete = false;
		m_bSearchPallete = false;
		
		m_BrushPaint = new Paint();
		m_BackgroundPaint = new Paint();
		m_SidePalettePaint = new Paint();
		m_CenterPalettePaint = new Paint();
		m_SizePalettePaint = new Paint();
		m_ColorPaperPaint = new Paint();
		
		m_PastePaint = new Paint();
		
		 m_Matrix = new Matrix();
	}
	
	public class BrushOption {
		public BrushOption() {
			m_Path = new Path();
		}
		public BRUSH m_Brush;
		public BlurMaskFilter m_Blur;
		public EmbossMaskFilter m_Emboss;
		
		public Path m_Path;

		public Bitmap m_ChangeBrush;
		
		public boolean m_bEraser = false;
	}
	
	public void recycleBitmap()
	{
		m_AnimationBitmap.recycle();
		m_DrawBitmap.recycle();
		m_PasteBitmap.recycle();
		m_MozaicBitmap.recycle();
		m_BrushBitmap.recycle();
		m_BackgroundBitmap.recycle();
		
		if(m_BGAnimationBitmap != null)
			m_BGAnimationBitmap.recycle();
		if(m_PaletteBitmap != null)
			m_PaletteBitmap.recycle();	
		m_EmptyPaletteImage.recycle();
		m_PaletteImage.recycle();
		
		m_AnimationBitmap = null;
		m_DrawBitmap = null;
		m_PasteBitmap = null;
		m_MozaicBitmap = null;
		m_BrushBitmap = null;
		m_BackgroundBitmap = null;
		m_BGAnimationBitmap = null;
		
		m_PaletteBitmap = null;
		m_PaletteImage = null;
		m_EmptyPaletteImage = null;
	}
	
	public Paint m_BrushPaint;
	
	public Paint m_BackgroundPaint;
	
	public Paint m_SidePalettePaint;
	public Paint m_CenterPalettePaint;
	
	public Paint m_SizePalettePaint;
	
	public Paint m_PastePaint;
	
	public Paint m_ColorPaperPaint;

	int m_nGetPixel;
	int m_nAlpha, m_nRed, m_nGreen, m_nBlue;

	public int m_nDisplayWidth;
	public int m_nDisplayHeight;

	public Matrix m_Matrix;
	int m_nAngle;

	public Bitmap m_PaletteBitmap;
	public Bitmap m_EmptyPaletteImage;
	public Bitmap m_AnimationBitmap;
	public Bitmap m_DrawBitmap;
	public Bitmap m_PasteBitmap;
	public Bitmap m_MozaicBitmap;
	public Bitmap m_BrushBitmap;
	public Bitmap m_BackgroundBitmap;
	public Bitmap m_BGAnimationBitmap;
	
	public Bitmap m_PaletteImage;
	
	public boolean m_bVisiablePallete;
	public boolean m_bClickPallete;
	public boolean m_bDoubleClickPallete;
	public boolean m_bLongClickPallete;
	public boolean m_bDragPallete;
	public boolean m_bSearchPallete;

	public BrushOption m_BrushOption;
}