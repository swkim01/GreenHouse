package test.primium;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;

public class MenuActivity extends Activity {

	private boolean EndCheck = false;
	private Bitmap MenuBG;
	private Intent intent;
	private BtnBackground mBtnBackground;
	private MediaPlayer mPlayer_Click;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		setContentView(R.layout.menu);
		mBtnBackground = new BtnBackground();
		intent = new Intent();
		mBtnBackground.mainBtnBackground(this,(Button)findViewById(R.id.mainScreenBtn));
		mBtnBackground.finishBtnBackground(this,(Button)findViewById(R.id.finishBtn));
		mBtnBackground.saveBtnBackground(this,(Button)findViewById(R.id.saveBtn));
		MenuBG = BitmapFactory.decodeResource(getResources(), R.drawable.menubackground);
		findViewById(R.id.menuLayout).setBackgroundDrawable(new BitmapDrawable(MenuBG));
		mPlayer_Click = MediaPlayer.create(this, R.raw.click);
	
		findViewById(R.id.mainScreenBtn).setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				intent.putExtra("MenuMode", 0);
				mPlayer_Click.start();
				setResult(RESULT_OK, intent);
				findViewById(R.id.menuLayout).setVisibility(View.INVISIBLE);
				mBtnBackground.recycleBitmap5();
				MenuBG.recycle();
				EndCheck = true;
				finish();
			}
		});
		findViewById(R.id.finishBtn).setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				intent.putExtra("MenuMode", 1);
				mPlayer_Click.start();
				setResult(RESULT_OK, intent);
				findViewById(R.id.menuLayout).setVisibility(View.INVISIBLE);
				mBtnBackground.recycleBitmap5();
				MenuBG.recycle();
				EndCheck = true;
				finish();
			}
		});
	
		findViewById(R.id.saveBtn).setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				mPlayer_Click.start();
				final LinearLayout MenuL = (LinearLayout)findViewById(R.id.menuLayout);
				final EditText ET = (EditText)findViewById(R.id.saveName);
				final LinearLayout SaveL = (LinearLayout)findViewById(R.id.saveLayout);
				MenuL.setVisibility(View.INVISIBLE);
				SaveL.setVisibility(View.VISIBLE);
				findViewById(R.id.saveOKBtn).setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						String FileName = null;
						FileName = ET.getText().toString();
						intent.putExtra("MenuMode", 2);
						intent.putExtra("FileName", FileName);						
						SaveL.setVisibility(View.INVISIBLE);
						mPlayer_Click.start();
						setResult(RESULT_OK, intent);
						mBtnBackground.recycleBitmap5();
						MenuBG.recycle();
						EndCheck = true;
						finish();
					}
				});
				findViewById(R.id.saveCancleBtn).setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						SaveL.setVisibility(View.INVISIBLE);
						intent.putExtra("MenuMode", 3);
						mPlayer_Click.start();
						setResult(RESULT_OK, intent);
						mBtnBackground.recycleBitmap5();
						MenuBG.recycle();
						EndCheck = true;
						finish();
					}
				});
			}
		});
	
	
	
	
	}
	@Override
	public void onResume()
	{
		super.onResume();
		
		Intent svc = new Intent(this, BackgroundSoundService.class);
		startService(svc);
//		BackgroundSoundService.mp.start();
	}
	@Override
	public void onPause(){
		super.onPause();
		if(!EndCheck)
			BackgroundSoundService.mp.pause();
	}
	@Override
	public void onBackPressed() {
		intent.putExtra("MenuMode", 3);
		setResult(RESULT_OK, intent);
		finish();
	}
}

