package test.primium;

import java.io.*;

import android.content.*;
import android.graphics.Bitmap.CompressFormat;
import android.net.*;
import android.os.*;

public class SaveFile {

	public Context m_Context;

	public SaveFile(Context context) {
		m_Context = context;
	}

	public void SaveImage(CustomView CV , String Name) {
		// http://canon110.tistory.com/entry/%EC%95%88%EB%93%9C%EB%A1%9C%EC%9D%B4%EB%93%9C-%EB%AF%B8%EB%94%94%EC%96%B4-%EC%8A%A4%EC%BA%90%EB%8B%9D-DB-%EC%86%8C%EC%8A%A4-%ED%8F%AC%ED%95%A8
		String fileName;
		if(Name != null)
			fileName = "/sdcard/dcim/camera/"
				+ Name + ".jpg";
		else
			fileName = "/sdcard/dcim/camera/"
				+ String.valueOf(System.currentTimeMillis())  + ".jpg";
		File saveFile = new File(fileName);
		FileOutputStream out = null;

		try {
			CV.m_Draw.m_DrawBitmap.eraseColor(0xFFFFFFFF);

			CV.m_DrawCanvas
					.drawBitmap(CV.m_Draw.m_BackgroundBitmap, 0, 0, null);
			CV.m_DrawCanvas.drawBitmap(CV.m_Draw.m_BrushBitmap, 0, 0, null);
			CV.m_DrawCanvas.drawBitmap(CV.m_Draw.m_MozaicBitmap, 0, 0, null);
			CV.m_DrawCanvas.drawBitmap(CV.m_Draw.m_AnimationBitmap, 0, 0, null);

			saveFile.createNewFile();

			out = new FileOutputStream(saveFile);

			CV.m_Draw.m_DrawBitmap.compress(CompressFormat.JPEG, 100, out);

			CV.m_Draw.m_DrawBitmap.eraseColor(0x00000000);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				out.flush();
				out.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		final BroadcastReceiver mReceiver = new BroadcastReceiver() {
			@Override
			public void onReceive(Context context, Intent intent) {
				if (intent.getAction().equals(
						Intent.ACTION_MEDIA_SCANNER_STARTED)) {
				} else if (intent.getAction().equals(
						Intent.ACTION_MEDIA_SCANNER_FINISHED)) {
				} else if (intent.getAction().equals(
						Intent.ACTION_MEDIA_SCANNER_SCAN_FILE)) {
				}
			}
		};

		IntentFilter intentFilter = new IntentFilter();
		intentFilter.addAction(Intent.ACTION_MEDIA_SCANNER_STARTED);
		intentFilter.addAction(Intent.ACTION_MEDIA_SCANNER_FINISHED);
		intentFilter.addAction(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
		intentFilter.addDataScheme("file");
		m_Context.registerReceiver(mReceiver, intentFilter);

		m_Context.sendBroadcast(new Intent(Intent.ACTION_MEDIA_MOUNTED, Uri
				.parse("file://"
						+ Environment.getExternalStorageDirectory()
								.getAbsolutePath())));
	}
	

}
