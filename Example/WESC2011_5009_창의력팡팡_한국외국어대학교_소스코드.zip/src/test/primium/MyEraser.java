package test.primium;

import test.primium.CustomView.BRUSH;
import android.content.*;
import android.graphics.*;
import android.graphics.Bitmap.Config;
import android.view.*;

public class MyEraser {
	Context m_Context;

	public static final int NUMBER = 4;
	public Bitmap[] m_SideEraserBMP = new Bitmap[NUMBER];
	public Bitmap m_CenterEraserBMP;
	
	public static final int TOUCH_TOLERANCE = 4;

	public static final float RADIUS = 30;

	public static final int CENTER = -1;
	public static final int ERASER_BRUSH = 0;
	public static final int ERASER_MOZAIC = 1;
	public static final int CLEAR_BRUSH = 2;
	public static final int CLEAR_MOSAIC = 3;

	int m_nFinalSelectItem = 0;

	public void recycleBitmap() {
		for (int i = 0; i < m_SideEraserBMP.length; i++){
			m_SideEraserBMP[i].recycle();
			m_SideEraserBMP[i] = null;
		}
		m_SideEraserBMP = null;
	}

	public MyEraser(Context context) {
		m_Context = context;

		int resizeNum = 9;
		for (int n = 0; n < NUMBER; n++) {
			m_SideEraserBMP[n] = Main.ResizeOptions(m_Context, R.drawable.eraser00 + n, resizeNum);
		}

		m_CenterEraserBMP = m_SideEraserBMP[0];
	}
	
	public void TouchStart_EraserBrush(float x, float y, CustomView CV)
	{
		CV.m_Draw.m_BrushOption.m_Path.reset();
		CV.m_Draw.m_BrushOption.m_Path.moveTo(x, y);
		CV.m_X = x;
		CV.m_Y = y;
		
		return ;
	}
	
	public void TouchMove_EraserBrush(float x, float y, CustomView CV)
	{
		float dx = Math.abs(x - CV.m_X);
		float dy = Math.abs(y - CV.m_Y);
		if (dx >= TOUCH_TOLERANCE || dy >= TOUCH_TOLERANCE) {

			CV.m_Draw.m_BrushOption.m_Path.quadTo(CV.m_X, CV.m_Y, (x + CV.m_X) / 2,
					(y + CV.m_Y) / 2);

			if (CV.m_Draw.m_BrushOption.m_bEraser) {
				CV.m_BrushCanvas.drawPath(CV.m_Draw.m_BrushOption.m_Path,
						CV.m_Draw.m_BrushPaint);
			}
			
			CV.m_X = x;
			CV.m_Y = y;
		}
		
		return ;
	}
	
	public void TouchUp_EraserBrush(float x, float y, CustomView CV)
	{
		CV.m_Draw.m_BrushOption.m_Path.lineTo(CV.m_X, CV.m_Y);
		CV.m_BrushCanvas.drawPath(CV.m_Draw.m_BrushOption.m_Path, CV.m_Draw.m_BrushPaint);
		CV.m_Draw.m_BrushOption.m_Path.reset();
		return ;
	}

	public void TouchUp_EraserMozaic(CustomView CV) {
		CV.m_Draw.m_BrushPaint.setAlpha(0);


		if (CV.m_MyMozaic.m_CurrentLinkedList.size() == 0) {
			return;
		} else {
			
			CV.m_MyMozaic.m_CurrentLinkedList.removeLast();
			
			CV.m_Draw.m_MozaicBitmap.eraseColor(0x00000000);
			
			CV.m_MyMozaic.PrintingMozaic(CV);
		}
	}
	
	public void VisiablePallete(float x, float y, CustomView CV) {
		CustomView.m_bCheckCenter = CV.m_PaletteMethods.CheckCenter(x, y,
				CV.m_PaletteMethods.m_CenterPoint.x,
				CV.m_PaletteMethods.m_CenterPoint.y, RADIUS);

		if (CustomView.m_bCheckCenter) {
			CV.m_PaletteMethods.m_PrePoint.x = (int) x;
			CV.m_PaletteMethods.m_PrePoint.y = (int) y;

			CV.m_PaletteMethods.m_nSelectItemIndex = CENTER;

			return;
		}

		for (int n = 0; n < CV.m_PaletteMethods.m_nItemNum; n++) {
			if (CV.m_PaletteMethods.m_CurrentPoint[n].y > CV.m_PaletteMethods.m_CenterPoint.y)
				continue;
			CustomView.m_bCheckCenter = CV.m_PaletteMethods.CheckCenter(x, y,
					CV.m_PaletteMethods.m_CurrentPoint[n].x,
					CV.m_PaletteMethods.m_CurrentPoint[n].y, RADIUS);

			if (CustomView.m_bCheckCenter) {
				CV.m_PaletteMethods.m_nSelectItemIndex = n;
				break;
			}
		}

		CV.m_PaletteMethods.m_PrePoint.x = (int) x;
		CV.m_PaletteMethods.m_PrePoint.y = (int) y;
		return;
	}

	public void SingleTapConfirmed(MotionEvent e, CustomView CV) {
		if(CV.m_PaletteMethods.m_nSelectItemIndex > NUMBER)
		{
			return;
		}
		CustomView.brush = BRUSH.Normal;
		SelectBrush(CV.m_PaletteMethods.m_nSelectItemIndex, CV);

		if (CV.m_PaletteMethods.m_nSelectItemIndex != CENTER) {
			m_nFinalSelectItem = CV.m_PaletteMethods.m_nSelectItemIndex;
			m_CenterEraserBMP = m_SideEraserBMP[m_nFinalSelectItem];
		}
		CV.m_PaletteMethods.m_CenterBitmap = m_CenterEraserBMP;
		
		CV.m_Draw.m_BrushOption.m_bEraser = true;
		CV.m_Draw.m_bVisiablePallete = false;
		
		CV.invalidate();
		return;
	}

	public void SelectBrush(int nIndex, CustomView CV) {
		switch (nIndex) {
		case CENTER:
			SelectBrush(m_nFinalSelectItem, CV);
			break;

		case ERASER_BRUSH:
			CustomView.brush = BRUSH.Eraser_Brush;
			CV.m_Draw.m_BrushPaint.setMaskFilter(null);
			CV.m_Draw.m_BrushPaint.setXfermode(new PorterDuffXfermode(
					PorterDuff.Mode.CLEAR));
			break;

		case ERASER_MOZAIC:
			CustomView.brush = BRUSH.Eraser_Mozaic;
			break;

		case CLEAR_BRUSH:
			CustomView.brush = BRUSH.Clear_Brush;
			CV.m_Draw.m_BrushPaint.setMaskFilter(null);
			CV.m_Draw.m_BrushPaint.setXfermode(new PorterDuffXfermode(
					PorterDuff.Mode.CLEAR));
			if(CV.m_bVisibleEdge)
				CV.m_Draw.m_BGAnimationBitmap.eraseColor(0xFFFFFFFF);
			CV.m_Draw.m_BrushBitmap.eraseColor(0x00000000);
			CV.m_Draw.m_MozaicBitmap.eraseColor(0x00000000);
			CV.m_Draw.m_PasteBitmap.eraseColor(0x00000000);
			CV.m_Draw.m_DrawBitmap.eraseColor(0x00000000);
			CV.m_Draw.m_AnimationBitmap.eraseColor(0x00000000);
			int width =JNIMethods.width;
			int height =JNIMethods.height;
			Bitmap RecycleImage = CV.m_Draw.m_BackgroundBitmap;
			RecycleImage.recycle();
			Bitmap CreateImage = Bitmap.createBitmap(JNIMethods.ImageArray, width, height, Config.ARGB_8888);
			CV.m_Draw.m_BackgroundBitmap = Bitmap.createScaledBitmap(CreateImage, CV.JNI_Width, CV.JNI_Height, false);
			CreateImage.recycle();
			CV.m_Draw.m_BrushPaint.setAlpha(0);
			if (CV.m_MyMozaic.m_CurrentLinkedList.size() != 0) {
				CV.m_MyMozaic.m_CurrentLinkedList.removeAll(CV.m_MyMozaic.m_CurrentLinkedList);
				CV.m_Draw.m_MozaicBitmap.eraseColor(0x00000000);
			}
			break;
			
		case CLEAR_MOSAIC:
			CustomView.brush = BRUSH.Clear_Mozaic;
			CV.m_Draw.m_BrushPaint.setAlpha(0);

			if (CV.m_MyMozaic.m_CurrentLinkedList.size() != 0) {
				CV.m_MyMozaic.m_CurrentLinkedList.removeAll(CV.m_MyMozaic.m_CurrentLinkedList);
				CV.m_Draw.m_MozaicBitmap.eraseColor(0x00000000);
			}
			break;
		}
	}

	public void Initialization(CustomView CV) {
		CV.m_PaletteMethods.m_nItemNum = MyEraser.NUMBER;
		
		CV.m_PaletteMethods.m_SideBitmap = m_SideEraserBMP;
		CV.m_PaletteMethods.m_CenterBitmap = m_CenterEraserBMP;
	}
}
