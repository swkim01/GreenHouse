package test.primium;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.IBinder;

public class BackgroundSoundService extends Service {
	 
	public static MediaPlayer mp;
	private MusicThread mThread;
	
    @Override
    public IBinder onBind(Intent arg0) {
            // TODO Auto-generated method stub
            return null;
    }
    
@Override
public int onStartCommand(Intent intent, int flags, int startId) {
	// TODO Auto-generated method stub
	
	if(mp == null){
		mp = MediaPlayer.create(getBaseContext(), R.raw.pangbgm);
	//	mThread.start();
		
		mp.setLooping(true);
	}
	mp.start();    
	
	return super.onStartCommand(intent, flags, startId);
}

//    @Override
//    public void onStart(Intent intent, int startId) {
//            // TODO
//    	mp = MediaPlayer.create(getBaseContext(), R.raw.pangbgm);
//    	mThread.start();
//    }
    
    @Override
    public void onCreate() {
            super.onCreate();
//            mThread = new MusicThread();
//            mThread.setDaemon(true);
    }
    
    @Override
    public void onDestroy() {
    	mp.release();
    	mp = null;
    }
    
    @Override
    public void onLowMemory() {
    }
    
    class MusicThread extends Thread{
    	@Override
		public void run(){
    		mp.start();        
    		mp.setLooping(true);
    	}
    }

}