package test.primium;

import android.content.*;
import android.view.*;

public class MySize {
	Context m_Context;

	public static final int CENTER = -1;
	public static final int RADIUS = 50;

	public MySize(Context context) {
		m_Context = context;
	}

	public void Touch_Start(float x, float y, CustomView CV) {

	}

	public void VisiablePallete(float x, float y, CustomView CV) {
		CustomView.m_bCheckCenter = CV.m_PaletteMethods.CheckCenter(x, y,
				CV.m_PaletteMethods.m_CenterPoint.x,
				CV.m_PaletteMethods.m_CenterPoint.y, RADIUS);

		if (CustomView.m_bCheckCenter) {
			CV.m_PaletteMethods.m_nSelectItemIndex = CENTER;
		}

		CV.m_PaletteMethods.m_PrePoint.x = (int) x;
		CV.m_PaletteMethods.m_PrePoint.y = (int) y;
		return;
	}

	public void SingleTapConfirmed(MotionEvent e, CustomView CV) {
		if (CV.m_PaletteMethods.m_nSelectItemIndex == CENTER) {
			CV.m_Draw.m_BrushPaint
					.setStrokeWidth(CV.m_PaletteMethods.m_CurrentRadius * 2);
			CV.m_Draw.m_PastePaint
					.setStrokeWidth(CV.m_PaletteMethods.m_CurrentRadius * 2);
		}
		return;
	}

	public void Initialization(CustomView CV) {
	}
}
