package test.primium;

import java.io.*;

import test.primium.CustomView.PALETTE;
import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.MediaPlayer;
import android.net.*;
import android.os.*;
import android.view.*;
import android.view.ViewDebug.FlagToString;
import android.widget.*;

public class GalleryViewActivity extends Activity implements
		View.OnClickListener {

	
	public static boolean EndCheck = false;
	public LinearLayout BtnLayout;

	public Bitmap BtnLayoutBG;

	public Drawable mDrawable;

	public static Button BrushBtn;
	public static Button SizeChangeBtn;
	public static Button PalleteBtn;
	public static Button AniStickerBtn;
	public static Button MozaicBtn;
	public static Button EraseBtn;
	
	
	public static CustomView		m_CustomView;
	public JNIMethods		jniMethods;
	public Uri				currImageURI;
	public int				m_ImageMode;
	public String			strPath;
	public String			path;
	public static int		BaseID;
	public MediaPlayer mPlayer_DrawClick;
	
	
	public Bitmap testBitmap;
	
	Intent					intent;
	ThreadFunction			m_Thread;
	public ProgressDialog	dialog;
	public static BtnBackground mBtnBackground;
	int						SelectMode	= -1;
	public static boolean bEndFlag;
	public boolean bCameraImg = false;
	private MediaPlayer mPlayer_Click;
	
	private void recycleBitmap() {
		BtnLayout.setBackgroundDrawable(null);

		BtnLayoutBG.recycle();
	}
	

	@Override
	public void onCreate(Bundle savedInstanceState) {
		System.out.println("GalleryViewActivity.onCreate()");
		super.onCreate(savedInstanceState);
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		setContentView(R.layout.fifth);
		EndCheck = false;
		mBtnBackground = new BtnBackground();

		mPlayer_Click = MediaPlayer.create(this, R.raw.click);
		BtnLayout = (LinearLayout) findViewById(R.id.Btnlayout);

		BitmapFactory.Options BackGroundOptions = new BitmapFactory.Options();

		BackGroundOptions.inDither = true;
		BitmapOption.getSampleSize(BackGroundOptions, Main.disp, null,
				getResources(), R.drawable.board1);

		BitmapOption.getSampleSize(BackGroundOptions, Main.disp, null,
				getResources(), R.drawable.board2);
		BtnLayoutBG = BitmapFactory.decodeResource(getResources(),
				R.drawable.board2, BackGroundOptions);
		mDrawable = new BitmapDrawable(BtnLayoutBG);
		BtnLayout.setBackgroundDrawable(mDrawable);

		SizeChangeBtn = (Button)findViewById(R.id.Size);
		PalleteBtn = (Button)findViewById(R.id.Pallete);
		AniStickerBtn = (Button)findViewById(R.id.Animation);
		MozaicBtn = (Button)findViewById(R.id.Mozaic);
		EraseBtn = (Button)findViewById(R.id.Eraser);
		BrushBtn = (Button)findViewById(R.id.Brush);
		SizeChangeBtn.setOnClickListener(this);
		PalleteBtn.setOnClickListener(this);
		AniStickerBtn.setOnClickListener(this);
		MozaicBtn.setOnClickListener(this);
		EraseBtn.setOnClickListener(this);
		BrushBtn.setOnClickListener(this);

		mBtnBackground.brushBtnBackground(this, BrushBtn);
		mBtnBackground.palleteBtnBackground(this, PalleteBtn);
		mBtnBackground.eraserBtnBackground(this, EraseBtn);
		mBtnBackground.aniStickerBtnBackground(this, AniStickerBtn);
		mBtnBackground.mozaicBtnBackground(this, MozaicBtn);
		mBtnBackground.changeSizeBtnBackground(this, SizeChangeBtn);
		
		
		
		jniMethods = new JNIMethods();
		m_CustomView = (CustomView) findViewById(R.id.drawV);
		m_CustomView.m_Draw.m_nAngle = Main.disp.getRotation(); // Android 2.1

		intent = getIntent();

		m_Thread = new ThreadFunction(this, GalleryViewActivity.this);
		
		bEndFlag = false;
		
		dialog = ProgressDialog.show(this, "", "ImageLoding...", true, false);

		if (intent.getIntExtra("select", 0) == 1
				|| intent.getIntExtra("select", 0) == 2) {

			
			path = intent.getStringExtra("ImagePath");
			
			m_ImageMode = intent.getIntExtra("Mode", Main.NomalMode);
			
			m_CustomView.m_Draw.m_BackgroundBitmap = GetBitmap(Main.disp, path, -1,
					Main.disp.getRotation());
			if (m_ImageMode == Main.NomalMode)
			{
				m_Thread.SetItem(Main.NomalMode);
			} else if (m_ImageMode == Main.GrayMode)
			{
				m_Thread.SetItem(Main.GrayMode);
			} else if (m_ImageMode == Main.SketchMode1)
			{
				m_Thread.SetItem(Main.SketchMode1);
				testBitmap = Bitmap.createBitmap(Main.disp.getWidth(), Main.disp.getHeight(), Bitmap.Config.ARGB_8888);

			} else if (m_ImageMode == Main.SketchMode2)
			{
				m_Thread.SetItem(Main.SketchMode2);
				testBitmap = Bitmap.createBitmap(Main.disp.getWidth(), Main.disp.getHeight(), Bitmap.Config.ARGB_8888);
			} else if (m_ImageMode == Main.OilPaintingMode)
			{
				m_Thread.SetItem(Main.OilPaintingMode);
			} else if (m_ImageMode == Main.WaterColorMode)
			{
				m_Thread.SetItem(Main.WaterColorMode);
			}

			if (intent.getIntExtra("select", 0) == 1)
			{
				bCameraImg = true;
			}

			m_CustomView.destroyDrawingCache();
		} else if (intent.getIntExtra("select", 0) == 3) {
			m_ImageMode = Main.ServiceMode;
			BaseID = 0;

			BaseID = R.drawable.basicimage1
					+ (intent.getIntExtra("ImageNum", 1) - 1);
			m_CustomView.m_Draw.m_BackgroundBitmap = GetBitmap(Main.disp, null, BaseID,
					Main.disp.getRotation());
			testBitmap = Bitmap.createBitmap(m_CustomView.m_Draw.m_BackgroundBitmap);
//			testBitmap = Bitmap.createBitmap(Main.disp.getWidth(), Main.disp.getHeight(), Bitmap.Config.ARGB_8888);
			m_Thread.SetItem(Main.ServiceMode);
		}

		m_CustomView.m_bStartApp = true;
		m_CustomView.m_nFindMode = m_ImageMode;
		
		mPlayer_DrawClick = MediaPlayer.create(this, R.raw.click);
		intent = new Intent(this, Main.class);
	}

	@Override
	public void onDestroy() {
		System.out.println("GalleryViewActivity.onDestroy()");
		super.onDestroy();
		recycleBitmap();

		m_Thread.m_SenserManager.unregisterListener(m_Thread.m_SensorListener);
		m_Thread.m_StandardThread.setLoop(false);
		mDrawable = null;
		m_CustomView = null;
		jniMethods = null;
		currImageURI = null;
		strPath = null;
		

		m_ImageMode = 0;

		intent = null;
	}

	@Override
	public void onResume()
	{
		super.onResume();
		System.out.println("GalleryViewActivity.onResume()");
		if(bCameraImg == true)
		{
			new Handler().postDelayed(new Runnable() {
				@Override
				public void run() {
					File file = new File(path);
					file.delete();
					file = null;
					bCameraImg = false;
				}
			}, 3000);
		}
		
		Intent svc = new Intent(this, BackgroundSoundService.class);
		startService(svc);
//		BackgroundSoundService.mp.start();
	}
	@Override
	public void onPause(){
		System.out.println("GalleryViewActivity.onPause()");
		super.onPause();
		if(!bEndFlag)
			BackgroundSoundService.mp.pause();
	}
	
//	public boolean onCreateOptionsMenu(Menu menu){
//		super.onCreateOptionsMenu(menu);
//		MenuInflater inflater = getMenuInflater();
//		inflater.inflate(R.menu.menu, menu);
//		return true;
//	}
//	
//	
//	public boolean onOptionsItemSelected(MenuItem item){
//		switch(item.getItemId()){
//		case R.id.saveMenu:
//			final SaveFile m_SaveFile = new SaveFile(this);
//			final EditText ET = (EditText)findViewById(R.id.saveName);
//			final LinearLayout LL = (LinearLayout)findViewById(R.id.saveLayout);
//			LL.setVisibility(View.VISIBLE);
//			findViewById(R.id.saveOKBtn).setOnClickListener(new OnClickListener() {
//				@Override
//				public void onClick(View v) {
//					// TODO Auto-generated method stub
//					String FileName = null;
//					FileName = ET.getText().toString();
//					m_SaveFile.SaveImage(m_CustomView, FileName);
//					LL.setVisibility(View.INVISIBLE);
//				}
//			});
//			findViewById(R.id.saveCancleBtn).setOnClickListener(new OnClickListener() {
//				@Override
//				public void onClick(View v) {
//					// TODO Auto-generated method stub
//					LL.setVisibility(View.INVISIBLE);
//				}
//			});
//			return true;
//		}
//		return false;
//	}
	
	public Bitmap GetBitmap(Display disp, String strImagePath, int id,
			int nRotation) {

		Matrix matrix = new Matrix();

		Bitmap TempBitmap = null;
		BitmapFactory.Options options = new BitmapFactory.Options();
		options.inDither = true;
		// options.inSampleSize = 4
		BitmapOption.getSampleSize(options, disp, strImagePath, getResources(),
				id);
		if (id == -1 && strImagePath != null)
			TempBitmap = BitmapFactory.decodeFile(strImagePath, options);
		else
			TempBitmap = BitmapFactory.decodeResource(getResources(), id);
		
		Bitmap temp;
		temp = TempBitmap;

		if (TempBitmap.getWidth() < TempBitmap.getHeight()) {
			matrix.postRotate(-90);
			TempBitmap = Bitmap.createBitmap(temp, 0, 0, temp.getWidth(),
					temp.getHeight(), matrix, true);
			temp.recycle();
		}
		return TempBitmap;
	}

	@Override
	public void onClick(View v) {
		m_CustomView.m_Draw.m_BrushPaint.setAlpha(0xC0);

		if (m_CustomView.m_Draw.m_bVisiablePallete) {
			m_CustomView.m_Draw.m_bVisiablePallete = false;
			m_CustomView.m_Draw.m_PaletteBitmap.recycle();	
		} else {
			m_CustomView.m_Draw.m_bVisiablePallete = true;
			
			m_CustomView.m_Draw.m_PaletteBitmap = Bitmap.createBitmap(m_CustomView.JNI_Width, m_CustomView.JNI_Height,
					Bitmap.Config.ARGB_8888);
			
			m_CustomView.m_PaletteCanvas = new Canvas(m_CustomView.m_Draw.m_PaletteBitmap);
			m_CustomView.m_Draw.m_PaletteBitmap.eraseColor(0x00000000);
			
			m_CustomView.m_PaletteCanvas.drawBitmap(m_CustomView.m_Draw.m_PaletteImage,
					m_CustomView.m_PaletteMethods.m_CenterPoint.x,
					m_CustomView.m_PaletteMethods.m_CenterPoint.y, null);
			
						
			mPlayer_DrawClick.start();	
			switch (v.getId()) {
			case R.id.Brush:
				CustomView.palette = PALETTE.Brush;
				m_CustomView.m_MyBrush.Initialization(m_CustomView);
				break;
			case R.id.Pallete:
				CustomView.palette = PALETTE.Color;
				m_CustomView.m_MyColor.Initialization(m_CustomView);
				break;
			case R.id.Size:
				CustomView.palette = PALETTE.Size;
				m_CustomView.m_MySize.Initialization(m_CustomView);
				break;
			case R.id.Animation:
				CustomView.palette = PALETTE.Animation;
				m_CustomView.m_MyAnimation.Initialization(m_CustomView);
				break;
			case R.id.Mozaic:
				CustomView.palette = PALETTE.Mozaic;
				m_CustomView.m_MyMozaic.Initialization(m_CustomView);
				break;
			case R.id.Eraser:
				CustomView.palette = PALETTE.Eraser;
				m_CustomView.m_MyEraser.Initialization(m_CustomView);
				break;
			}

			m_CustomView.m_PaletteMethods.PaletteSearch(
					m_CustomView.m_PaletteMethods.m_PrePoint.x,
					m_CustomView.m_PaletteMethods.m_PrePoint.y,
					m_CustomView.m_PaletteMethods, m_CustomView.m_Draw,
					m_CustomView.m_PaletteCanvas);
		}
		m_CustomView.invalidate();
	}

	
	
	// @Override
	public void colorChanged(int color) {
		m_CustomView.m_Draw.m_BrushPaint.setColor(0xC0FFFFFF & color);
	}

	
	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		System.out.println("GalleryViewActivity.onActivityResult()");
		if (resultCode == RESULT_OK) {
			if (requestCode == 1) {
				int MenuMode = data.getIntExtra("MenuMode", -1);
				if(MenuMode != -1){
					switch(MenuMode){
					case 0:
						EndCheck = true;
						bEndFlag = true;
						m_CustomView.onDestroy();
						m_CustomView.destroyDrawingCache();
						m_CustomView = null;
						mBtnBackground.recycleBitmap4();
						intent = new Intent(this , FirstPageActivity.class);
						intent.putExtra("Cycle", true);
						finish();
						startActivity(intent);
						break;
					case 1:
						EndCheck = true;
						m_CustomView.onDestroy();
						m_CustomView.destroyDrawingCache();
						mBtnBackground.recycleBitmap4();
						BackgroundSoundService.mp.stop();
						Intent svc = new Intent(this , BackgroundSoundService.class);
						stopService(svc);
						m_CustomView = null;
						
//						ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
//						am.restartPackage(getPackageName());

						finish();
						break;
					case 2:
						final SaveFile m_SaveFile = new SaveFile(GalleryViewActivity.this);
						m_SaveFile.SaveImage(m_CustomView, data.getStringExtra("FileName"));
						break;
					case 3:
						break;
					}
				}
			}
		}
	}
	
	@Override
	public void onBackPressed() {
		mPlayer_DrawClick.start();	
		BaseGallery.recycleBitmap();
		
		Intent MenuIntent = new Intent(this, MenuActivity.class);
		bEndFlag = true;
		startActivityForResult(MenuIntent, 1);
	}
	


}
