package test.primium;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ViewFlipper;

public class Main extends Activity {

	public FrameLayout first;
	public LinearLayout second;
	public LinearLayout third;
	public static Button CameraBtn;
	public static Button AlbumBtn;
	public static Button GalleryBtn;
	public static Button BaseGalleryBtn;
	public Button firstBtn;
	public Button TutorailBtn;

	public ImageView firstImageView;
	public ViewFlipper flipper;
	public static int cur_page;
	public Bitmap Image;
	public ImageView imgView;
	public Uri currImageURI;
	public String strPath;

	public Uri mImageCaptureUri;
	public BtnBackground mBtnBackground;
	public Intent intent;
	public static Intent svc;
	public Drawable mBackgroundDrawable;
	public Drawable mDrawable;

	public Canvas mCanvas;
	private Bitmap FirstBackground = null;
	private Bitmap SecondBackground = null;
	private Bitmap ThirdBackground = null;
	private Bitmap Logo = null;
	private Bitmap RightLogo = null;
	private Bitmap LeftLogo = null;
	private Bitmap Title = null;
	public Bitmap SelectBG = null;
	public MediaPlayer mPlayer;
	

	public static final int None = -1;
	public static final int ServiceMode = 0;
	public static final int NomalMode = 1;
	public static final int GrayMode = 2;
	public static final int SketchMode1 = 3;
	public static final int SketchMode2 = 4;
	public static final int OilPaintingMode = 5;
	public static final int WaterColorMode = 6;
	public static final int ACCELEROMETER = 7;
	public int Mode = None;

	public static WindowManager wm;
	public BitmapFactory.Options options;
	public static Display disp;
	public Boolean Cycle = false;
	public Boolean ProcessMusic = false;
	public volatile static boolean ChangePageFlag;
	
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		svc = new Intent(this, BackgroundSoundService.class);
		mBtnBackground = new BtnBackground();
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		dalvik.system.VMRuntime.getRuntime().setTargetHeapUtilization(0.7f);

		setContentView(R.layout.main);

		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

		ProcessMusic = false;
		ChangePageFlag = false;

		wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
		disp = wm.getDefaultDisplay();
		options = new BitmapFactory.Options();
		BitmapOption.getSampleSize(options, disp, null, getResources(),
				R.drawable.background1);
	}

	@Override
	protected void onResume() {
		super.onResume();

		if (!Cycle) {
			final FrameLayout FL = (FrameLayout) findViewById(R.layout.main);
			final LinearLayout AniLL = (LinearLayout) findViewById(R.id.aniLinearView);
			final ImageView IV = (ImageView) findViewById(R.id.aniView);
			final ImageView Left = (ImageView) findViewById(R.id.aniLeftView);
			final ImageView Right = (ImageView) findViewById(R.id.aniRightView);
			Logo = BitmapFactory.decodeResource(getResources(),
					R.drawable.logo1);
			mDrawable = new BitmapDrawable(Logo);
			IV.setBackgroundDrawable(mDrawable);
			RightLogo = BitmapFactory.decodeResource(getResources(),
					R.drawable.rightlogo);
			mDrawable = new BitmapDrawable(RightLogo);
			Right.setBackgroundDrawable(mDrawable);
			LeftLogo = BitmapFactory.decodeResource(getResources(),
					R.drawable.leftlogo3);
			mDrawable = new BitmapDrawable(LeftLogo);
			Left.setBackgroundDrawable(mDrawable);
			final Animation mAni1;
			final Animation mAni2;
			final Animation mAni5;
			mAni1 = AnimationUtils.loadAnimation(Main.this, R.anim.rotate_drop);
			mAni2 = AnimationUtils.loadAnimation(Main.this, R.anim.rotate);

			mAni5 = AnimationUtils.loadAnimation(Main.this, R.anim.crash);
			mPlayer = MediaPlayer.create(this, R.raw.opening);

			new Handler().postDelayed(new Runnable() {
				@Override
				public void run() {
					IV.setVisibility(View.VISIBLE);
					IV.startAnimation(mAni1);
				}
			}, 10);
			new Handler().postDelayed(new Runnable() {
				@Override
				public void run() {

					IV.setVisibility(View.INVISIBLE);
					AniLL.setVisibility(View.INVISIBLE);
					Right.setVisibility(View.INVISIBLE);
					Left.setVisibility(View.INVISIBLE);
					IV.setBackgroundDrawable(null);
					Right.setBackgroundDrawable(null);
					Left.setBackgroundDrawable(null);

					Logo.recycle();
					RightLogo.recycle();
					LeftLogo.recycle();
					cur_page = 1;
					Cycle = true;
				}

			}, 3000);

			mAni1.setAnimationListener(new AnimationListener() {
				@Override
				public void onAnimationStart(Animation animation) {}
				@Override
				public void onAnimationRepeat(Animation animation) {}
				@Override
				public void onAnimationEnd(Animation animation) {
					AniLL.setVisibility(View.VISIBLE);
					Left.setVisibility(View.VISIBLE);
					Left.startAnimation(mAni5);
					mPlayer.start();
					IV.startAnimation(mAni2);
				}
			});
			mAni2.setAnimationListener(new AnimationListener() {
				@Override
				public void onAnimationStart(Animation animation) {}
				@Override
				public void onAnimationRepeat(Animation animation) {}
				@Override
				public void onAnimationEnd(Animation animation) {
					Right.setVisibility(View.VISIBLE);
					Right.startAnimation(mAni5);
					intent = new Intent(Main.this , FirstPageActivity.class);
					finish();
					startActivity(intent);

				}
			});


		} 

	}

	@Override
	public void onPause() {
		super.onPause();
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
	}

	public static Bitmap ResizeOptions(Context context, int resId, int resizeNum) {
		Bitmap tempImage = BitmapFactory.decodeResource(context.getResources(),
				resId, BitmapOption.buttonResize(Main.disp,
						context.getResources(), resId, resizeNum));
		return tempImage;
	}
}
