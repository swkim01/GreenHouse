package test.primium;

import android.content.*;
import android.graphics.*;
import android.view.*;

public class MyColor {
	Context m_Context;

	public static int[] nColor = { 0xFF0000FF, 0xFF00FF00, 0xFFFF0000,
			0xFF00FFFF, 0xFFFF00FF, 0xFFFFFF00, 0xFF000000, 0xFFFFFFFF };

	public static final int NUMBER = 8;
	public static final int CENTER = -1;

	public Bitmap[] m_SideColorBMP = new Bitmap[NUMBER];
	public Bitmap m_CenterColorBMP;
	public static final float RADIUS = 20;

	public int m_nCurrentColor = 0xC000FF00;

	public void recycleBitmap() {
		for (int i = 0; i < m_SideColorBMP.length; i++){
			m_SideColorBMP[i].recycle();
			m_SideColorBMP[i] = null;
		}
		m_CenterColorBMP.recycle();
		m_CenterColorBMP = null;
		
		m_SideColorBMP = null;
	}

	public MyColor(Context context) {
		m_Context = context;

		int resizeNum = 9;
		for (int n = 0; n < NUMBER; n++) {
			m_SideColorBMP[n] = Main.ResizeOptions(m_Context, R.drawable.color_bmp00 + n, resizeNum) ;
		}

		m_CenterColorBMP = Main.ResizeOptions(m_Context, R.drawable.color_bmp07, resizeNum) ;
	}

	public void VisiablePallete(float x, float y, CustomView CV) {
//		CV.m_Draw.m_PaletteBitmap = Bitmap.createBitmap(
//				CV.m_Draw.m_nDisplayWidth, CV.m_Draw.m_nDisplayWidth,
//				Bitmap.Config.ARGB_8888);
//
//		// BitmapFactory.Options Pallete_Option = new BitmapFactory.Options();
//		CV.m_Draw.m_PaletteImage = BitmapFactory.decodeResource(
//				m_Context.getResources(), R.drawable.palette, null);
//		
//		CV.m_PaletteCanvas = new Canvas(CV.m_Draw.m_PaletteBitmap);
//		CV.m_Draw.m_PaletteBitmap.eraseColor(0x00000000);
//
//		CV.m_PaletteCanvas.drawBitmap(CV.m_Draw.m_PaletteImage,
//				CV.m_PaletteMethods.m_CenterPoint.x,
//				CV.m_PaletteMethods.m_CenterPoint.y, null);
		
		
		
		
		
		CustomView.m_bCheckSide = false;
		CustomView.m_bCheckCenter = false;
		

		CustomView.m_bCheckCenter = CV.m_PaletteMethods.CheckCenter(x, y,
				CV.m_PaletteMethods.m_CenterPoint.x,
				CV.m_PaletteMethods.m_CenterPoint.y, RADIUS);
		CustomView.m_bCheckSide = CV.m_PaletteMethods
				.CheckSide(CV.m_Draw.m_nGetPixel);


		if (CustomView.m_bCheckCenter) {
			CV.m_PaletteMethods.m_PrePoint.x = (int) x;
			CV.m_PaletteMethods.m_PrePoint.y = (int) y;

			CV.m_PaletteMethods.m_nSelectItemIndex = CENTER;

		} else if (CustomView.m_bCheckSide) {
			for (int n = 0; n < CV.m_PaletteMethods.m_nItemNum; n++) {
				CustomView.m_bCheckCenter = CV.m_PaletteMethods.CheckCenter(x,
						y, CV.m_PaletteMethods.m_CurrentPoint[n].x,
						CV.m_PaletteMethods.m_CurrentPoint[n].y, RADIUS);

				if (CustomView.m_bCheckCenter) {
					CV.m_PaletteMethods.m_nSelectItemIndex = n;
					m_nCurrentColor = nColor[n];
					CV.m_Draw.m_nGetPixel = nColor[n];
					break;
				}
			}
		} else {
			CV.m_Draw.m_nGetPixel = m_nCurrentColor;
		}

		CV.m_PaletteMethods.m_PrePoint.x = (int) x;
		CV.m_PaletteMethods.m_PrePoint.y = (int) y;
		return;
	}

	public void DoubleTap(MotionEvent e, CustomView CV) {
		if(CV.m_PaletteMethods.m_nSelectItemIndex == CENTER)
//		if(CV.m_bCheckCenter)
		{
			return ;
		}
//		else if (CV.m_bCheckSide) {
		else{
			CV.m_Draw.m_nGetPixel = CV.m_PaletteMethods.MixColor(
					CV.m_Draw.m_CenterPalettePaint.getColor(),
					CV.m_Draw.m_nGetPixel);

			CV.m_Draw.m_CenterPalettePaint
					.setColor((CV.m_Draw.m_nGetPixel & 0x00FFFFFF) | 0xFF000000);

			CV.m_PaletteMethods
					.PaletteSearch(
							CV.m_PaletteMethods.m_CurrentPoint[CV.m_PaletteMethods.m_nSelectItemIndex].x,
							CV.m_PaletteMethods.m_CurrentPoint[CV.m_PaletteMethods.m_nSelectItemIndex].y,
							CV.m_PaletteMethods, CV.m_Draw, CV.m_PaletteCanvas); 

		}
		return;
	}

	public void SingleTapConfirmed(MotionEvent e, CustomView CV) {

		CV.m_Draw.m_BrushPaint.setColor(0xC0FFFFFF & CV.m_Draw.m_nGetPixel);

		// 색상 바꾸는 부분.
		if (CustomView.brush == CustomView.BRUSH.Sand) // Sand는 Alpa값 BB
		{
			CV.m_Draw.m_BrushOption.m_ChangeBrush = CV.ChangeBrush(
					CV.m_Draw.m_BrushOption.m_ChangeBrush, 0xBB000000,
					CV.m_Draw.m_BrushPaint.getColor());
		} else if (CustomView.brush == CustomView.BRUSH.Pattern) { // 기타 Brush는
																	// Alpa값 0C
			CV.m_Draw.m_BrushOption.m_ChangeBrush = CV.ChangeBrush(
					CV.m_Draw.m_BrushOption.m_ChangeBrush, 0x0C000000,
					CV.m_Draw.m_BrushPaint.getColor());
		}

		CV.m_Draw.m_SizePalettePaint.setColor((CV.m_Draw.m_BrushPaint
				.getColor() & 0x00FFFFFF) | 0xFF000000);

		CV.m_Draw.m_bVisiablePallete = false;
		
		
		
		
		
//		CV.m_Draw.m_PaletteBitmap.recycle();
//		CV.m_Draw.m_PaletteImage.recycle();
//		
//		CV.m_PaletteCanvas = null;
	
		// CV.m_Draw.m_BrushOption.m_bEraser = false;
		// CV.m_Draw.m_BrushPaint.setXfermode(null);
		CV.invalidate();
		return;
	}

	public void Initialization(CustomView CV) {
		CV.m_PaletteMethods.m_nItemNum = MyColor.NUMBER;

		CV.m_PaletteMethods.m_SideBitmap = m_SideColorBMP;
		CV.m_PaletteMethods.m_CenterBitmap = m_CenterColorBMP;
	}
}
