package test.primium;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.provider.MediaStore.MediaColumns;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;

public class ThirdPageActivity extends Activity{
	public LinearLayout ThirdLayout;
	public Button GalleryBtn;
	public Button BaseGalleryBtn;
	public String strPath;
	public BtnBackground mBtnBackground;
	public Intent intent;
	public Drawable mBackgroundDrawable;
	private Bitmap ThirdBackground;
	public WindowManager wm;
	public BitmapFactory.Options options;
	public Display disp;
	private boolean Process;
	public Uri currImageURI;
	private MediaPlayer mPlayer_Click;
	private boolean btnflag;
	
	@Override
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.third);
		mBtnBackground = new BtnBackground();
		
		ThirdLayout = (LinearLayout) findViewById(R.id.thirdView);
		GalleryBtn = (Button) findViewById(R.id.GalleryBtn);
		BaseGalleryBtn = (Button) findViewById(R.id.BaseGalleryBtn);

		
		wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
		disp = wm.getDefaultDisplay();
		options = new BitmapFactory.Options();
		BitmapOption.getSampleSize(options, disp, null, getResources(),
				R.drawable.background3);
		Process = true;
		
		
		mPlayer_Click = MediaPlayer.create(this, R.raw.click);
		mBtnBackground.galleryBtnBackground(this, GalleryBtn);
		mBtnBackground.baseGelleryBtnBackground(this, BaseGalleryBtn);
		
		ThirdBackground = BitmapFactory.decodeResource(
				getResources(), R.drawable.background3, options);
		mBackgroundDrawable = new BitmapDrawable(ThirdBackground);
		ThirdLayout.setBackgroundDrawable(mBackgroundDrawable);
		
		btnflag = false;
	}
	
	public void onStart(){
		super.onStart();
		System.out.println("ThirdPageActivity onStart");
	}
	
	@Override
	public void onResume(){
		super.onResume();
		Intent svc = new Intent(this, BackgroundSoundService.class);
		startService(svc);
		final Animation BtnAnimation;
		BtnAnimation = AnimationUtils.loadAnimation(this,
				R.anim.mainbtn_in);
		if(Process){
			new Handler().postDelayed(new Runnable() {
				@Override
				public void run() {
					// TODO Auto-generated method stub
					GalleryBtn.startAnimation(BtnAnimation);
					BaseGalleryBtn.startAnimation(BtnAnimation);
					Process = false;
				}
			}, 20);
			new Handler().postDelayed(new Runnable() {
				@Override
				public void run() {
					// TODO Auto-generated method stub
					GalleryBtn.setOnClickListener(PageChange);
					BaseGalleryBtn.setOnClickListener(PageChange);
				}
			},700);
		}
	}
	
	
	@Override
	public void onPause(){
		super.onPause();
		if(!Process && BackgroundSoundService.mp.isPlaying()){
			System.out.println("ThirdPageActivity onPause BGM Stop");
			BackgroundSoundService.mp.pause();
			return;
		}
		
	}
	
	public void onStop(){
		super.onStop();
		System.out.println("ThirdPagePageActivity onStop()");
	}
	
	public void onRestart(){
		super.onRestart();
		Process=false;
	}
	@Override
	public void onDestroy(){
		super.onDestroy();
		ThirdLayout.setBackgroundDrawable(null);
		GalleryBtn.setBackgroundDrawable(null);
		BaseGalleryBtn.setBackgroundDrawable(null);
		ThirdBackground.recycle();
		mBtnBackground.recycleBitmap2();
//		ThirdLayout.setBackgroundDrawable(null);
//		GalleryBtn.setBackgroundDrawable(null);
//		BaseGalleryBtn.setBackgroundDrawable(null);
//		ThirdBackground.recycle();
//		BtnBackground.recycleBitmap2();
		
//		BackgroundSoundService.mp.stop();
//		stopService(FirstPageActivity.BackgoundMusic);
	}
	
	private Button.OnClickListener PageChange = new View.OnClickListener(){
		@Override
		public void onClick(View v) {
			if(!btnflag){
				try {
					mPlayer_Click.start();
				} catch (Exception e) {
					mPlayer_Click = MediaPlayer.create(ThirdPageActivity.this, R.raw.click);
					// TODO: handle exception
				}
				switch(v.getId()){
				case R.id.GalleryBtn:
					Process = true;
					intent = new Intent();
					intent.setType("image/*");
					intent.setAction(Intent.ACTION_GET_CONTENT);
					startActivityForResult(
					Intent.createChooser(intent, "Select Picture"), 2);
					break;
				case R.id.BaseGalleryBtn:
					Process = true;
					intent = new Intent(ThirdPageActivity.this, BaseGallery.class);
					finish();
					startActivity(intent);
					break;
				}
				btnflag = true;
			}
		}
	};
	
	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		Process = false;
		btnflag = false;
		finishActivity(requestCode);
		if (resultCode == RESULT_OK && requestCode == 2) {
			Process = true;
			int position = 0;
			position = data.getIntExtra("ImageNum", 0);
			currImageURI = data.getData();
			strPath = getRealPathFromURI(currImageURI);
			intent = new Intent(this, FourthPageActivity.class);
			intent.putExtra("ImageNum", position);
			intent.putExtra("ImagePath", strPath);
			intent.putExtra("select", requestCode);
			finish();
			startActivity(intent);
		}
	}
	private String getRealPathFromURI(Uri contentUri) {
		// can post image
		String[] proj = { MediaColumns.DATA };
		Cursor cursor = managedQuery(contentUri, proj, null, null, null);
		int column_index = cursor
				.getColumnIndexOrThrow(MediaColumns.DATA);

		cursor.moveToFirst();
		return cursor.getString(column_index);
	}
	@Override
	public void onBackPressed() {
//		super.onBackPressed();
		finish();
		Intent i = new Intent(this , SecondPageActivity.class);
		startActivity(i);
		mPlayer_Click.start();
		Process = true;
	}
}
