package test.primium;

import java.util.*;

import test.primium.CustomView.BRUSH;
import android.content.*;
import android.graphics.*;
import android.view.*;

public class MyAnimation {
	public static final int NUMBER = 4;

	public static final int CENTER = -1;

	public static final int NONE = -1;
	public static final int FIRE = 0;
	public static final int FISH_EYE = 1;
	public static final int LIGHT = 2;
	public static final int RAIN = 3;

	private static final float PI = 3.1415926f;
	public static final float RADIUS = 30;

	public static final int TOUCH_TOLERANCE = 4;

	private float EndX = 0;
	private float EndY = 0;
	private CustomView mCV;

	float m_fCurX;
	float m_fCurY;
	float m_fPreX = 0;
	float m_fPreY = 0;
	float m_fdx;
	float m_fdy;
	float m_fGradient;
	float m_fSignX = 1;
	float m_fSignY = 1;
	float m_fMax = 0;

	public static int EndAnimation = -1;

	public static LinkedList<FireNode> m_FireLinkedList = new LinkedList<FireNode>();
	public static LinkedList<FireNode> m_NodeLinkedList = new LinkedList<FireNode>();

	int m_nFinalSelectItem = 0;

	public Bitmap[] m_SideAnimationBMP = new Bitmap[NUMBER];
	public Bitmap m_CenterAnimationBMP;
	public JNIMethods m_JNIMethods = new JNIMethods();

	Context m_Context;

	Point m_StartPosition = new Point();
	Point m_PrePosition = new Point();
	Point m_PostPosition = new Point();

	Path m_FierPath = new Path();
	Paint m_FierPaint = new Paint();

	// int[] m_pnNodeX;
	// int[] m_pnNodeY;
	// int[] m_pnNodeRadius;
	// int m_nNodeSize;
	boolean m_bLoop;
	public static boolean process;
	public BlurMaskFilter m_FierBlur;

	public class FireNode {
		public FireNode() {
			m_Position = new Point();
		}

		Point m_Position;
		float m_Radius;
	}

	public MyAnimation(Context context) {
		m_Context = context;

		Collection<FireNode> collection;
		int resizeNum = 9;
		for (int n = 0; n < NUMBER; n++) {
			m_SideAnimationBMP[n] = Main.ResizeOptions(m_Context,
					R.drawable.anisticker00 + n, resizeNum);
		}

		m_CenterAnimationBMP = m_SideAnimationBMP[0];

		m_FierPaint.setAntiAlias(true);
		m_FierPaint.setStyle(Paint.Style.STROKE);
		m_FierPaint.setStrokeJoin(Paint.Join.ROUND);
		m_FierPaint.setStrokeCap(Paint.Cap.ROUND);
		m_FierPaint.setStrokeWidth(30);
		process = false;
	}

	public void VisiablePallete(float x, float y, CustomView CV) {
		CustomView.m_bCheckCenter = CV.m_PaletteMethods.CheckCenter(x, y,
				CV.m_PaletteMethods.m_CenterPoint.x,
				CV.m_PaletteMethods.m_CenterPoint.y, RADIUS);

		if (CustomView.m_bCheckCenter) {
			CV.m_PaletteMethods.m_PrePoint.x = (int) x;
			CV.m_PaletteMethods.m_PrePoint.y = (int) y;

			CV.m_PaletteMethods.m_nSelectItemIndex = CENTER;

			return;
		}

		for (int n = 0; n < CV.m_PaletteMethods.m_nItemNum; n++) {
			if (CV.m_PaletteMethods.m_CurrentPoint[n].y > CV.m_PaletteMethods.m_CenterPoint.y)
				continue;
			CustomView.m_bCheckCenter = CV.m_PaletteMethods.CheckCenter(x, y,
					CV.m_PaletteMethods.m_CurrentPoint[n].x,
					CV.m_PaletteMethods.m_CurrentPoint[n].y, RADIUS);

			if (CustomView.m_bCheckCenter) {
				CV.m_PaletteMethods.m_nSelectItemIndex = n;
				break;
			}
		}

		CV.m_PaletteMethods.m_PrePoint.x = (int) x;
		CV.m_PaletteMethods.m_PrePoint.y = (int) y;
		return;
	}

	public void recycleBitmap() {
		for (int i = 0; i < m_SideAnimationBMP.length; i++) {
			m_SideAnimationBMP[i].recycle();
			m_SideAnimationBMP[i] = null;
		}
		m_CenterAnimationBMP.recycle();
		m_CenterAnimationBMP = null;

		m_SideAnimationBMP = null;
	}

	public void TouchStart_Fire(float x, float y, CustomView CV) {
		if (!process) {
			m_StartPosition.x = (int) x;
			m_StartPosition.y = (int) y;

			CV.m_X = x;
			CV.m_Y = y;
		}
		return;
	}

	public void TouchMove_Fire(float x, float y, CustomView CV) {
		if (!process) {
			float dx = Math.abs(x - CV.m_X);
			float dy = Math.abs(y - CV.m_Y);

			if (dx >= TOUCH_TOLERANCE || dy >= TOUCH_TOLERANCE) {
				Interpolation(CV, CV.m_X, CV.m_Y, x, y, 1);

				CV.m_X = x;
				CV.m_Y = y;
			}
		}
		return;
	}

	public void TouchUp_Fire(float x, float y, CustomView CV) {

		if (!process) {
			process = true;
			EndX = x;
			EndY = y;
			mCV = CV;
			Intent intent = new Intent(CV.m_Context, AnimationActivity.class);
			intent.putExtra("Mode", FIRE);
			GalleryViewActivity.bEndFlag = true;
			CV.m_Context.startActivity(intent);
			EndAnimation = FIRE;
		}
		return;
	}

	public void TouchUp_FishEye(float x, float y, CustomView CV) {

		if (!process) {
			process = true;
			EndX = x;
			EndY = y;
			mCV = CV;
			Intent intent = new Intent(CV.m_Context, AnimationActivity.class);
			intent.putExtra("Mode", FISH_EYE);
			GalleryViewActivity.bEndFlag = true;
			CV.m_Context.startActivity(intent);

			EndAnimation = FISH_EYE;
		}
		return;
	}

	public void TouchUp_Light(float x, float y, CustomView CV) {
		// 필요한 function을 넣으시오.
		// CV.m_Draw.m_BackgroundBitmap = m_JNI.FireAnimationEffect(CV);
		if (!process) {
			process = true;
			EndX = x;
			EndY = y;
			mCV = CV;
			Intent intent = new Intent(CV.m_Context, AnimationActivity.class);
			intent.putExtra("Mode", LIGHT);
			GalleryViewActivity.bEndFlag = true;
			CV.m_Context.startActivity(intent);

			EndAnimation = LIGHT;
		}
		return;
	}

	public void TouchUp_Rain(float x, float y, CustomView CV) {
		// 필요한 function을 넣으시오.
		// CV.m_Draw.m_BackgroundBitmap = m_JNI.FireAnimationEffect(CV);
		if (!process) {
			process = true;
			EndX = x;
			EndY = y;
			mCV = CV;
			Intent intent = new Intent(CV.m_Context, AnimationActivity.class);
			intent.putExtra("Mode", RAIN);
			GalleryViewActivity.bEndFlag = true;
			CV.m_Context.startActivity(intent);

			EndAnimation = RAIN;
		}
		return;
	}

	public void SingleTapConfirmed(MotionEvent e, CustomView CV) {

		if (CV.m_PaletteMethods.m_nSelectItemIndex > NUMBER) {
			return;
		}
		SelectBrush(CV.m_PaletteMethods.m_nSelectItemIndex, CV);

		if (CV.m_PaletteMethods.m_nSelectItemIndex != CENTER) {
			m_nFinalSelectItem = CV.m_PaletteMethods.m_nSelectItemIndex;
			m_CenterAnimationBMP = m_SideAnimationBMP[m_nFinalSelectItem];
		}
		CV.m_PaletteMethods.m_CenterBitmap = m_CenterAnimationBMP;

		CV.m_Draw.m_bVisiablePallete = false;
		CV.m_Draw.m_BrushOption.m_bEraser = false;
		CV.m_Draw.m_BrushPaint.setXfermode(null);
		CV.invalidate();
		return;
	}

	public void SelectBrush(int nIndex, CustomView CV) {

		switch (nIndex) {
		case CENTER:
			SelectBrush(m_nFinalSelectItem, CV);
			break;
		case FIRE:
			CustomView.brush = BRUSH.Fire;
			CV.m_Draw.m_BrushPaint.setMaskFilter(null);
			break;

		case FISH_EYE:
			CustomView.brush = BRUSH.Fish_eye;
			CV.m_Draw.m_BrushPaint.setMaskFilter(null);
			break;

		case LIGHT:
			CustomView.brush = BRUSH.Light;
			CV.m_Draw.m_BrushPaint.setMaskFilter(null);
			break;

		case RAIN:
			CustomView.brush = BRUSH.Rain;
			CV.m_Draw.m_BrushPaint.setMaskFilter(null);
			break;

		}
	}

	public void Area(CustomView CV) {
		float fArea = 0;
		Point PrePosition = new Point();
		Point PostPosition = new Point();
		Point CeterPosition = new Point();

		for (int n = 0; n < m_NodeLinkedList.size(); n++) {
			PrePosition = m_NodeLinkedList.get(n).m_Position;
			PostPosition = m_NodeLinkedList.get((n + 1)
					% m_NodeLinkedList.size()).m_Position;

			fArea += PrePosition.x * PostPosition.y;
			fArea -= PrePosition.y * PostPosition.x;

			CeterPosition.x += ((PrePosition.x + PostPosition.x) * ((PrePosition.x * PostPosition.y) - (PostPosition.x * PrePosition.y)));
			CeterPosition.y += ((PrePosition.y + PostPosition.y) * ((PrePosition.x * PostPosition.y) - (PostPosition.x * PrePosition.y)));
		}

		fArea /= 2.0;
		fArea = Math.abs(fArea);

		CeterPosition.x = (int) Math.abs((CeterPosition.x / (6.0 * fArea)));
		CeterPosition.y = (int) Math.abs((CeterPosition.y / (6.0 * fArea)));

		CV.m_BrushCanvas.drawCircle(CeterPosition.x, CeterPosition.y, 30,
				CV.m_Draw.m_BrushPaint);

		return;
	}

	public void AttachFire(CustomView CV, boolean bLoop) {

		int nListSize = m_NodeLinkedList.size();

		if (nListSize < 20)
			return;

		CV.m_Draw.m_DrawBitmap.eraseColor(0xFFFFFFFF);
		CV.m_Draw.m_PasteBitmap.eraseColor(0x00000000);

		m_FierPath.reset();

		m_FierPath.moveTo(m_NodeLinkedList.get(0).m_Position.x,
				m_NodeLinkedList.get(0).m_Position.y);

		for (int n = 0; n < nListSize; n++) {
			if (Math.random() <= 0.05) {
				int nWidth = (int) (40 * Math.random() + 10);

				if (n + nWidth >= nListSize)
					continue;

				float nStep = PI / nWidth;
				float fRadius = 0;
				float fPostRadian, fPreRadian;
				int dx, dy;
				Point CenterPosition = new Point();
				Point AxisPosition = new Point();
				Point CurrentPosition = new Point();

				if (Math.random() >= 0.5)
					nStep *= +1;
				else
					nStep *= -1;

				m_PrePosition = m_NodeLinkedList.get(n).m_Position;
				m_PostPosition = m_NodeLinkedList.get(n + nWidth).m_Position;

				dx = m_PostPosition.x - m_PrePosition.x;
				dy = m_PostPosition.y - m_PrePosition.y;

				fRadius = (float) Math.sqrt(Math.pow(dx / 2.0, 2.0)
						+ Math.pow(dy / 2.0, 2.0));

				CenterPosition.x = (m_PostPosition.x + m_PrePosition.x) / 2;
				CenterPosition.y = (m_PostPosition.y + m_PrePosition.y) / 2;

				AxisPosition.x = (int) (CenterPosition.x + fRadius);
				AxisPosition.y = (CenterPosition.y);

				fPreRadian = IncludedRadian(AxisPosition, m_PrePosition,
						CenterPosition);

				fPostRadian = IncludedRadian(AxisPosition, m_PostPosition,
						CenterPosition);

				for (int nCount = 0; nCount <= nWidth; nCount++) {

					if (n + nCount >= nListSize)
						break;

					CurrentPosition = ChangePosition(CenterPosition.x,
							CenterPosition.y, fRadius, (fPreRadian + nStep
									* nCount)
									% (2 * PI));

					m_FierPath.lineTo(CurrentPosition.x, CurrentPosition.y);
					m_NodeLinkedList.get(n + nCount).m_Position = CurrentPosition;
				}

				n = n + nWidth;

			} else {
				m_FierPath.lineTo(m_NodeLinkedList.get(n).m_Position.x,
						m_NodeLinkedList.get(n).m_Position.y);
			}
		}

		m_FierPaint.setStyle(Paint.Style.FILL);

		m_FierPaint.setMaskFilter(null);
		m_FierPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
		CV.m_DrawCanvas.drawPath(m_FierPath, m_FierPaint);

		m_FierPaint.setMaskFilter(null);
		m_FierPaint.setXfermode(null);
		m_FierPaint.setColor(0xFFFFFFFF);

		Point RandomPosition = new Point();

		for (int n = 0; n < nListSize; n++) {
			RandomPosition = RandomPosition(
					m_NodeLinkedList.get(n).m_Position.x,
					m_NodeLinkedList.get(n).m_Position.y, 10);

			CV.m_DrawCanvas.drawCircle(RandomPosition.x, RandomPosition.y,
					m_NodeLinkedList.get(n).m_Radius, m_FierPaint);
		}

		return;
	}

	public void Interpolation(CustomView CV, float PrePositionX,
			float PrePositionY, float PostPositionX, float PostPositionY,
			float fVariation) {
		float fRadius;

		m_fdx = PostPositionX - PrePositionX;
		m_fdy = PostPositionY - PrePositionY;

		m_fGradient = Math.abs(m_fdy) / Math.abs(m_fdx);

		if (Math.abs(m_fdx) < Math.abs(m_fdy)) {
			m_fSignX = 1 / m_fGradient;
			m_fSignY = 1;
			m_fMax = Math.abs(m_fdy);
		} else {
			m_fSignX = 1;
			m_fSignY = m_fGradient;
			m_fMax = Math.abs(m_fdx);
		}

		if (m_fdx < 0)
			m_fSignX *= -1;

		if (m_fdy < 0)
			m_fSignY *= -1;

		m_PrePosition.x = (int) PrePositionX;
		m_PrePosition.y = (int) PrePositionY;

		for (float nConut = 0; nConut <= m_fMax; nConut += fVariation) {
			fRadius = (float) (4 * Math.random() + 1);

			FireNode Node = new FireNode();
			Node.m_Position.x = (int) (PrePositionX + (m_fSignX * nConut));
			Node.m_Position.y = (int) (PrePositionY + (m_fSignY * nConut));
			Node.m_Radius = fRadius;
			m_NodeLinkedList.add(Node);

			m_PrePosition = m_PostPosition;
		}
		return;
	}

	public CustomView ImageIntegration(CustomView CV, int nIndex) {

		if (nIndex == FIRE) {
			CV.m_Draw.m_AnimationBitmap.eraseColor(0x00000000);

			CV.m_AnimationCanvas
					.drawBitmap(CV.m_Draw.m_PasteBitmap, 0, 0, null);
			CV.m_AnimationCanvas.drawBitmap(CV.m_Draw.m_DrawBitmap, 0, 0, null);

			CV.m_Draw.m_PasteBitmap.eraseColor(0x00000000);
			CV.m_Draw.m_DrawBitmap.eraseColor(0x00000000);
		} else {
			CV.m_Draw.m_DrawBitmap.eraseColor(0x00000000);

			if (CV.m_bVisibleEdge) {
				CV.m_DrawCanvas.drawBitmap(CV.m_Draw.m_BGAnimationBitmap, 0, 0,
						null);
				CV.m_DrawCanvas.drawBitmap(CV.m_Draw.m_BrushBitmap, 0, 0, null);
				CV.m_DrawCanvas
						.drawBitmap(CV.m_Draw.m_MozaicBitmap, 0, 0, null);

				CV.m_Draw.m_BGAnimationBitmap.eraseColor(0x00000000);
				CV.m_Draw.m_BrushBitmap.eraseColor(0x00000000);
				CV.m_Draw.m_MozaicBitmap.eraseColor(0x00000000);
			} else {
				CV.m_DrawCanvas.drawBitmap(CV.m_Draw.m_BackgroundBitmap, 0, 0,
						null);
				CV.m_DrawCanvas.drawBitmap(CV.m_Draw.m_BrushBitmap, 0, 0, null);
				CV.m_DrawCanvas
						.drawBitmap(CV.m_Draw.m_MozaicBitmap, 0, 0, null);

				CV.m_Draw.m_BackgroundBitmap.eraseColor(0x00000000);
				CV.m_Draw.m_BrushBitmap.eraseColor(0x00000000);
				CV.m_Draw.m_MozaicBitmap.eraseColor(0x00000000);
			}

			if (CV.m_MyMozaic.m_CurrentLinkedList.size() != 0) {
				CV.m_MyMozaic.m_CurrentLinkedList
						.removeAll(CV.m_MyMozaic.m_CurrentLinkedList);
				CV.m_Draw.m_MozaicBitmap.eraseColor(0x00000000);
			}
		}
		// switch (nIndex) {
		// case FIRE:
		// CV.m_Draw.m_AnimationBitmap.eraseColor(0x00000000);
		//
		// CV.m_AnimationCanvas.drawBitmap(CV.m_Draw.m_PasteBitmap, 0, 0, null);
		// CV.m_AnimationCanvas.drawBitmap(CV.m_Draw.m_DrawBitmap, 0, 0, null);
		//
		// CV.m_Draw.m_PasteBitmap.eraseColor(0x00000000);
		// CV.m_Draw.m_DrawBitmap.eraseColor(0x00000000);
		// break;
		//
		// case RAIN:
		// CV.m_Draw.m_DrawBitmap.eraseColor(0x00000000);
		//
		// CV.m_DrawCanvas.drawBitmap(CV.m_Draw.m_BackgroundBitmap, 0, 0, null);
		// CV.m_DrawCanvas.drawBitmap(CV.m_Draw.m_BrushBitmap, 0, 0, null);
		// CV.m_DrawCanvas.drawBitmap(CV.m_Draw.m_MozaicBitmap, 0, 0, null);
		//
		// CV.m_Draw.m_BackgroundBitmap.eraseColor(0x00000000);
		// CV.m_Draw.m_BrushBitmap.eraseColor(0x00000000);
		// CV.m_Draw.m_MozaicBitmap.eraseColor(0x00000000);
		// break;
		//
		// default:
		// break;
		// }

		return CV;
	}

	public void Initialization(CustomView CV) {
		CV.m_PaletteMethods.m_nItemNum = MyAnimation.NUMBER;

		CV.m_PaletteMethods.m_SideBitmap = m_SideAnimationBMP;
		CV.m_PaletteMethods.m_CenterBitmap = m_CenterAnimationBMP;
	}

	// 중심점에 대해 Radian의 각도를 가지며 Radius만큼 떨어진 곳의 좌표
	public Point ChangePosition(float PositionX, float PositionY, float Radius,
			float dRadian) {
		Point dPoint = new Point();

		dPoint.x = (int) (PositionX + Radius * Math.cos(dRadian));
		dPoint.y = (int) (PositionY + Radius * Math.sin(dRadian));

		return dPoint;
	}

	// 중심점에 대해 Radian의 각도를 가지며 Radius만큼 떨어진 곳의 좌표
	public Point RandomPosition(float PositionX, float PositionY, float fWidth) {
		Point dPoint = new Point();

		float fRadius;
		float fRadian;

		fRadius = (float) (fWidth * Math.random() - fWidth / 2);
		fRadian = (float) (2 * PI * Math.random());

		dPoint.x = (int) (PositionX + fRadius * Math.cos(fRadian));
		dPoint.y = (int) (PositionY + fRadius * Math.sin(fRadian));

		return dPoint;
	}

	public boolean CheckLoof(float TouchX, float TouchY, float CenterX,
			float CenterY, float nRadius) {
		float fDistance = 0;
		float dx, dy;
		boolean bLoop = false;

		dx = TouchX - CenterX;
		dy = TouchY - CenterY;

		fDistance = (float) Math.sqrt(Math.pow(dx, 2) + Math.pow(dy, 2));

		if (fDistance < nRadius) {
			bLoop = true;
		} else {
			bLoop = false;
		}
		return bLoop;
	}

	// 3점 사이에 끼인각
	public float IncludedRadian(Point m_PrePoint, Point m_PostPoint,
			Point m_CenterPoint) {
		float dRadian;

		float dx1 = m_PrePoint.x - m_CenterPoint.x;
		float dy1 = m_PrePoint.y - m_CenterPoint.y;

		float dx2 = m_PostPoint.x - m_CenterPoint.x;
		float dy2 = m_PostPoint.y - m_CenterPoint.y;

		float dRadian1 = (float) Math.atan2(dy1, dx1);
		float dRadian2 = (float) Math.atan2(dy2, dx2);

		dRadian = dRadian2 - dRadian1;

		return dRadian;
	}

	public void inThread() {

		if (MyAnimation.process) {
			switch (EndAnimation) {
			case NONE:
				break;
			case FIRE:
				// m_bLoop = CheckLoof(EndX, EndY, m_StartPosition.x,
				// m_StartPosition.y, 70);
				// if (m_bLoop) {

				Interpolation(mCV, mCV.m_X, mCV.m_Y, EndX, EndY, 1);

				mCV.m_X = EndX;
				mCV.m_Y = EndY;

				Interpolation(mCV, mCV.m_X, mCV.m_Y, m_StartPosition.x,
						m_StartPosition.y, 1);
				// }

				AttachFire(mCV, m_bLoop);
				// Area(CV);

				m_FierPaint.setStyle(Paint.Style.STROKE);
				m_FierPaint.setMaskFilter(null);
				m_FierPaint.setXfermode(null);

				m_FierBlur = new BlurMaskFilter(20, BlurMaskFilter.Blur.NORMAL);
				m_FierPaint.setColor(0xFF774900);
				m_FierPaint.setMaskFilter(m_FierBlur);
				mCV.m_PasteCanvas.drawPath(m_FierPath, m_FierPaint);

				m_FierBlur = new BlurMaskFilter(10, BlurMaskFilter.Blur.NORMAL);
				m_FierPaint.setColor(0xFF000000);
				m_FierPaint.setMaskFilter(m_FierBlur);
				mCV.m_PasteCanvas.drawPath(m_FierPath, m_FierPaint);

				mCV = ImageIntegration(mCV, FIRE);

				mCV.destroyDrawingCache();

				m_FireLinkedList.clear();
				m_NodeLinkedList.clear();
				m_FierPath.reset();
				EndAnimation = NONE;
				mCV.postInvalidate();
				GalleryViewActivity.bEndFlag = false;
				break;

			case RAIN:
				mCV = ImageIntegration(mCV, RAIN);

				m_JNIMethods.RainDropEffect(mCV, (int) EndX, (int) EndY);
				// if(mCV.m_bVisibleEdge){
				// mCV.m_Draw.m_BGAnimationBitmap =
				// m_JNIMethods.RainDropEffect(mCV,
				// (int) EndX, (int) EndY);
				// }else{
				// mCV.m_Draw.m_BackgroundBitmap =
				// m_JNIMethods.RainDropEffect(mCV,
				// (int) EndX, (int) EndY);
				// }

				mCV.destroyDrawingCache();
				EndAnimation = NONE;
				mCV.postInvalidate();
				GalleryViewActivity.bEndFlag = false;
				break;
			case LIGHT:
				mCV = ImageIntegration(mCV, LIGHT);

				m_JNIMethods.LightEffect(mCV, (int) EndX, (int) EndY);
				// if(mCV.m_bVisibleEdge){
				// mCV.m_Draw.m_BGAnimationBitmap =
				// m_JNIMethods.LightEffect(mCV,
				// (int) EndX, (int) EndY);
				// }else{
				// mCV.m_Draw.m_BackgroundBitmap = m_JNIMethods.LightEffect(mCV,
				// (int) EndX, (int) EndY);
				// }

				mCV.destroyDrawingCache();
				EndAnimation = NONE;
				mCV.postInvalidate();
				GalleryViewActivity.bEndFlag = false;
				break;

			case FISH_EYE:
				mCV = ImageIntegration(mCV, LIGHT);

				m_JNIMethods.FisheyeEffect(mCV, (int) EndX, (int) EndY);
				// if(mCV.m_bVisibleEdge){
				// mCV.m_Draw.m_BGAnimationBitmap =
				// m_JNIMethods.FisheyeEffect(mCV,
				// (int) EndX, (int) EndY);
				// }else{
				// mCV.m_Draw.m_BackgroundBitmap =
				// m_JNIMethods.FisheyeEffect(mCV,
				// (int) EndX, (int) EndY);
				// }

				mCV.destroyDrawingCache();
				EndAnimation = NONE;
				mCV.postInvalidate();
				GalleryViewActivity.bEndFlag = false;

				break;
			}
			MyAnimation.process = false;
		}
	}

}