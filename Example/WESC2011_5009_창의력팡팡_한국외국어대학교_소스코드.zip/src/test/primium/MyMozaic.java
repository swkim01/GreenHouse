package test.primium;

import java.util.*;

import test.primium.CustomView.BRUSH;
import android.content.*;
import android.graphics.*;
import android.view.*;

public class MyMozaic {
	public static final int NUMBER = 8;

	public static final int CENTER = -1;

	public static final int SAND = 0;
	public static final int CANDY = 1;
	public static final int COIN = 2;
	public static final int FLOWER = 3;
	public static final int PASTE = 4;
	public static final int COLOR_PAPER = 5;
	public static final int BUTTON = 6;
	public static final int STAR = 7;

	public static final int BLUE = 0xFF0000FF;
	public static final int GREEN = 0xFF00FF00;
	public static final int RED = 0xFFFF0000;
	public static final int CYAN = 0xFF00FFFF;
	public static final int MAGENTA = 0xFFFF00FF;
	public static final int YELLOW = 0xFFFFFF00;
	public static final int BLACK = 0xFF000000;
	public static final int WHITE = 0xFFFFFFFF;

	private static final float PI = 3.1415926f;
	public static final float RADIUS = 30;

	public static final int TOUCH_TOLERANCE = 4;

	int m_nFinalSelectItem = 0;

	private int m_nGetPixel = 0x00000000;
	private int m_nPasteColor = 0xA0FFFFFF;
	
	public BlurMaskFilter m_PaperBlur;
	

	Point RandomPoint = new Point();
	Path m_PastePath = new Path();

	public Bitmap[] m_SideMozaicBMP = new Bitmap[NUMBER];
	public Bitmap m_SandMozaicBMP;
	public Bitmap m_CenterMozaicBMP;

	public LinkedList<MozaicNode> m_CurrentLinkedList = new LinkedList<MozaicNode>();
	public LinkedList<MozaicNode> m_MozaicLinkedList = new LinkedList<MozaicNode>();
	public LinkedList<MozaicNode> m_SandLinkedList = new LinkedList<MozaicNode>();

	public Context m_Context;

	public MyMozaic(Context context) {
		m_Context = context;

		int resizeNum = 9;
		m_SandMozaicBMP = BitmapFactory.decodeResource(
				m_Context.getResources(), R.drawable.mozaic_sand);
		
		for (int n = 0; n < NUMBER; n++) {
			m_SideMozaicBMP[n] = Main.ResizeOptions(m_Context, R.drawable.mozaic00 + n, resizeNum);
		}

		m_CenterMozaicBMP = m_SideMozaicBMP[0];
	}

	public void recycleBitmap() {
		for (int i = 0; i < m_SideMozaicBMP.length; i++) {
			m_SideMozaicBMP[i].recycle();
			m_SideMozaicBMP[i] = null;
		}
		m_CenterMozaicBMP.recycle();
		m_CenterMozaicBMP = null;

		m_SideMozaicBMP = null;

		m_CurrentLinkedList.clear();
		m_MozaicLinkedList.clear();
		m_SandLinkedList.clear();
	}

	private float RandomRange(float f, float g) {
		return (int) (Math.random() * (g - f + 1)) + f;
	}

	public void VisiablePallete(float x, float y, CustomView CV) {
		// CV.m_Draw.m_TempBitmap =
		// Bitmap.createBitmap(CV.m_Draw.m_nDisplayWidth,
		// CV.m_Draw.m_nDisplayHeight,
		// Bitmap.Config.ARGB_8888);
		//
		// CV.m_Draw.m_PasteBitmap =
		// Bitmap.createBitmap(CV.m_Draw.m_nDisplayWidth,
		// CV.m_Draw.m_nDisplayHeight,
		// Bitmap.Config.ARGB_8888);
		//
		// CV.m_TempCanvas = new Canvas(CV.m_Draw.m_TempBitmap);
		// CV.m_Draw.m_TempBitmap.eraseColor(0x00000000);
		//
		// CV.m_PasteCanvas = new Canvas(CV.m_Draw.m_PasteBitmap);
		// CV.m_Draw.m_PasteBitmap.eraseColor(0x00000000);

		CustomView.m_bCheckCenter = CV.m_PaletteMethods.CheckCenter(x, y,
				CV.m_PaletteMethods.m_CenterPoint.x,
				CV.m_PaletteMethods.m_CenterPoint.y, RADIUS);

		if (CustomView.m_bCheckCenter) {
			CV.m_PaletteMethods.m_PrePoint.x = (int) x;
			CV.m_PaletteMethods.m_PrePoint.y = (int) y;
			CV.m_PaletteMethods.m_nSelectItemIndex = CENTER;
			return;
		}

		for (int n = 0; n < CV.m_PaletteMethods.m_nItemNum; n++) {
			if (CV.m_PaletteMethods.m_CurrentPoint[n].y > CV.m_PaletteMethods.m_CenterPoint.y)
				continue;
			CustomView.m_bCheckSide = CV.m_PaletteMethods.CheckCenter(x, y,
					CV.m_PaletteMethods.m_CurrentPoint[n].x,
					CV.m_PaletteMethods.m_CurrentPoint[n].y, RADIUS);

			if (CustomView.m_bCheckSide) {
				CV.m_PaletteMethods.m_nSelectItemIndex = n;
				break;
			}
		}

		CV.m_PaletteMethods.m_PrePoint.x = (int) x;
		CV.m_PaletteMethods.m_PrePoint.y = (int) y;
		return;
	}

	public void TouchUp_Candy(float x, float y, CustomView CV) {
		AttachMozaic(x, y, MyMozaic.CANDY, CV);

		return;
	}

	public void TouchUp_Coin(float x, float y, CustomView CV) {
		AttachMozaic(x, y, MyMozaic.COIN, CV);

		return;
	}

	public void TouchUp_Flower(float x, float y, CustomView CV) {
		AttachMozaic(x, y, MyMozaic.FLOWER, CV);

		return;
	}

	public void TouchUp_ColorPaper(float x, float y, CustomView CV) {
		AttachColorPaper(x, y, MyMozaic.COLOR_PAPER, CV);

		return;
	}
	public void TouchUp_Button(float x, float y, CustomView CV) {
		AttachMozaic(x, y, MyMozaic.BUTTON, CV);

		return;
	}
	public void TouchUp_Star(float x, float y, CustomView CV) {
		AttachMozaic(x, y, MyMozaic.STAR, CV);

		return;
	}

	public void TouchStart_Paste(float x, float y, CustomView CV) {
		CV.m_Draw.m_PasteBitmap.eraseColor(0x00000000);

		CV.m_Draw.m_BrushOption.m_Path.reset();
		CV.m_Draw.m_BrushOption.m_Path.moveTo(x, y);

		m_PastePath.reset();
		m_PastePath.moveTo(x, y);

		CV.m_X = x;
		CV.m_Y = y;

		return;
	}

	public void TouchMove_Paste(float x, float y, CustomView CV) {
		float dx = Math.abs(x - CV.m_X);
		float dy = Math.abs(y - CV.m_Y);
		if (dx >= TOUCH_TOLERANCE || dy >= TOUCH_TOLERANCE) {
			CV.m_Draw.m_BrushOption.m_Path.quadTo(CV.m_X, CV.m_Y,
					(x + CV.m_X) / 2, (y + CV.m_Y) / 2);
			m_PastePath.quadTo(CV.m_X, CV.m_Y, (x + CV.m_X) / 2,
					(y + CV.m_Y) / 2);

			CV.m_X = x;
			CV.m_Y = y;
		}

		return;
	}

	public void TouchUp_Paste(float x, float y, CustomView CV) {
		CV.m_Draw.m_BrushOption.m_Path.lineTo(CV.m_X, CV.m_Y);
		m_PastePath.lineTo(CV.m_X, CV.m_Y);

		CV.m_PasteCanvas.drawPath(CV.m_Draw.m_BrushOption.m_Path,
				CV.m_Draw.m_PastePaint);

		CV.m_Draw.m_BrushOption.m_Path.reset();

		return;
	}

	public void TouchStart_Sand(float x, float y, CustomView CV) {
		AttachSand(x, y, MyMozaic.SAND, CV);

		return;
	}

	public void TouchMove_Sand(float x, float y, CustomView CV) {
		AttachSand(x, y, MyMozaic.SAND, CV);

		return;
	}

	public void TouchUp_Sand(float x, float y, CustomView CV) {
		AttachSand(x, y, MyMozaic.SAND, CV);

		return;
	}

	public void AttachMozaic(float x, float y, int MozaicNum, CustomView CV) {
		if (!CV.isInside(x, y, CV))
			return;

		m_nGetPixel = CV.m_Draw.m_PasteBitmap.getPixel((int) x, (int) y);

		MozaicNode Node_Mozaic = new MozaicNode();

		if (m_nGetPixel == m_nPasteColor) {
			Node_Mozaic.m_bCheckPosition = true;
		} else {
			Node_Mozaic.m_bCheckPosition = false;
		}

		Node_Mozaic.m_nBrushType = MozaicNum;
		Node_Mozaic.m_fTouchPositionX = x
				- (CV.m_Draw.m_BrushOption.m_ChangeBrush.getWidth() / 2);
		Node_Mozaic.m_fTouchPositionY = y
				- (CV.m_Draw.m_BrushOption.m_ChangeBrush.getHeight() / 2);

		CV.m_MyMozaic.m_MozaicLinkedList.add(Node_Mozaic);

		PrintingMozaic(
				x - CV.m_Draw.m_BrushOption.m_ChangeBrush.getWidth() / 2,
				y - CV.m_Draw.m_BrushOption.m_ChangeBrush.getHeight() / 2, CV);

		return;
	}

	public void AttachColorPaper(float x, float y, int MozaicNum, CustomView CV) {
		if (!CV.isInside(x, y, CV))
			return;

		int nVertexSize;

		float fMinRadius;
		float dRadius;

		float fStandradRadian;
		float dRadian;

		Point Vertex;

		m_nGetPixel = CV.m_Draw.m_PasteBitmap.getPixel((int) x, (int) y);

		// Polygon의 꼭지점 = [3, 6]
		nVertexSize = 3 + (int) (4 * Math.random());
		fMinRadius = CV.m_Draw.m_BrushPaint.getStrokeWidth() / 4;
		fStandradRadian = (2 * PI) / nVertexSize;

		MozaicNode Node_ColorPaper = new MozaicNode(nVertexSize);

		if (m_nGetPixel == m_nPasteColor) {
			Node_ColorPaper.m_bCheckPosition = true;
		} else {
			Node_ColorPaper.m_bCheckPosition = false;
		}

		Node_ColorPaper.m_nBrushType = MozaicNum;

		Node_ColorPaper.m_fTouchPositionX = x;
		Node_ColorPaper.m_fTouchPositionY = y;

		Node_ColorPaper.m_nBrushColor = CV.m_Draw.m_BrushPaint.getColor() & 0x00FFFFFF | 0xFF000000;

		for (int n = 0; n < nVertexSize; n++) {
			dRadius = (float) (fMinRadius + fMinRadius * Math.random());
			dRadian = (float) (fStandradRadian * n + fStandradRadian
					* Math.random());

			Vertex = ChangePoint(x, y, dRadius, dRadian + fStandradRadian);

			Node_ColorPaper.m_nPolygonVertex[n] = Vertex;
		}

		Node_ColorPaper.VertexToPath(Node_ColorPaper.m_nPolygonVertex,
				nVertexSize);

		CV.m_MyMozaic.m_MozaicLinkedList.add(Node_ColorPaper);

		CV.m_Draw.m_ColorPaperPaint.setStrokeWidth(1);
		CV.m_Draw.m_ColorPaperPaint.setStyle(Paint.Style.STROKE);
		CV.m_Draw.m_ColorPaperPaint.setColor(0xFF000000);
		PrintingColorPaper(x, y, Node_ColorPaper, CV);

		m_PaperBlur = new BlurMaskFilter(1, BlurMaskFilter.Blur.NORMAL);
		CV.m_Draw.m_ColorPaperPaint.setMaskFilter(m_PaperBlur);
		CV.m_Draw.m_ColorPaperPaint.setColor(0xFF000000);
		CV.m_DrawCanvas.drawPath(Node_ColorPaper.m_PolygonPath, CV.m_Draw.m_ColorPaperPaint);
		
		CV.m_Draw.m_ColorPaperPaint.setStrokeWidth(CV.m_Draw.m_BrushPaint
				.getStrokeWidth());
		CV.m_Draw.m_ColorPaperPaint.setStyle(Paint.Style.FILL);
		CV.m_Draw.m_ColorPaperPaint.setColor(Node_ColorPaper.m_nBrushColor);
		PrintingColorPaper(x, y, Node_ColorPaper, CV);

		return;
	}

	public void AttachSand(float x, float y, int MozaicNum, CustomView CV) {
		if (!CV.isInside(x, y, CV))
			return;

		m_nGetPixel = CV.m_Draw.m_PasteBitmap.getPixel((int) x, (int) y);

		MozaicNode Node_Sand = new MozaicNode();

		if (m_nGetPixel == m_nPasteColor) {

			Node_Sand.m_bCheckPosition = true;
		} else {
			Node_Sand.m_bCheckPosition = false;
		}

		Node_Sand.m_nBrushType = MozaicNum;
		Node_Sand.m_nBrushColor = CV.m_Draw.m_BrushPaint.getColor();
		Node_Sand.m_fTouchPositionX = x
				- (CV.m_Draw.m_BrushOption.m_ChangeBrush.getWidth() / 2);
		Node_Sand.m_fTouchPositionY = y
				- (CV.m_Draw.m_BrushOption.m_ChangeBrush.getHeight() / 2);

		CV.m_MyMozaic.m_SandLinkedList.add(Node_Sand);

		PrintingSand(x - CV.m_Draw.m_BrushOption.m_ChangeBrush.getWidth() / 2,
				y - CV.m_Draw.m_BrushOption.m_ChangeBrush.getHeight() / 2, CV);

		return;
	}

	public void SeparateObject(CustomView CV) {
		CV.m_Draw.m_PasteBitmap.eraseColor(0x00000000);
		CV.m_Draw.m_DrawBitmap.eraseColor(0x00000000);
		//
		// CV.m_MyMozaic.m_MozaicLinkedList.removeAll(CV.m_MyMozaic.m_MozaicLinkedList);
		// CV.m_MyMozaic.m_SandLinkedList.removeAll(CV.m_MyMozaic.m_SandLinkedList);
		// CV.m_MyMozaic.m_PastePath.reset();

		SeparateMozaic(CV);
		SeparateSand(CV);

		// CV.m_Draw.m_TempBitmap.recycle();
		// CV.m_Draw.m_PasteBitmap.recycle();
		//
		// CV.m_TempCanvas = null;
		// CV.m_PasteCanvas = null;

		return;
	}

	public void SeparateMozaic(CustomView CV) {
		CV.m_Draw.m_MozaicBitmap.eraseColor(0x00000000);

		if (CV.m_MyMozaic.m_MozaicLinkedList.size() != 0) {
			for (int n = 0; n < CV.m_MyMozaic.m_MozaicLinkedList.size(); n++) {

				if (CV.m_MyMozaic.m_MozaicLinkedList.get(n).m_bCheckPosition) {
					CV.m_MyMozaic.m_CurrentLinkedList
							.add(CV.m_MyMozaic.m_MozaicLinkedList.get(n));
				}
			}
		}

		PrintingMozaic(CV);

		CV.m_MyMozaic.m_MozaicLinkedList
				.removeAll(CV.m_MyMozaic.m_MozaicLinkedList);

		CV.m_MyMozaic.m_PastePath.reset();

		CV.invalidate();

		return;
	}


	public void SeparateSand(CustomView CV) {

		PrintingSand(CV);

		CV.m_MyMozaic.m_SandLinkedList
				.removeAll(CV.m_MyMozaic.m_SandLinkedList);

		CV.m_MyMozaic.m_PastePath.reset();

		CV.invalidate();

		return;
	}

	public void PrintingMozaic(float x, float y, CustomView CV) {
		CV.m_DrawCanvas.drawBitmap(CV.m_Draw.m_BrushOption.m_ChangeBrush, x, y,
				null);
		return;
	}

	public void PrintingColorPaper(float x, float y, MozaicNode nCurrentNode,
			CustomView CV) {

		CV.m_DrawCanvas.drawPath(nCurrentNode.m_PolygonPath,
				CV.m_Draw.m_ColorPaperPaint);

		return;
	}

	public void PrintingMozaic(CustomView CV) {
		if (CV.m_MyMozaic.m_CurrentLinkedList.size() != 0) {
			for (int n = 0; n < CV.m_MyMozaic.m_CurrentLinkedList.size(); n++) {
				if (CV.m_MyMozaic.m_CurrentLinkedList.get(n).m_nBrushType != MyMozaic.COLOR_PAPER) {

					CV.m_Draw.m_BrushOption.m_ChangeBrush = CV.m_MyMozaic.m_SideMozaicBMP[CV.m_MyMozaic.m_CurrentLinkedList
							.get(n).m_nBrushType];

					CV.m_MozaicCanvas
							.drawBitmap(
									CV.m_Draw.m_BrushOption.m_ChangeBrush,
									CV.m_MyMozaic.m_CurrentLinkedList.get(n).m_fTouchPositionX,
									CV.m_MyMozaic.m_CurrentLinkedList.get(n).m_fTouchPositionY,
									null);
				} else {

					CV.m_Draw.m_ColorPaperPaint.setStyle(Paint.Style.STROKE);
					CV.m_Draw.m_ColorPaperPaint.setStrokeWidth(1);
					CV.m_Draw.m_ColorPaperPaint.setColor(BLACK);
					CV.m_MozaicCanvas
							.drawPath(
									CV.m_MyMozaic.m_CurrentLinkedList.get(n).m_PolygonPath,
									CV.m_Draw.m_ColorPaperPaint);

					CV.m_Draw.m_ColorPaperPaint.setStyle(Paint.Style.FILL);
					CV.m_Draw.m_ColorPaperPaint
							.setStrokeWidth(CV.m_Draw.m_BrushPaint
									.getStrokeWidth());
					CV.m_Draw.m_ColorPaperPaint
							.setColor(CV.m_MyMozaic.m_CurrentLinkedList.get(n).m_nBrushColor);
					CV.m_MozaicCanvas
							.drawPath(
									CV.m_MyMozaic.m_CurrentLinkedList.get(n).m_PolygonPath,
									CV.m_Draw.m_ColorPaperPaint);
				}
			}
		}
		return;
	}

	public void PrintingSand(float x, float y, CustomView CV) {
		float fRadian;
		float fRadius;

		for (int n = 0; n < 40; n++) {
			if (n > 30) {
				fRadius = (float) (40 * Math.random());
			} else if (n >= 20) {
				fRadius = (float) (30 * Math.random());
			} else {
				fRadius = (float) (20 * Math.random());
			}

			fRadian = (float) (2 * PI * Math.random());

			RandomPoint = ChangePoint(x, y, fRadius, fRadian);

			CV.m_DrawCanvas
					.drawBitmap(
							CV.m_Draw.m_BrushOption.m_ChangeBrush,
							RandomPoint.x
									- (CV.m_Draw.m_BrushOption.m_ChangeBrush
											.getWidth() / 2),
							RandomPoint.y
									- (CV.m_Draw.m_BrushOption.m_ChangeBrush
											.getHeight() / 2), null);

		}

		return;
	}

	public void PrintingSand(CustomView CV) {

		if (CV.m_MyMozaic.m_SandLinkedList.size() != 0) {

			CV.m_Draw.m_BrushOption.m_ChangeBrush = CV.m_MyMozaic.m_SandMozaicBMP;

			CV.m_Draw.m_BrushOption.m_ChangeBrush = CV.ChangeBrush(
					CV.m_Draw.m_BrushOption.m_ChangeBrush, 0xBB000000,
					CV.m_Draw.m_BrushPaint.getColor());

			for (int n = 0; n < CV.m_MyMozaic.m_SandLinkedList.size(); n++) {
				if (CV.m_MyMozaic.m_SandLinkedList.get(n).m_bCheckPosition) {
					float x = CV.m_MyMozaic.m_SandLinkedList.get(n).m_fTouchPositionX;
					float y = CV.m_MyMozaic.m_SandLinkedList.get(n).m_fTouchPositionY;

					CV.m_Draw.m_BrushOption.m_ChangeBrush = CV
							.ChangeBrush(
									CV.m_Draw.m_BrushOption.m_ChangeBrush,
									0xBB000000,
									CV.m_MyMozaic.m_SandLinkedList.get(n).m_nBrushColor);

					float fRadian;
					float fRadius;

					for (int nCount = 0; nCount < 40; nCount++) {
						if (nCount > 30) {
							fRadius = (float) (40 * Math.random());
						} else if (nCount >= 20) {
							fRadius = (float) (30 * Math.random());
						} else {
							fRadius = (float) (20 * Math.random());
						}

						fRadian = (float) (2 * PI * Math.random());

						RandomPoint = ChangePoint(x, y, fRadius, fRadian);

						CV.m_BrushCanvas
								.drawBitmap(
										CV.m_Draw.m_BrushOption.m_ChangeBrush,
										RandomPoint.x
												- (CV.m_Draw.m_BrushOption.m_ChangeBrush
														.getWidth() / 2),
										RandomPoint.y
												- (CV.m_Draw.m_BrushOption.m_ChangeBrush
														.getHeight() / 2), null);
					}
				}
			}
		}

		return;
	}

	public void SingleTapConfirmed(MotionEvent e, CustomView CV) {
		if(CV.m_PaletteMethods.m_nSelectItemIndex > NUMBER)
		{
			return;
		}
		SelectBrush(CV.m_PaletteMethods.m_nSelectItemIndex, CV);

		if (CV.m_PaletteMethods.m_nSelectItemIndex != CENTER) {
			m_nFinalSelectItem = CV.m_PaletteMethods.m_nSelectItemIndex;
			m_CenterMozaicBMP = m_SideMozaicBMP[m_nFinalSelectItem];
		}
		CV.m_PaletteMethods.m_CenterBitmap = m_CenterMozaicBMP;

		CV.m_Draw.m_bVisiablePallete = false;
		CV.m_Draw.m_BrushOption.m_bEraser = false;
		CV.m_Draw.m_BrushPaint.setXfermode(null);
		CV.invalidate();
		return;
	}

	public void SelectBrush(int nIndex, CustomView CV) {

		switch (nIndex) {
		case CENTER:

			SelectBrush(m_nFinalSelectItem, CV);

			break;
		case SAND:
			CustomView.brush = BRUSH.Sand;
			CV.m_Draw.m_BrushPaint.setColor(CV.m_MyColor.m_nCurrentColor);
			CV.m_Draw.m_BrushOption.m_ChangeBrush = CV.ChangeBrush(
					m_SandMozaicBMP, 0xBB000000,
					CV.m_Draw.m_BrushPaint.getColor());
			break;
		case CANDY:
			CustomView.brush = BRUSH.Candy;
			CV.m_Draw.m_BrushOption.m_ChangeBrush = m_SideMozaicBMP[CANDY];
			break;

		case COIN:
			CustomView.brush = BRUSH.Coin;
			CV.m_Draw.m_BrushOption.m_ChangeBrush = m_SideMozaicBMP[COIN];
			break;

		case FLOWER:
			CustomView.brush = BRUSH.Flower;
			CV.m_Draw.m_BrushOption.m_ChangeBrush = m_SideMozaicBMP[FLOWER];
			break;

		case PASTE:
			CustomView.brush = BRUSH.Paste;
			CV.m_Draw.m_BrushPaint.setMaskFilter(null);

			break;

		case COLOR_PAPER:
			CustomView.brush = BRUSH.ColorPaper;
			CV.m_Draw.m_BrushPaint.setMaskFilter(null);
			break;
		case BUTTON:
			CustomView.brush = BRUSH.Button;
			CV.m_Draw.m_BrushOption.m_ChangeBrush = m_SideMozaicBMP[BUTTON];
			break;
		case STAR:
			CustomView.brush = BRUSH.Star;
			CV.m_Draw.m_BrushOption.m_ChangeBrush = m_SideMozaicBMP[STAR];
			break;
		}
	}

	public void Initialization(CustomView CV) {
		CV.m_PaletteMethods.m_nItemNum = MyMozaic.NUMBER;

		CV.m_PaletteMethods.m_SideBitmap = m_SideMozaicBMP;
		CV.m_PaletteMethods.m_CenterBitmap = m_CenterMozaicBMP;

	}

	// Angle을 Radian으로 변환
	public float AngleToRadian(float Angle) {
		float Radian;

		Radian = 2 * PI * (Angle / 360);
		return Radian;
	}

	// Radian을 Angle로 변환
	public float RadianToAngle(float Radian) {
		float Angle;

		Angle = 360 * (Radian / (2 * PI));
		return Angle;
	}

	// 중심점에 대해 Radian의 각도를 가지며 Radius만큼 떨어진 곳의 좌표
	public Point ChangePoint(float CenterPositionX, float CenterPositionY,
			float Radius, float dRadian) {
		Point dPoint = new Point();

		dPoint.x = (int) (CenterPositionX + Radius * Math.cos(dRadian));
		dPoint.y = (int) (CenterPositionY + Radius * Math.sin(dRadian));

		return dPoint;
	}
}
