package test.primium;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.WindowManager;
import android.widget.ImageView;

public class AnimationActivity extends Activity {
	
	private ImageView AnimationView;
	private AnimationDrawable mAnimationDrawble;
	private int Mode = MyAnimation.NONE;
	private Bitmap Animation1;
	private Bitmap Animation2;
	private Drawable mDrawable1;
	private Drawable mDrawable2;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		Mode = getIntent().getIntExtra("Mode", MyAnimation.NONE);
		setContentView(R.layout.animationlayout);
		AnimationView = (ImageView)findViewById(R.id.AnimationView);
		mAnimationDrawble = new AnimationDrawable();
	}
	
	@Override
	public void onResume(){
		super.onResume();
		
		
		new Handler().postDelayed(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
//				AnimationView.setBackgroundResource(R.drawable.totalanimation);
				AnimationView.setBackgroundDrawable(mAnimationDrawble);
//				mAnimationDrawble = (AnimationDrawable) AnimationView.getBackground();
				try {
					switch(Mode){
					case MyAnimation.NONE:
						break;
					case MyAnimation.LIGHT:
						Animation1 = BitmapFactory.decodeResource(getResources(), R.drawable.lightanimation1);
						Animation2 = BitmapFactory.decodeResource(getResources(), R.drawable.lightanimation2);
//					AnimationView.setBackgroundResource(R.drawable.lightanimation);
						break;
					case MyAnimation.FIRE:
						Animation1 = BitmapFactory.decodeResource(getResources(), R.drawable.fireanimation1);
						Animation2 = BitmapFactory.decodeResource(getResources(), R.drawable.fireanimation2);
//					AnimationView.setBackgroundResource(R.drawable.fireanimation);
						break;
					case MyAnimation.RAIN:
						Animation1 = BitmapFactory.decodeResource(getResources(), R.drawable.rainanimation1);
						Animation2 = BitmapFactory.decodeResource(getResources(), R.drawable.rainanimation2);
//					AnimationView.setBackgroundResource(R.drawable.rainanimation);
						break;
					case MyAnimation.FISH_EYE:
						Animation1 = BitmapFactory.decodeResource(getResources(), R.drawable.fisheyeanimation1);
						Animation2 = BitmapFactory.decodeResource(getResources(), R.drawable.fisheyeanimation2);
						
//					AnimationView.setBackgroundResource(R.drawable.rainanimation);
						break;
					}
				} catch (Exception e) {
					System.out
							.println("AnimationActivity.onResume().new Runnable() {...}.run()");
					Log.e("Creative", e.toString());
					System.gc();
					e.printStackTrace();
					Intent intent = new Intent(AnimationActivity.this , AnimationActivity.class);
					intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(intent);
					
					// TODO: handle exception
				}
				mDrawable1 = new BitmapDrawable(Animation1);
				mDrawable2 = new BitmapDrawable(Animation2);
				mAnimationDrawble.addFrame(mDrawable1, 200);
				mAnimationDrawble.addFrame(mDrawable2, 200);
				mAnimationDrawble.addFrame(mDrawable1, 200);
				mAnimationDrawble.addFrame(mDrawable2, 200);
				mAnimationDrawble.addFrame(mDrawable1, 200);
				mAnimationDrawble.addFrame(mDrawable2, 200);
				mAnimationDrawble.addFrame(mDrawable1, 200);
				mAnimationDrawble.addFrame(mDrawable2, 200);
				mAnimationDrawble.start();
			}
		}, 100);
		new Handler().postDelayed(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				mAnimationDrawble.stop();
				AnimationView.setBackgroundDrawable(null);
				mAnimationDrawble.clearColorFilter();
				try {
					if(Animation1!=null)
						Animation1.recycle();
					if(Animation2!=null)
						Animation2.recycle();
				} catch (Exception e) {
					e.printStackTrace();
					// TODO: handle exception
				}
				MyAnimation.EndAnimation = MyAnimation.NONE;//Mode;
//				MyAnimation.process = false;
				finish();
			}
		}, 1500);
		
	}
}
