package test.primium;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Debug;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Gallery;
import android.widget.ImageView;

public class BaseGallery extends Activity {

	private static ArrayList<Bitmap> Image;
	private ArrayList<BitmapDrawable> drawable;
	private static final int MAX_ITEM = 8;

	private WindowManager wm;
	private BitmapFactory.Options options;
	private Display disp;
	private Drawable mDrawable;
	private MediaPlayer mPlayer_BaseGalleryClick;
	private static Bitmap FourthBackground;
	private static boolean bNullCheck = false;
	private Intent intent;
	private String StrPath;
	private int Position; 
//	private int Select;
	private boolean Process;
	private Gallery gal;
	private MediaPlayer mPlayer_Click;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		intent = getIntent();
		
		
		
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
		bNullCheck = true;
		Image = new ArrayList<Bitmap>(MAX_ITEM);
		drawable = new ArrayList<BitmapDrawable>(MAX_ITEM);
		for (int i = 0; i < MAX_ITEM; i++) {
			Image.add(null);
			drawable.add(null);
		}

		setContentView(R.layout.fourth);
		mPlayer_BaseGalleryClick = MediaPlayer.create(this, R.raw.click);
		
		gal = (Gallery) findViewById(R.id.fouthView);
		wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
		disp = wm.getDefaultDisplay();
		options = new BitmapFactory.Options();
		BitmapOption.getSampleSize(options, disp, null, getResources(),
				R.drawable.background3);
		Process = false;
		FourthBackground = BitmapFactory.decodeResource(getResources(),
				R.drawable.background3, options);
		mDrawable = new BitmapDrawable(FourthBackground);
		
		gal.setBackgroundDrawable(mDrawable);
		gal.setAdapter(new ImageAdapter(this));
		gal.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView parent, View v, int position,
					long id) {
				mPlayer_BaseGalleryClick.start();
				intent = new Intent(BaseGallery.this,GalleryViewActivity.class);

				intent.putExtra("ImageNum", position + 1);
				intent.putExtra("ImagePath", StrPath);
				intent.putExtra("select", 3);
				intent.putExtra("Mode", 0);
				finish();
				startActivity(intent);
				Process = true;
			}
		});
	}

	public static void recycleBitmap() {
		if (bNullCheck) {
			FourthBackground.recycle();
			for (int n = 0; n < MAX_ITEM; n++)
				if (Image.get(n) != null)
					Image.get(n).recycle();
			bNullCheck = false;
		}
	}
	
	@Override
	public void onResume()
	{
		super.onResume();
		
		Intent svc = new Intent(this , BackgroundSoundService.class);
		startService(svc);
//		try {
//			BackgroundSoundService.mp.start();
//		} catch (Exception e) {
//
//			e.printStackTrace();
//		}
	}
	@Override
	public void onPause(){
		super.onPause();
		if(!Process && BackgroundSoundService.mp.isPlaying()){
			BackgroundSoundService.mp.pause();
		}
	}
	public void onStop(){
		super.onStop();
		if (!Process && BackgroundSoundService.mp.isPlaying())
			BackgroundSoundService.mp.pause();
		System.out.println("SecPagePageActivity onStop()");
	}
	@Override
	public void onDestroy() {
		super.onDestroy();
		for (int i = 0; i < MAX_ITEM; i++) {
			if (Image.get(i) != null)
				Image.get(i).recycle();
		}
		drawable = null;

	}

	public class ImageAdapter extends BaseAdapter {
		int mGalleryItemBackground;
		private Context mContext;

		private Integer[] mImageIds = { R.drawable.rebasicimage1,
				R.drawable.rebasicimage2, R.drawable.rebasicimage3,
				R.drawable.rebasicimage4, R.drawable.rebasicimage5,
				R.drawable.rebasicimage6, R.drawable.rebasicimage7,
				R.drawable.rebasicimage8 };

		public ImageAdapter(Context c) {
			mContext = c;
			// See res/values/attrs.xml for the <declare-styleable> that defines
			// Gallery1.
			TypedArray a = obtainStyledAttributes(R.styleable.Gallery1);
			mGalleryItemBackground = a.getResourceId(
					R.styleable.Gallery1_android_galleryItemBackground, 0);
			a.recycle();
		}

		@Override
		public int getCount() {
			return mImageIds.length;
		}

		@Override
		public Object getItem(int position) {
			return mImageIds[position];
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			ImageView imageView;

			if (convertView == null)
				imageView = new ImageView(mContext);
			else
				imageView = (ImageView) convertView;

			if (Image == null || Image.get(position) == null) {
				Image.add(position, BitmapFactory.decodeResource(
						getResources(), mImageIds[position]));
				drawable.add(position, new BitmapDrawable(Image.get(position)));
			}
			Log.d("DEBUG",
					"Heap Size : "
							+ Long.toString(Debug.getNativeHeapAllocatedSize()));
			imageView.setImageDrawable(drawable.get(position));

			imageView.setScaleType(ImageView.ScaleType.FIT_XY);
			imageView.setLayoutParams(new Gallery.LayoutParams(400, 360));

			imageView.setBackgroundResource(mGalleryItemBackground);

			return imageView;
		}
	}

	@Override
	public void onBackPressed() {
		// TODO 
//		mPlayer_Click.start();
//		intent = new Intent(this, ThirdPageActivity.class);
//		intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//		startActivity(intent);
		Process = true;
		finish();
		Intent i = new Intent(this , ThirdPageActivity.class);
		startActivity(i);
	}
}
