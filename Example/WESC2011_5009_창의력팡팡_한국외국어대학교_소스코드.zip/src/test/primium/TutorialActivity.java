package test.primium;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ViewFlipper;

public class TutorialActivity extends Activity{
	
	private ViewFlipper Flipper;
	
	private final int MainPage = 0;
	private final int BrushPage = 1;
	private final int PalettePage = 2;
	private final int Sizepage = 3;
	private final int StickerPage = 4;
	private final int AnimationPage = 5;
	private final int EraserPage = 6;
	
	private int BrushTutorialSize = 4;
	private int PaletteTutorialSize = 4;
	private int SizeTutorialSize = 3;
	private int StickerTutorialSize = 14;
	private int AnimationTutorialSize = 11;
	private int EraserTutorialSize = 10;
	private boolean bEndFlag = false;
	private Display disp;
	private LinearLayout TutorialMenu;
	private Bitmap TutorialBG;
	private WindowManager wm;
	private Button NextBtn;
	private RelativeLayout NextBtnLayout;
	public MediaPlayer mPlayer_Click;
	private int CurPage = MainPage;
	private int FlipperPage = 0;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		
		mPlayer_Click = MediaPlayer.create(this, R.raw.click);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		setContentView(R.layout.tutorail);
		setMainBtnListener();
		Flipper = (ViewFlipper)findViewById(R.id.TutorialFlipper);
		NextBtn = (Button)findViewById(R.id.NextBtn);
		NextBtnLayout = (RelativeLayout)findViewById(R.id.NextBtnLayout);
		TutorialMenu = (LinearLayout)findViewById(R.id.TutorialMenu);
		wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
		disp = wm.getDefaultDisplay();
		TutorialBG = BitmapFactory.decodeResource(
				getResources(), R.drawable.tutorailmenu);
		TutorialMenu.setBackgroundDrawable(new BitmapDrawable(TutorialBG));
		
		NextBtn.setOnClickListener(NextBtnListe);
	}

	@Override
	public void onResume()
	{
		super.onResume();
		
		Intent svc = new Intent(this, BackgroundSoundService.class);
		startService(svc);
//		BackgroundSoundService.mp.start();
	}
	
	
	@Override
	public void onPause(){
		super.onPause();
		if(!bEndFlag)
			BackgroundSoundService.mp.pause();
	}
	
	
	private Button.OnClickListener MainBtnListener = new View.OnClickListener() {
		@Override
		public void onClick(View v) {
			switch(v.getId()){
			
			case R.id.BrushTutorialBtn:
				if(CurPage != BrushPage){
					mPlayer_Click.start();
					CurPage = BrushPage;
					Flipper.setVisibility(View.VISIBLE);
					NextBtnLayout.setVisibility(View.VISIBLE);
					NextBtn.setVisibility(View.VISIBLE);
					TutorialMenu.setVisibility(View.INVISIBLE);
					TutorialBG.recycle();
//					for(int n = 0 ; n < BrushTutorialSize ; n++){
//						ImageView IV = new ImageView(TutorialActivity.this);
//						IV.setBackgroundResource(R.drawable.brushtutorial00+n);
//						Flipper.addView(IV, n);
//					}
					ImageView IV = new ImageView(TutorialActivity.this);
					IV.setBackgroundResource(R.drawable.brushtutorial00+FlipperPage);
					Flipper.addView(IV, 0);
					FlipperPage++;
				}
				break;
			case R.id.PaletteTutorialBtn:
				if(CurPage != PalettePage){
					mPlayer_Click.start();
					CurPage = PalettePage;
					Flipper.setVisibility(View.VISIBLE);
					NextBtnLayout.setVisibility(View.VISIBLE);
					NextBtn.setVisibility(View.VISIBLE);
					TutorialMenu.setVisibility(View.INVISIBLE);
					TutorialBG.recycle();
//					for(int n = 0 ; n < PaletteTutorialSize ; n++){
//						ImageView IV = new ImageView(TutorialActivity.this);
//						IV.setBackgroundResource(R.drawable.palettetutorial00+n);
//						Flipper.addView(IV, n);
					ImageView IV = new ImageView(TutorialActivity.this);
					IV.setBackgroundResource(R.drawable.palettetutorial00+FlipperPage);
					Flipper.addView(IV, 0);
					FlipperPage++;
//					}
				}
				break;
			case R.id.SizeTutorialBtn:
				if(CurPage != Sizepage){
					mPlayer_Click.start();
					CurPage = Sizepage;
					Flipper.setVisibility(View.VISIBLE);
					NextBtnLayout.setVisibility(View.VISIBLE);
					NextBtn.setVisibility(View.VISIBLE);
					TutorialMenu.setVisibility(View.INVISIBLE);
					TutorialBG.recycle();
//					for(int n = 0 ; n < SizeTutorialSize ; n++){
//						ImageView IV = new ImageView(TutorialActivity.this);
//						IV.setBackgroundResource(R.drawable.sizetutorial00+n);
//						Flipper.addView(IV, n);
//					}
					ImageView IV = new ImageView(TutorialActivity.this);
					IV.setBackgroundResource(R.drawable.sizetutorial00+FlipperPage);
					Flipper.addView(IV, 0);
					FlipperPage++;
				}
				break;
			case R.id.StickerTutorialBtn:
				if(CurPage != Sizepage){
					mPlayer_Click.start();
					CurPage = StickerPage;
					Flipper.setVisibility(View.VISIBLE);
					NextBtnLayout.setVisibility(View.VISIBLE);
					NextBtn.setVisibility(View.VISIBLE);
					TutorialMenu.setVisibility(View.INVISIBLE);
					TutorialBG.recycle();
//					for(int n = 0 ; n < StickerTutorialSize ; n++){
//						ImageView IV = new ImageView(TutorialActivity.this);
//						IV.setBackgroundResource(R.drawable.stickertutorial00+n);
//						Flipper.addView(IV, n);
//					}
					ImageView IV = new ImageView(TutorialActivity.this);
					IV.setBackgroundResource(R.drawable.stickertutorial00+FlipperPage);
					Flipper.addView(IV, 0);
					FlipperPage++;
				}
				break;
			case R.id.AnimationTutorialBtn:
				if(CurPage != AnimationPage){
					mPlayer_Click.start();
					CurPage = AnimationPage;
					Flipper.setVisibility(View.VISIBLE);
					NextBtnLayout.setVisibility(View.VISIBLE);
					NextBtn.setVisibility(View.VISIBLE);
					TutorialMenu.setVisibility(View.INVISIBLE);
					TutorialBG.recycle();
//					for(int n = 0 ; n < AnimationTutorialSize ; n++){
//						ImageView IV = new ImageView(TutorialActivity.this);
//						IV.setBackgroundResource(R.drawable.animationtutorial00+n);
//						Flipper.addView(IV, n);
//					}
					ImageView IV = new ImageView(TutorialActivity.this);
					IV.setBackgroundResource(R.drawable.animationtutorial00+FlipperPage);
					Flipper.addView(IV, 0);
					FlipperPage++;
				}
				break;
			case R.id.EraserTutorialBtn:
				if(CurPage != EraserPage){
					mPlayer_Click.start();
					CurPage = EraserPage;
					Flipper.setVisibility(View.VISIBLE);
					NextBtnLayout.setVisibility(View.VISIBLE);
					NextBtn.setVisibility(View.VISIBLE);
					TutorialMenu.setVisibility(View.INVISIBLE);
					TutorialBG.recycle();
//					for(int n = 0 ; n < EraserTutorialSize ; n++){
//						ImageView IV = new ImageView(TutorialActivity.this);
//						IV.setBackgroundResource(R.drawable.erasertutorial00+n);
//						Flipper.addView(IV, n);
//					}
					ImageView IV = new ImageView(TutorialActivity.this);
					IV.setBackgroundResource(R.drawable.erasertutorial00+FlipperPage);
					Flipper.addView(IV, 0);
					FlipperPage++;
				}
				break;
			}
		}
		
	};
	
	
	private Button.OnClickListener NextBtnListe = new View.OnClickListener() {
		@Override
		public void onClick(View v) {
			ImageView IV = new ImageView(TutorialActivity.this);
			mPlayer_Click.start();
			switch(CurPage){
			case BrushPage:
				
				if(FlipperPage == BrushTutorialSize){
					TutorialMenu.setVisibility(View.VISIBLE);
					TutorialBG = BitmapFactory.decodeResource(
							getResources(), R.drawable.tutorailmenu);
					TutorialMenu.setBackgroundDrawable(new BitmapDrawable(TutorialBG));
					FlipperPage = 0;
					CurPage = MainPage;
					NextBtnLayout.setVisibility(View.INVISIBLE);
					NextBtn.setVisibility(View.INVISIBLE);
					Flipper.removeAllViews();
					return;
				}
				IV.setBackgroundResource(R.drawable.brushtutorial00+FlipperPage);
				Flipper.addView(IV, 1);
				Flipper.showNext();
				Flipper.removeViewAt(0);
				FlipperPage++;
				
//				Flipper.showNext();
//				FlipperPage++;
//				if(FlipperPage == BrushTutorialSize){
//					TutorialMenu.setVisibility(View.VISIBLE);
//					TutorialBG = BitmapFactory.decodeResource(
//							getResources(), R.drawable.tutorailmenu);
//					TutorialMenu.setBackgroundDrawable(new BitmapDrawable(TutorialBG));
//					FlipperPage = 0;
//					CurPage = MainPage;
//					NextBtnLayout.setVisibility(View.INVISIBLE);
//					NextBtn.setVisibility(View.INVISIBLE);
//					Flipper.removeAllViews();
//					
//				}
				break;
			case PalettePage:
				if(FlipperPage == PaletteTutorialSize){
					TutorialMenu.setVisibility(View.VISIBLE);
					TutorialBG = BitmapFactory.decodeResource(
							getResources(), R.drawable.tutorailmenu);
					TutorialMenu.setBackgroundDrawable(new BitmapDrawable(TutorialBG));
					FlipperPage = 0;
					CurPage = MainPage;
					NextBtnLayout.setVisibility(View.INVISIBLE);
					NextBtn.setVisibility(View.INVISIBLE);
					Flipper.removeAllViews();
					return;
				}
				IV.setBackgroundResource(R.drawable.palettetutorial00+FlipperPage);
				Flipper.addView(IV, 1);
				Flipper.showNext();
				Flipper.removeViewAt(0);
				FlipperPage++;
				break;
			case Sizepage:
				if(FlipperPage == SizeTutorialSize){
					TutorialMenu.setVisibility(View.VISIBLE);
					TutorialBG = BitmapFactory.decodeResource(
							getResources(), R.drawable.tutorailmenu);
					TutorialMenu.setBackgroundDrawable(new BitmapDrawable(TutorialBG));
					FlipperPage = 0;
					CurPage = MainPage;
					NextBtnLayout.setVisibility(View.INVISIBLE);
					NextBtn.setVisibility(View.INVISIBLE);
					Flipper.removeAllViews();
					return;
				}
				IV.setBackgroundResource(R.drawable.sizetutorial00+FlipperPage);
				Flipper.addView(IV, 1);
				Flipper.showNext();
				Flipper.removeViewAt(0);
				FlipperPage++;
				break;
			case StickerPage:
				if(FlipperPage == StickerTutorialSize){
					TutorialMenu.setVisibility(View.VISIBLE);
					TutorialBG = BitmapFactory.decodeResource(
							getResources(), R.drawable.tutorailmenu);
					TutorialMenu.setBackgroundDrawable(new BitmapDrawable(TutorialBG));
					FlipperPage = 0;
					CurPage = MainPage;
					NextBtnLayout.setVisibility(View.INVISIBLE);
					NextBtn.setVisibility(View.INVISIBLE);
					Flipper.removeAllViews();
					return;
				}
				IV.setBackgroundResource(R.drawable.stickertutorial00+FlipperPage);
				Flipper.addView(IV, 1);
				Flipper.showNext();
				Flipper.removeViewAt(0);
				FlipperPage++;
				break;
			case AnimationPage:
				if(FlipperPage == AnimationTutorialSize){
					TutorialMenu.setVisibility(View.VISIBLE);
					TutorialBG = BitmapFactory.decodeResource(
							getResources(), R.drawable.tutorailmenu);
					TutorialMenu.setBackgroundDrawable(new BitmapDrawable(TutorialBG));
					FlipperPage = 0;
					CurPage = MainPage;
					NextBtnLayout.setVisibility(View.INVISIBLE);
					NextBtn.setVisibility(View.INVISIBLE);
					Flipper.removeAllViews();
					return;
				}
				IV.setBackgroundResource(R.drawable.animationtutorial00+FlipperPage);
				Flipper.addView(IV, 1);
				Flipper.showNext();
				Flipper.removeViewAt(0);
				FlipperPage++;
				break;
			case EraserPage:
				if(FlipperPage == EraserTutorialSize){
					TutorialMenu.setVisibility(View.VISIBLE);
					TutorialBG = BitmapFactory.decodeResource(
							getResources(), R.drawable.tutorailmenu);
					TutorialMenu.setBackgroundDrawable(new BitmapDrawable(TutorialBG));
					FlipperPage = 0;
					CurPage = MainPage;
					NextBtnLayout.setVisibility(View.INVISIBLE);
					NextBtn.setVisibility(View.INVISIBLE);
					Flipper.removeAllViews();
					return;
				}
				IV.setBackgroundResource(R.drawable.erasertutorial00+FlipperPage);
				Flipper.addView(IV, 1);
				Flipper.showNext();
				Flipper.removeViewAt(0);
				FlipperPage++;
				break;
				
			}
		}
	};
	
	@Override
	public void onBackPressed() {
		mPlayer_Click.start();
		if(CurPage == MainPage){
			bEndFlag = true;
			TutorialMenu.setVisibility(View.INVISIBLE);
			TutorialMenu.setBackgroundDrawable(null);
			TutorialBG.recycle();
			Intent i = new Intent(this , FirstPageActivity.class);
			startActivity(i);
			finish();
		}
		else{
			FlipperPage = 0;
			CurPage = MainPage;
			bEndFlag = true;
			TutorialMenu.setVisibility(View.VISIBLE);
			TutorialBG = BitmapFactory.decodeResource(
					getResources(), R.drawable.tutorailmenu);
			TutorialMenu.setBackgroundDrawable(new BitmapDrawable(TutorialBG));
			NextBtnLayout.setVisibility(View.INVISIBLE);
			NextBtn.setVisibility(View.INVISIBLE);
			Flipper.removeAllViews();
		}
	}
	
	private void setMainBtnListener(){
		findViewById(R.id.BrushTutorialBtn).setOnClickListener(MainBtnListener);
		findViewById(R.id.PaletteTutorialBtn).setOnClickListener(MainBtnListener);
		findViewById(R.id.SizeTutorialBtn).setOnClickListener(MainBtnListener);
		findViewById(R.id.StickerTutorialBtn).setOnClickListener(MainBtnListener);
		findViewById(R.id.AnimationTutorialBtn).setOnClickListener(MainBtnListener);
		findViewById(R.id.EraserTutorialBtn).setOnClickListener(MainBtnListener);
	}
}
