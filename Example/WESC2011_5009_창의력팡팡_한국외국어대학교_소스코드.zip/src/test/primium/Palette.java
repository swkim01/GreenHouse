package test.primium;

import android.graphics.*;

public class Palette {
	private static final float PI = 3.1415926f;

	private static final int MAX_ITEM = 8;
	private static final float DISTANCE = 80;

	private static final float MAX_RADIUS = 2 * PI;
	private static final float MIN_RADIUS = 0.5f;
	public static final float RADIUS = 30;

	private static final float WIDTH = 50;
	private static final float RATIO = WIDTH / MAX_RADIUS;

	public float m_CurrentRadius = 0;

	public int m_nItemNum = 0;
	public int m_nSelectItemIndex = 0;

	public float m_dAngle = 0;
	public float m_dRadian = 0;

	public float m_Radian = 0;
	public float m_RatioRadius = 0;

	public Point m_PrePoint = new Point();
	public Point m_PostPoint = new Point();
	public Point m_CenterPoint = new Point();
	public Point[] m_CurrentPoint = new Point[MAX_ITEM];

	public int[] nColor = { 0xFF0000FF, 0xFF00FF00, 0xFFFF0000, 0xFF00FFFF,
			0xFFFF00FF, 0xFFFFFF00, 0xFFFFFFFF, 0xFF000000 };

	public Bitmap[] m_SideBitmap = new Bitmap[MAX_ITEM];
	public Bitmap m_CenterBitmap;

	public Palette() {
		for (int n = 0; n < MAX_ITEM; n++) {
			m_CurrentPoint[n] = new Point();
			m_CurrentPoint[n].x = 0;
			m_CurrentPoint[n].y = 0;
			new BitmapFactory();
			m_SideBitmap[n] = BitmapFactory.decodeStream(null);
		}
	}

	public Palette(int CenterX, int CenterY) {
		for (int n = 0; n < MAX_ITEM; n++) {
			m_CurrentPoint[n] = new Point();
			m_CurrentPoint[n].x = 0;
			m_CurrentPoint[n].y = 0;
		}

		m_CenterPoint.x = CenterX;
		m_CenterPoint.y = CenterY;
	}

	public void recycleBitmap() {
		for (int i = 0; i < m_nItemNum; i++) {
			if (m_SideBitmap[i] != null) {
				m_SideBitmap[i].recycle();

				m_SideBitmap[i] = null;
			}
		}
		if (m_CenterBitmap != null) {
			m_CenterBitmap.recycle();
			m_CenterBitmap = null;
		}

		m_SideBitmap = null;
	}

	// Color Mix
	public int MixColor(int Color1, int Color2) {
		int[] nAlpha = new int[3];
		int[] nRed = new int[3];
		int[] nGreen = new int[3];
		int[] nBlue = new int[3];

		nAlpha[0] = Color.alpha(Color1);
		nRed[0] = Color.red(Color1);
		nGreen[0] = Color.green(Color1);
		nBlue[0] = Color.blue(Color1);

		nAlpha[1] = Color.alpha(Color2);
		nRed[1] = Color.red(Color2);
		nGreen[1] = Color.green(Color2);
		nBlue[1] = Color.blue(Color2);

		nAlpha[2] = (nAlpha[0] + nAlpha[1]) / 2;
		nRed[2] = (nRed[0] + nRed[1]) / 2;
		nGreen[2] = (nGreen[0] + nGreen[1]) / 2;
		nBlue[2] = (nBlue[0] + nBlue[1]) / 2;

		return Color.argb(nAlpha[2], nRed[2], nGreen[2], nBlue[2]);
	}

	// 3점 사이에 끼인각
	public float IncludedRadian(Point m_PrePoint, Point m_PostPoint,
			Point m_CenterPoint) {
		float dRadian;

		float dx1 = m_PrePoint.x - m_CenterPoint.x;
		float dy1 = m_PrePoint.y - m_CenterPoint.y;

		float dx2 = m_PostPoint.x - m_CenterPoint.x;
		float dy2 = m_PostPoint.y - m_CenterPoint.y;

		float dRadian1 = (float) Math.atan2(dy1, dx1);
		float dRadian2 = (float) Math.atan2(dy2, dx2);

		dRadian = dRadian2 - dRadian1;

		return dRadian;
	}

	// 중심점에 대해 Radian의 각도를 가지며 Radius만큼 떨어진 곳의 좌표
	public Point ChangePoint(Point CenterPoint, float Radius, float dRadian) {
		Point dPoint = new Point();

		dPoint.x = (int) (CenterPoint.x + Radius * Math.cos(dRadian));
		dPoint.y = (int) (CenterPoint.y + Radius * Math.sin(dRadian));

		return dPoint;
	}
	
	public Point ChangePoint(float PositionX, float PositionY, float Radius, float dRadian) {
		Point dPoint = new Point();

		dPoint.x = (int) (PositionX + Radius * Math.cos(dRadian));
		dPoint.y = (int) (PositionY + Radius * Math.sin(dRadian));

		return dPoint;
	}

	// Angle을 Radian으로 변환
	public float AngleToRadian(float Angle) {
		float Radian;

		Radian = 2 * PI * (Angle / 360);
		return Radian;
	}

	// Radian을 Angle로 변환
	public float RadianToAngle(float Radian) {
		float Angle;

		Angle = 360 * (Radian / (2 * PI));
		return Angle;
	}

	public Point ChangeMatrix(Point CenterPoint, Point ImageCenter,
			Point ConvertPoint) {
		Point dPoint = new Point();

		dPoint.x = CenterPoint.x - ImageCenter.x;
		dPoint.y = CenterPoint.y - ImageCenter.y;

		ConvertPoint.x -= dPoint.x;
		ConvertPoint.y -= dPoint.y;

		return ConvertPoint;
	}

	public boolean CheckCenter(float TouchX, float TouchY, float CenterX,
			float CenterY, float nRadius) {
		float fDistance = 0;
		float dx, dy;

		dx = TouchX - CenterX;
		dy = TouchY - CenterY;

		fDistance = (float) Math.sqrt(Math.pow(dx, 2) + Math.pow(dy, 2));

		if (fDistance < nRadius) {
			return true;
		} else {
			return false;
		}
	}

	public boolean CheckSide(int nColor) {
		int nCheckAlpha, nCheckRed, nCheckGreen, nCheckBlue;

		nCheckAlpha = Color.alpha(nColor);
		nCheckRed = Color.red(nColor) % 0xFF;
		nCheckGreen = Color.green(nColor) % 0xFF;
		nCheckBlue = Color.blue(nColor) % 0xFF;

		if (nCheckAlpha == 0) {
			return false;
		} else if (nCheckRed == 0 || nCheckGreen == 0 || nCheckBlue == 0) {
			return true;
		} else {

			return false;
		}
	}

	public void PaletteDrag(int x, int y, Palette PaletteMethods,
			DrawTool Draw, Canvas PalleteCanvas) {

		PaletteMethods.m_CenterPoint.x = x;
		PaletteMethods.m_CenterPoint.y = y;

		PaletteMethods.m_PostPoint.x = x;
		PaletteMethods.m_PostPoint.y = y;

		Draw.m_PaletteBitmap.eraseColor(0x00000000);

		// PalleteCanvas.drawBitmap(Draw.m_PaletteImage,
		// PaletteMethods.m_CenterPoint.x - Draw.m_PaletteImage.getWidth()
		// / 2, PaletteMethods.m_CenterPoint.y
		// - Draw.m_PaletteImage.getHeight() / 2, null);

		if (CustomView.palette == CustomView.PALETTE.Color) {
			// 가운데가 뚫린 팔레트
			PalleteCanvas.drawCircle(PaletteMethods.m_CenterPoint.x,
					PaletteMethods.m_CenterPoint.y, 50,
					Draw.m_CenterPalettePaint);

			PalleteCanvas.drawBitmap(
					Draw.m_EmptyPaletteImage,
					PaletteMethods.m_CenterPoint.x
							- Draw.m_EmptyPaletteImage.getWidth() / 2,
					PaletteMethods.m_CenterPoint.y
							- Draw.m_EmptyPaletteImage.getHeight() / 2, null);
		} else {
			// 가운데가 막힌 팔레트
			PalleteCanvas.drawBitmap(
					Draw.m_PaletteImage,
					PaletteMethods.m_CenterPoint.x
							- Draw.m_PaletteImage.getWidth() / 2,
					PaletteMethods.m_CenterPoint.y
							- Draw.m_PaletteImage.getHeight() / 2, null);
		}

		if (CustomView.palette == CustomView.PALETTE.Size) {

			PalleteCanvas.drawCircle(PaletteMethods.m_CenterPoint.x,
					PaletteMethods.m_CenterPoint.y, m_CurrentRadius,
					Draw.m_SizePalettePaint);
		} else {
			// 다른 팔레트는 center & side 도 그림
			m_dAngle = 360 / m_nItemNum;
			m_dRadian = AngleToRadian(m_dAngle);
			//
			// PaletteMethods.m_Radian += PaletteMethods.ChangeRadian(
			// PaletteMethods.m_PrePoint, PaletteMethods.m_PostPoint,
			// PaletteMethods.m_CenterPoint);
			// PaletteMethods.m_Radian = PaletteMethods.m_Radian % (2 * PI);


			// 시계 방향으로 회전 & x축이 0도
			for (int n = 0; n < PaletteMethods.m_nItemNum; n++) {
				PaletteMethods.m_CurrentPoint[n] = PaletteMethods.ChangePoint(
						PaletteMethods.m_CenterPoint, DISTANCE,
						PaletteMethods.m_Radian + m_dRadian * n);

				if (PaletteMethods.m_CurrentPoint[n].y > PaletteMethods.m_CenterPoint.y)
					continue;

				PalleteCanvas.drawBitmap(
						m_SideBitmap[n],
						PaletteMethods.m_CurrentPoint[n].x
								- m_SideBitmap[n].getWidth() / 2,
						PaletteMethods.m_CurrentPoint[n].y
								- m_SideBitmap[n].getHeight() / 2, null);
			}

			if (CustomView.palette != CustomView.PALETTE.Color) {
				PalleteCanvas.drawBitmap(
						m_CenterBitmap,
						PaletteMethods.m_CenterPoint.x
								- m_CenterBitmap.getWidth() / 2,
						PaletteMethods.m_CenterPoint.y
								- m_CenterBitmap.getHeight() / 2, null);
			}
		}

		PaletteMethods.m_PrePoint.x = x;
		PaletteMethods.m_PrePoint.y = y;
	}

	// Palette를 Search 할 경우
	public void PaletteSearch(int x, int y, Palette PaletteMethods,
			DrawTool Draw, Canvas PalleteCanvas) {

		PaletteMethods.m_PostPoint.x = x;
		PaletteMethods.m_PostPoint.y = y;

		Draw.m_PaletteBitmap.eraseColor(0x00000000);

		if (CustomView.palette == CustomView.PALETTE.Color) {
			// 가운데가 뚫린 팔레트
			PalleteCanvas.drawCircle(PaletteMethods.m_CenterPoint.x,
					PaletteMethods.m_CenterPoint.y, 50,
					Draw.m_CenterPalettePaint);

			PalleteCanvas.drawBitmap(
					Draw.m_EmptyPaletteImage,
					PaletteMethods.m_CenterPoint.x
							- Draw.m_EmptyPaletteImage.getWidth() / 2,
					PaletteMethods.m_CenterPoint.y
							- Draw.m_EmptyPaletteImage.getHeight() / 2, null);
		} else {
			// 가운데가 막힌 팔레트
			PalleteCanvas.drawBitmap(
					Draw.m_PaletteImage,
					PaletteMethods.m_CenterPoint.x
							- Draw.m_PaletteImage.getWidth() / 2,
					PaletteMethods.m_CenterPoint.y
							- Draw.m_PaletteImage.getHeight() / 2, null);
		}

		if (CustomView.palette == CustomView.PALETTE.Size) {
			// Size 팔레트는 center 만 그림
			PaletteMethods.m_RatioRadius += PaletteMethods.IncludedRadian(
					PaletteMethods.m_PrePoint, PaletteMethods.m_PostPoint,
					PaletteMethods.m_CenterPoint);
			PaletteMethods.m_RatioRadius = PaletteMethods.m_RatioRadius;


			if (PaletteMethods.m_RatioRadius < MIN_RADIUS) {
				m_CurrentRadius = RATIO * MIN_RADIUS;
				PaletteMethods.m_RatioRadius = MIN_RADIUS;
			} else if (PaletteMethods.m_RatioRadius > MAX_RADIUS) {
				m_CurrentRadius = RATIO * MAX_RADIUS;
				PaletteMethods.m_RatioRadius = MAX_RADIUS;
			} else {
				m_CurrentRadius = RATIO * PaletteMethods.m_RatioRadius;
			}

			PalleteCanvas.drawCircle(PaletteMethods.m_CenterPoint.x,
					PaletteMethods.m_CenterPoint.y, m_CurrentRadius,
					Draw.m_SizePalettePaint);
		} else {
			// 다른 팔레트는 center & side 도 그림
			m_dAngle = 360 / m_nItemNum;
			m_dRadian = AngleToRadian(m_dAngle);

			PaletteMethods.m_Radian += PaletteMethods.IncludedRadian(
					PaletteMethods.m_PrePoint, PaletteMethods.m_PostPoint,
					PaletteMethods.m_CenterPoint);
			PaletteMethods.m_Radian = PaletteMethods.m_Radian % (2 * PI);


			// 시계 방향으로 회전 & x축이 0도
			for (int n = 0; n < PaletteMethods.m_nItemNum; n++) {
				PaletteMethods.m_CurrentPoint[n] = PaletteMethods.ChangePoint(
						PaletteMethods.m_CenterPoint, DISTANCE,
						PaletteMethods.m_Radian + m_dRadian * n);

				if (PaletteMethods.m_CurrentPoint[n].y > PaletteMethods.m_CenterPoint.y)
					continue;

				PalleteCanvas.drawBitmap(
						m_SideBitmap[n],
						PaletteMethods.m_CurrentPoint[n].x
								- m_SideBitmap[n].getWidth() / 2,
						PaletteMethods.m_CurrentPoint[n].y
								- m_SideBitmap[n].getHeight() / 2, null);
			}

			if (CustomView.palette != CustomView.PALETTE.Color) {
				PalleteCanvas.drawBitmap(
						m_CenterBitmap,
						PaletteMethods.m_CenterPoint.x
								- m_CenterBitmap.getWidth() / 2,
						PaletteMethods.m_CenterPoint.y
								- m_CenterBitmap.getHeight() / 2, null);
			}
		}

		PaletteMethods.m_PrePoint.x = x;
		PaletteMethods.m_PrePoint.y = y;
	}
}
