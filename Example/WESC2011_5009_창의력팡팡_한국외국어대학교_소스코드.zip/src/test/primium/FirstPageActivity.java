package test.primium;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.Animation.AnimationListener;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;

public class FirstPageActivity extends Activity{
	private FrameLayout FirstLayout;
	private ImageView TitleImageView;
	private Button TitleBtn;
	private Button TutorailBtn;
	private BitmapFactory.Options options;
	private Bitmap FirstLayoutBackground;
	private Bitmap Title;
	private Intent intent;
	private Intent svc;
	private Drawable mBackgroundDrawable;
	private Drawable mBtnDrawable;
	private Display disp;
	private WindowManager wm;
	private boolean ProcessMusic;
	private MediaPlayer mPlayer_Click;
	private boolean btnflag;
	
	@Override
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.first);
		intent = getIntent();


		wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
		disp = wm.getDefaultDisplay();
		options = new BitmapFactory.Options();
		ProcessMusic = false;
		BitmapOption.getSampleSize(options, disp, null, getResources(),
				R.drawable.background1);
		FirstLayout = (FrameLayout) findViewById(R.id.firstView);
		TutorailBtn = (Button) findViewById(R.id.TutorialBtn);
		TitleBtn = (Button) findViewById(R.id.first_btn);
		TitleImageView = (ImageView) findViewById(R.id.firstImageView);
		TitleBtn.setOnClickListener(BtnClickListener);
		TutorailBtn.setOnClickListener(BtnClickListener);
		mPlayer_Click = MediaPlayer.create(this, R.raw.click);

		
		
		FirstLayoutBackground = BitmapFactory.decodeResource(getResources(),
				R.drawable.background1, options);
		mBackgroundDrawable = new BitmapDrawable(FirstLayoutBackground);
		FirstLayout.setBackgroundDrawable(mBackgroundDrawable);
		Title = BitmapFactory.decodeResource(getResources(), R.drawable.title);
		mBtnDrawable = new BitmapDrawable(Title);
		TitleImageView.setBackgroundDrawable(mBtnDrawable);
		TitleBtn.setBackgroundDrawable(mBtnDrawable);
		
		btnflag = false;
	}

	public void onStart(){
		super.onStart();
		ProcessMusic = false;
	}
	
	@Override
	public void onResume(){
		super.onResume();
		
		svc = new Intent(this, BackgroundSoundService.class);
		startService(svc);
		
		new Handler().postDelayed(new Runnable() {
			@Override
			public void run() {
//				BackgroundSoundService.mp.start();
				
				// TODO Auto-generated method stub
				animationRepeat(TitleBtn);
				animationRepeat(TutorailBtn);
			}
		}, 20);
		//		final Animation TitleAni1;
		//		final Animation TitleAni2;
		//		final Animation TitleAni3;
		//		final Animation TitleAni4;
		//		
		//		TitleAni1 = AnimationUtils.loadAnimation(this, R.anim.zoom_in);
		//		TitleAni2 = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		//		TitleAni3 = AnimationUtils.loadAnimation(this, R.anim.zoom_in);
		//		TitleAni4 = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		//		TitleBtn.setOnClickListener(BtnClickListener);
		//		TutorailBtn.setOnClickListener(BtnClickListener);
		//		TitleBtn.startAnimation(TitleAni1);
		//		TutorailBtn.startAnimation(TitleAni3);
		//		TitleAni1.setAnimationListener(new AnimationListener() {
		//			public void onAnimationStart(Animation animation) {}
		//			public void onAnimationRepeat(Animation animation) {}
		//			public void onAnimationEnd(Animation animation) {
		//				TitleBtn.startAnimation(TitleAni2);
		//			}
		//		});
		//
		//		TitleAni2.setAnimationListener(new AnimationListener() {
		//			public void onAnimationStart(Animation animation) {}
		//			public void onAnimationRepeat(Animation animation) {}
		//			public void onAnimationEnd(Animation animation) {
		//				TitleBtn.startAnimation(TitleAni1);
		//			}
		//		});
		//		TitleAni3.setAnimationListener(new AnimationListener() {
		//			public void onAnimationStart(Animation animation) {}
		//			public void onAnimationRepeat(Animation animation) {}
		//			public void onAnimationEnd(Animation animation) {
		//				TutorailBtn.startAnimation(TitleAni4);
		//			}
		//		});
		//
		//		TitleAni4.setAnimationListener(new AnimationListener() {
		//			public void onAnimationStart(Animation animation) {}
		//			public void onAnimationRepeat(Animation animation) {}
		//			public void onAnimationEnd(Animation animation) {
		//				TutorailBtn.startAnimation(TitleAni3);
		//			}
		//		});
	}


	@Override
	public void onPause(){
		super.onPause();
		if (!ProcessMusic && BackgroundSoundService.mp.isPlaying()){
			BackgroundSoundService.mp.pause();
			System.out.println("FirstPageActivity onPause BGM Stop");
		}
	}

	public void onStop(){
		super.onStop();
		if (!ProcessMusic && BackgroundSoundService.mp.isPlaying()){
			BackgroundSoundService.mp.pause();
			System.out.println("FirstPageActivity onPause BGM Stop");
		}
		System.out.println("FirstPageActivity onStop()");
	}
	@Override
	public void onDestroy(){
		super.onDestroy();
		TitleImageView.setBackgroundDrawable(null);
		TitleBtn.setBackgroundDrawable(null);
		FirstLayout.setBackgroundDrawable(null);
		Title.recycle();
		FirstLayoutBackground.recycle();
		System.out.println("FirstPageActivity onDestroy()");
//		BackgroundSoundService.mp.stop();
//		stopService(svc);
	}

	private Button.OnClickListener BtnClickListener = new View.OnClickListener() {
		@Override
		public void onClick(View v) {
			if(!btnflag){
				mPlayer_Click.start();
				
				final Animation MainClickAni1;
				final Animation MainClickAni2;
				final Animation MainClickAni3;
				
				MainClickAni1 = AnimationUtils.loadAnimation(FirstPageActivity.this,
						R.anim.zoooom_in);
				MainClickAni2 = AnimationUtils.loadAnimation(FirstPageActivity.this,
						R.anim.zoooom_out);
				MainClickAni3 = AnimationUtils.loadAnimation(FirstPageActivity.this,
						R.anim.zoooom_in);
	
				switch (v.getId()) {
				case R.id.TutorialBtn:
	
					final Intent TutorialIntent = new Intent(FirstPageActivity.this,TutorialActivity.class);
					mPlayer_Click.start();
					TutorailBtn.startAnimation(MainClickAni1);
					MainClickAni1.setAnimationListener(new AnimationListener() {
						@Override
						public void onAnimationStart(Animation animation) {}	
						@Override
						public void onAnimationRepeat(Animation animation) {}	
						@Override
						public void onAnimationEnd(Animation animation) {
							TutorailBtn.startAnimation(MainClickAni2);
						}
					});
					MainClickAni2.setAnimationListener(new AnimationListener() {
						@Override
						public void onAnimationStart(Animation animation) {}	
						@Override
						public void onAnimationRepeat(Animation animation) {}	
						@Override
						public void onAnimationEnd(Animation animation) {
							TutorailBtn.startAnimation(MainClickAni3);
						}
					});
					MainClickAni3.setAnimationListener(new AnimationListener() {
						@Override
						public void onAnimationStart(Animation animation) {}	
						@Override
						public void onAnimationRepeat(Animation animation) {}	
						@Override
						public void onAnimationEnd(Animation animation) {
							ProcessMusic = true;
							finish();
							startActivity(TutorialIntent);
						}
					});
					break;
				case R.id.first_btn:
	
					final Intent intent = new Intent(FirstPageActivity.this,SecondPageActivity.class);
					mPlayer_Click.start();
					TitleBtn.startAnimation(MainClickAni1);
	
					MainClickAni1.setAnimationListener(new AnimationListener() {
						@Override
						public void onAnimationStart(Animation animation) {}
						@Override
						public void onAnimationRepeat(Animation animation) {}
						@Override
						public void onAnimationEnd(Animation animation) {
							TitleBtn.startAnimation(MainClickAni2);
						}
					});
					MainClickAni2.setAnimationListener(new AnimationListener() {
						@Override
						public void onAnimationStart(Animation animation) {}
						@Override
						public void onAnimationRepeat(Animation animation) {}
						@Override
						public void onAnimationEnd(Animation animation) {
							TitleBtn.startAnimation(MainClickAni3);
						}
					});
					MainClickAni3.setAnimationListener(new AnimationListener() {
						@Override
						public void onAnimationStart(Animation animation) {}
						@Override
						public void onAnimationRepeat(Animation animation) {}
						@Override
						public void onAnimationEnd(Animation animation) {
							ProcessMusic = true;
							finish();
							startActivity(intent);
						}
					});
	
					break;
				}
				btnflag = true;
			}
		}
	};


	private void animationRepeat(View view){
		final Animation TitleAni1;
		final Animation TitleAni2;
		final View RepeatView = view;
		TitleAni1 = AnimationUtils.loadAnimation(this, R.anim.zoom_in);
		TitleAni2 = AnimationUtils.loadAnimation(this, R.anim.zoom_out);
		RepeatView.setAnimation(TitleAni1);
		RepeatView.startAnimation(TitleAni1);
		TitleAni1.setAnimationListener(new AnimationListener() {
			@Override
			public void onAnimationStart(Animation animation) {}
			@Override
			public void onAnimationRepeat(Animation animation) {}
			@Override
			public void onAnimationEnd(Animation animation) {
				RepeatView.startAnimation(TitleAni2);
			}
		});

		TitleAni2.setAnimationListener(new AnimationListener() {
			@Override
			public void onAnimationStart(Animation animation) {}
			@Override
			public void onAnimationRepeat(Animation animation) {}
			@Override
			public void onAnimationEnd(Animation animation) {
				RepeatView.startAnimation(TitleAni1);
			}
		});
	}

	@Override
	public void onBackPressed() {
		TitleImageView.setBackgroundDrawable(null);
		TitleBtn.setBackgroundDrawable(null);
		FirstLayout.setBackgroundDrawable(null);
		BackgroundSoundService.mp.stop();
		stopService(svc);
		ProcessMusic = true;
		finish();
	}
}
