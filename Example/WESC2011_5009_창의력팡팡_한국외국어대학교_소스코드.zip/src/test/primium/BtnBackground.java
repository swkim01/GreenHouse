package test.primium;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.view.Display;
import android.widget.Button;

public class BtnBackground {
	public Bitmap PressAlbumBitmap;
	public Bitmap UnpressAlbumBitmap;
	public Bitmap PressAniStickerBitmap;
	public Bitmap UnpressAniStickerBitmap;
	public Bitmap PressBaseGalleryBitmap;
	public Bitmap UnpressBaseGalleryBitmap;
	public Bitmap PressBrushBitmap;
	public Bitmap UnpressBrushBitmap;
	public Bitmap PressCameraBitmap;
	public Bitmap UnpressCameraBitmap;
	public Bitmap PressChangeSizeBitmap;
	public Bitmap UnpressChangeSizeBitmap;
	public Bitmap PressEraserBitmap;
	public Bitmap UnpressEraserBitmap;
	public Bitmap PressGalleryBitmap;
	public Bitmap UnpressGalleryBitmap;
	public Bitmap PressMozaicBitmap;
	public Bitmap UnpressMozaicBitmap;
	public Bitmap PressPalleteBitmap;
	public Bitmap UnpressPalleteBitmap;
	
	
	public Bitmap PressNormalBitmap;
	public Bitmap UnpressNormalBitmap;
	public Bitmap PressSketch1Bitmap;
	public Bitmap UnpressSketch1Bitmap;
	public Bitmap PressSketch2Bitmap;
	public Bitmap UnpressSketch2Bitmap;
	public Bitmap PressWaterColorBitmap;
	public Bitmap UnpressWaterColorBitmap;
	public Bitmap PressOilPaintBitmap;
	public Bitmap UnpressOilPaintBitmap;
	public Bitmap PressGrayBitmap;
	public Bitmap UnpressGrayBitmap;
	
	
	public Bitmap PressMainBitmap;
	public Bitmap UnpressMainBitmap;
	public Bitmap PressSaveBitmap;
	public Bitmap UnpressSaveBitmap;
	public Bitmap PressFinishBitmap;
	public Bitmap UnpressFinishBitmap;

	
	public Drawable PressDrawable;
	public Drawable UnpressDrawable;
	
	public void recycleBitmap1(){
		PressAlbumBitmap.recycle();
		UnpressAlbumBitmap.recycle();
		PressCameraBitmap.recycle();
		UnpressCameraBitmap.recycle();
	}
	public void recycleBitmap2(){
		PressBaseGalleryBitmap.recycle();
		UnpressBaseGalleryBitmap.recycle();
		PressGalleryBitmap.recycle();
		UnpressGalleryBitmap.recycle();
		
	}
	public void recycleBitmap3(){
		if(PressNormalBitmap != null){
			PressNormalBitmap.recycle();
			UnpressNormalBitmap.recycle();
			PressSketch1Bitmap.recycle();
			UnpressSketch1Bitmap.recycle();
			PressSketch2Bitmap.recycle();
			UnpressSketch2Bitmap.recycle();
			PressWaterColorBitmap.recycle();
			UnpressWaterColorBitmap.recycle();
			PressOilPaintBitmap.recycle();
			UnpressOilPaintBitmap.recycle();
			PressGrayBitmap.recycle();
			UnpressGrayBitmap.recycle();
		}
		
	}
	
	public void recycleBitmap4(){
		PressAniStickerBitmap.recycle();
		UnpressAniStickerBitmap.recycle();
		PressBrushBitmap.recycle();
		UnpressBrushBitmap.recycle();
		PressChangeSizeBitmap.recycle();
		UnpressChangeSizeBitmap.recycle();
		PressEraserBitmap.recycle();
		UnpressEraserBitmap.recycle();
		PressMozaicBitmap.recycle();
		UnpressMozaicBitmap.recycle();
		PressPalleteBitmap.recycle();
		UnpressPalleteBitmap.recycle();
	}
	
	public void recycleBitmap5(){
		
		PressMainBitmap.recycle();
		UnpressMainBitmap.recycle();
		PressSaveBitmap.recycle();
		UnpressSaveBitmap.recycle();
		PressFinishBitmap.recycle();
		UnpressFinishBitmap.recycle();
	}
//	public void albumBtnBackground(Context context , Button button){
//		BitmapFactory.Options options =  BitmapOption.getSampleSize(button, context.getResources(), R.drawable.album); 
//		
//		PressAlbumBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.album2,options);
//		UnpressAlbumBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.album,options);
//		PressDrawable = new BitmapDrawable(PressAlbumBitmap);
//		UnpressDrawable = new BitmapDrawable(UnpressAlbumBitmap);
//		button.setBackgroundDrawable(imgChange(UnpressDrawable, PressDrawable));
//		options = null;
//	}
//	public void aniStickerBtnBackground(Context context , Button button){
//		BitmapFactory.Options options =  BitmapOption.getSampleSize(button, context.getResources(), R.drawable.anisticker);
//		
//		PressAniStickerBitmap= BitmapFactory.decodeResource(context.getResources(), R.drawable.anisticker2,options);
//		UnpressAniStickerBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.anisticker,options);
//		PressDrawable = new BitmapDrawable(PressAniStickerBitmap);
//		UnpressDrawable = new BitmapDrawable(UnpressAniStickerBitmap);
//		button.setBackgroundDrawable(imgChange(UnpressDrawable, PressDrawable));
//		options = null;
//	}
//	public void baseGelleryBtnBackground(Context context , Button button){
//		BitmapFactory.Options options =  BitmapOption.getSampleSize(button, context.getResources(), R.drawable.image);
//		
//		PressBaseGalleryBitmap= BitmapFactory.decodeResource(context.getResources(), R.drawable.image2, options);
//		UnpressBaseGalleryBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.image, options);
//		PressDrawable = new BitmapDrawable(PressBaseGalleryBitmap);
//		UnpressDrawable = new BitmapDrawable(UnpressBaseGalleryBitmap);
//		button.setBackgroundDrawable(imgChange(UnpressDrawable, PressDrawable));
//		options = null;
//	}
//	public void brushBtnBackground(Context context , Button button){
//		BitmapFactory.Options options =  BitmapOption.getSampleSize(button, context.getResources(), R.drawable.brush);
//		PressBrushBitmap= BitmapFactory.decodeResource(context.getResources(), R.drawable.brush2, options);
//		UnpressBrushBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.brush, options);
//		PressDrawable = new BitmapDrawable(PressBrushBitmap);
//		UnpressDrawable = new BitmapDrawable(UnpressBrushBitmap);
//		button.setBackgroundDrawable(imgChange(UnpressDrawable, PressDrawable));
//		options = null;
//	}
//	public void cameraBtnBackground(Context context , Button button){
//		BitmapFactory.Options options =  BitmapOption.getSampleSize(button, context.getResources(), R.drawable.camera);
//		PressCameraBitmap= BitmapFactory.decodeResource(context.getResources(), R.drawable.camera2, options);
//		UnpressCameraBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.camera, options);
//		PressDrawable = new BitmapDrawable(PressCameraBitmap);
//		UnpressDrawable = new BitmapDrawable(UnpressCameraBitmap);
//		button.setBackgroundDrawable(imgChange(UnpressDrawable, PressDrawable));
//		options = null;
//	}
//	public void changeSizeBtnBackground(Context context , Button button){
//		BitmapFactory.Options options =  BitmapOption.getSampleSize(button, context.getResources(), R.drawable.size);
//		PressChangeSizeBitmap= BitmapFactory.decodeResource(context.getResources(), R.drawable.size2, options);
//		UnpressChangeSizeBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.size, options);
//		PressDrawable = new BitmapDrawable(PressChangeSizeBitmap);
//		UnpressDrawable = new BitmapDrawable(UnpressChangeSizeBitmap);
//		button.setBackgroundDrawable(imgChange(UnpressDrawable, PressDrawable));
//		options = null;
//	}
//	public void eraserBtnBackground(Context context , Button button){
//		BitmapFactory.Options options =  BitmapOption.getSampleSize(button, context.getResources(), R.drawable.eraser);
//		PressEraserBitmap= BitmapFactory.decodeResource(context.getResources(), R.drawable.eraser2, options);
//		UnpressEraserBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.eraser, options);
//		PressDrawable = new BitmapDrawable(PressEraserBitmap);
//		UnpressDrawable = new BitmapDrawable(UnpressEraserBitmap);
//		button.setBackgroundDrawable(imgChange(UnpressDrawable, PressDrawable));
//		options = null;
//	}
//	public void galleryBtnBackground(Context context , Button button){
//		BitmapFactory.Options options =  BitmapOption.getSampleSize(button, context.getResources(), R.drawable.picture);
//		PressGalleryBitmap= BitmapFactory.decodeResource(context.getResources(), R.drawable.picture2,options);
//		UnpressGalleryBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.picture,options);
//		PressDrawable = new BitmapDrawable(PressGalleryBitmap);
//		UnpressDrawable = new BitmapDrawable(UnpressGalleryBitmap);
//		button.setBackgroundDrawable(imgChange(UnpressDrawable, PressDrawable));
//		options = null;
//	}
//	public void mozaicBtnBackground(Context context , Button button){
//		BitmapFactory.Options options =  BitmapOption.getSampleSize(button, context.getResources(), R.drawable.mozaic);
//		PressMozaicBitmap= BitmapFactory.decodeResource(context.getResources(), R.drawable.mozaic2, options);
//		UnpressMozaicBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.mozaic, options);
//		PressDrawable = new BitmapDrawable(PressMozaicBitmap);
//		UnpressDrawable = new BitmapDrawable(UnpressMozaicBitmap);
//		button.setBackgroundDrawable(imgChange(UnpressDrawable, PressDrawable));
//		options = null;
//	}
//	public void palleteBtnBackground(Context context , Button button){
//		BitmapFactory.Options options =  BitmapOption.getSampleSize(button, context.getResources(), R.drawable.pallete1);
//		PressPalleteBitmap= BitmapFactory.decodeResource(context.getResources(), R.drawable.pallete2, options);
//		UnpressPalleteBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.pallete1 , options);
//		PressDrawable = new BitmapDrawable(PressPalleteBitmap);
//		UnpressDrawable = new BitmapDrawable(UnpressPalleteBitmap);
//		button.setBackgroundDrawable(imgChange(UnpressDrawable, PressDrawable));
//		options = null;
//	}
	public void albumBtnBackground(Context context , Button button){
		PressAlbumBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.album2);
		UnpressAlbumBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.album);
		PressDrawable = new BitmapDrawable(PressAlbumBitmap);
		UnpressDrawable = new BitmapDrawable(UnpressAlbumBitmap);
		button.setBackgroundDrawable(imgChange(UnpressDrawable, PressDrawable));
	}
	public void aniStickerBtnBackground(Context context , Button button){
		PressAniStickerBitmap= BitmapFactory.decodeResource(context.getResources(), R.drawable.anisticker2);
		UnpressAniStickerBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.anisticker);
		PressDrawable = new BitmapDrawable(PressAniStickerBitmap);
		UnpressDrawable = new BitmapDrawable(UnpressAniStickerBitmap);
		button.setBackgroundDrawable(imgChange(UnpressDrawable, PressDrawable));
	}
	public void baseGelleryBtnBackground(Context context , Button button){
		PressBaseGalleryBitmap= BitmapFactory.decodeResource(context.getResources(), R.drawable.image2);
		UnpressBaseGalleryBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.image);
		PressDrawable = new BitmapDrawable(PressBaseGalleryBitmap);
		UnpressDrawable = new BitmapDrawable(UnpressBaseGalleryBitmap);
		button.setBackgroundDrawable(imgChange(UnpressDrawable, PressDrawable));
	}
	public void brushBtnBackground(Context context , Button button){
		PressBrushBitmap= BitmapFactory.decodeResource(context.getResources(), R.drawable.brush2);
		UnpressBrushBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.brush);
		PressDrawable = new BitmapDrawable(PressBrushBitmap);
		UnpressDrawable = new BitmapDrawable(UnpressBrushBitmap);
		button.setBackgroundDrawable(imgChange(UnpressDrawable, PressDrawable));
	}
	public void cameraBtnBackground(Context context , Button button){
		PressCameraBitmap= BitmapFactory.decodeResource(context.getResources(), R.drawable.camera2);
		UnpressCameraBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.camera);
		PressDrawable = new BitmapDrawable(PressCameraBitmap);
		UnpressDrawable = new BitmapDrawable(UnpressCameraBitmap);
		button.setBackgroundDrawable(imgChange(UnpressDrawable, PressDrawable));
	}
	public void changeSizeBtnBackground(Context context , Button button){
		PressChangeSizeBitmap= BitmapFactory.decodeResource(context.getResources(), R.drawable.size2);
		UnpressChangeSizeBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.size);
		PressDrawable = new BitmapDrawable(PressChangeSizeBitmap);
		UnpressDrawable = new BitmapDrawable(UnpressChangeSizeBitmap);
		button.setBackgroundDrawable(imgChange(UnpressDrawable, PressDrawable));
	}
	public void eraserBtnBackground(Context context , Button button){
		PressEraserBitmap= BitmapFactory.decodeResource(context.getResources(), R.drawable.eraser2);
		UnpressEraserBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.eraser);
		PressDrawable = new BitmapDrawable(PressEraserBitmap);
		UnpressDrawable = new BitmapDrawable(UnpressEraserBitmap);
		button.setBackgroundDrawable(imgChange(UnpressDrawable, PressDrawable));
	}
	public void galleryBtnBackground(Context context , Button button){
		PressGalleryBitmap= BitmapFactory.decodeResource(context.getResources(), R.drawable.picture2);
		UnpressGalleryBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.picture);
		PressDrawable = new BitmapDrawable(PressGalleryBitmap);
		UnpressDrawable = new BitmapDrawable(UnpressGalleryBitmap);
		button.setBackgroundDrawable(imgChange(UnpressDrawable, PressDrawable));
	}
	public void mozaicBtnBackground(Context context , Button button){
		PressMozaicBitmap= BitmapFactory.decodeResource(context.getResources(), R.drawable.mozaic2);
		UnpressMozaicBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.mozaic);
		PressDrawable = new BitmapDrawable(PressMozaicBitmap);
		UnpressDrawable = new BitmapDrawable(UnpressMozaicBitmap);
		button.setBackgroundDrawable(imgChange(UnpressDrawable, PressDrawable));
	}
	public void palleteBtnBackground(Context context , Button button){
		PressPalleteBitmap= BitmapFactory.decodeResource(context.getResources(), R.drawable.pallete2);
		UnpressPalleteBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.pallete1 );
		PressDrawable = new BitmapDrawable(PressPalleteBitmap);
		UnpressDrawable = new BitmapDrawable(UnpressPalleteBitmap);
		button.setBackgroundDrawable(imgChange(UnpressDrawable, PressDrawable));
	}
	
	
	public void saveBtnBackground(Context context , Button button){
		PressSaveBitmap= BitmapFactory.decodeResource(context.getResources(), R.drawable.savebutton2,BitmapOption.buttonResize(Main.disp, context.getResources(), R.drawable.savebutton2, 3));
		UnpressSaveBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.savebutton1 ,BitmapOption.buttonResize(Main.disp, context.getResources(), R.drawable.savebutton1, 3));
		PressDrawable = new BitmapDrawable(PressSaveBitmap);
		UnpressDrawable = new BitmapDrawable(UnpressSaveBitmap);
		button.setBackgroundDrawable(imgChange(UnpressDrawable, PressDrawable));
	}
	public void mainBtnBackground(Context context , Button button){
		PressMainBitmap= BitmapFactory.decodeResource(context.getResources(), R.drawable.mainbutton2,BitmapOption.buttonResize(Main.disp, context.getResources(), R.drawable.mainbutton2, 3));
		UnpressMainBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.mainbutton1 ,BitmapOption.buttonResize(Main.disp, context.getResources(), R.drawable.mainbutton1, 3));
		PressDrawable = new BitmapDrawable(PressMainBitmap);
		UnpressDrawable = new BitmapDrawable(UnpressMainBitmap);
		button.setBackgroundDrawable(imgChange(UnpressDrawable, PressDrawable));
	}
	public void finishBtnBackground(Context context , Button button){
		PressFinishBitmap= BitmapFactory.decodeResource(context.getResources(), R.drawable.finishbutton2,BitmapOption.buttonResize(Main.disp, context.getResources(), R.drawable.finishbutton2, 3));
		UnpressFinishBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.finishbutton1 ,BitmapOption.buttonResize(Main.disp, context.getResources(), R.drawable.finishbutton1, 3));
		PressDrawable = new BitmapDrawable(PressFinishBitmap);
		UnpressDrawable = new BitmapDrawable(UnpressFinishBitmap);
		button.setBackgroundDrawable(imgChange(UnpressDrawable, PressDrawable));
	}
	
//	public void normalBtnBackground(Context context , Button button){
//		PressNormalBitmap= BitmapFactory.decodeResource(context.getResources(), R.drawable.normal);
//		UnpressNormalBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.normal );
//		PressDrawable = new BitmapDrawable(PressNormalBitmap);
//		UnpressDrawable = new BitmapDrawable(UnpressNormalBitmap);
//		button.setBackgroundDrawable(imgChange(UnpressDrawable, PressDrawable));
//	}
//	public void sketch1BtnBackground(Context context , Button button){
//		PressSketch1Bitmap= BitmapFactory.decodeResource(context.getResources(), R.drawable.sketch1);
//		UnpressSketch1Bitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.sketch1 );
//		PressDrawable = new BitmapDrawable(PressSketch1Bitmap);
//		UnpressDrawable = new BitmapDrawable(UnpressSketch1Bitmap);
//		button.setBackgroundDrawable(imgChange(UnpressDrawable, PressDrawable));
//	}
//	public void sketch2BtnBackground(Context context , Button button){
//		PressSketch2Bitmap= BitmapFactory.decodeResource(context.getResources(), R.drawable.sketch2);
//		UnpressSketch2Bitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.sketch2 );
//		PressDrawable = new BitmapDrawable(PressSketch2Bitmap);
//		UnpressDrawable = new BitmapDrawable(UnpressSketch2Bitmap);
//		button.setBackgroundDrawable(imgChange(UnpressDrawable, PressDrawable));
//	}
//	public void grayBtnBackground(Context context , Button button){
//		PressGrayBitmap= BitmapFactory.decodeResource(context.getResources(), R.drawable.gray);
//		UnpressGrayBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.gray );
//		PressDrawable = new BitmapDrawable(PressGrayBitmap);
//		UnpressDrawable = new BitmapDrawable(UnpressGrayBitmap);
//		button.setBackgroundDrawable(imgChange(UnpressDrawable, PressDrawable));
//	}
//	public void waterColorBtnBackground(Context context , Button button){
//		PressWaterColorBitmap= BitmapFactory.decodeResource(context.getResources(), R.drawable.water);
//		UnpressWaterColorBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.water );
//		PressDrawable = new BitmapDrawable(PressWaterColorBitmap);
//		UnpressDrawable = new BitmapDrawable(UnpressWaterColorBitmap);
//		button.setBackgroundDrawable(imgChange(UnpressDrawable, PressDrawable));
//	}
//	public void oilPaintBtnBackground(Context context , Button button){
//		PressOilPaintBitmap= BitmapFactory.decodeResource(context.getResources(), R.drawable.oil);
//		UnpressOilPaintBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.oil );
//		PressDrawable = new BitmapDrawable(PressOilPaintBitmap);
//		UnpressDrawable = new BitmapDrawable(UnpressOilPaintBitmap);
//		button.setBackgroundDrawable(imgChange(UnpressDrawable, PressDrawable));
//	}
	
	public StateListDrawable normalBtnBackground(Context context , Display disp){
		PressNormalBitmap= BitmapFactory.decodeResource(context.getResources(), R.drawable.normal2,BitmapOption.buttonResize(Main.disp, context.getResources(), R.drawable.normal2, 3));
		UnpressNormalBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.normal1,BitmapOption.buttonResize(Main.disp, context.getResources(), R.drawable.normal1, 3) );
		PressDrawable = new BitmapDrawable(PressNormalBitmap);
		UnpressDrawable = new BitmapDrawable(UnpressNormalBitmap);
		return imgChange(UnpressDrawable, PressDrawable);
	}
	public StateListDrawable sketch1BtnBackground(Context context, Display disp){
		PressSketch1Bitmap= BitmapFactory.decodeResource(context.getResources(), R.drawable.sketch1_2,BitmapOption.buttonResize(Main.disp, context.getResources(), R.drawable.sketch1_2, 3));
		UnpressSketch1Bitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.sketch1_1 ,BitmapOption.buttonResize(Main.disp, context.getResources(), R.drawable.sketch1_1, 3));
		PressDrawable = new BitmapDrawable(PressSketch1Bitmap);
		UnpressDrawable = new BitmapDrawable(UnpressSketch1Bitmap);
		return imgChange(UnpressDrawable, PressDrawable);
	}
	public StateListDrawable sketch2BtnBackground(Context context, Display disp){
		PressSketch2Bitmap= BitmapFactory.decodeResource(context.getResources(), R.drawable.sketch2_2,BitmapOption.buttonResize(Main.disp, context.getResources(), R.drawable.sketch2_2, 3));
		UnpressSketch2Bitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.sketch2_1 ,BitmapOption.buttonResize(Main.disp, context.getResources(), R.drawable.sketch2_1, 3));
		PressDrawable = new BitmapDrawable(PressSketch2Bitmap);
		UnpressDrawable = new BitmapDrawable(UnpressSketch2Bitmap);
		return imgChange(UnpressDrawable, PressDrawable);
	}
	public StateListDrawable grayBtnBackground(Context context, Display disp){
		PressGrayBitmap= BitmapFactory.decodeResource(context.getResources(), R.drawable.gray2,BitmapOption.buttonResize(Main.disp, context.getResources(), R.drawable.gray2, 3));
		UnpressGrayBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.gray1 ,BitmapOption.buttonResize(Main.disp, context.getResources(), R.drawable.gray1, 3));
		PressDrawable = new BitmapDrawable(PressGrayBitmap);
		UnpressDrawable = new BitmapDrawable(UnpressGrayBitmap);
		return imgChange(UnpressDrawable, PressDrawable);
	}
	public StateListDrawable waterColorBtnBackground(Context context, Display disp){
		PressWaterColorBitmap= BitmapFactory.decodeResource(context.getResources(), R.drawable.water2,BitmapOption.buttonResize(Main.disp, context.getResources(), R.drawable.water2, 3));
		UnpressWaterColorBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.water1 ,BitmapOption.buttonResize(Main.disp, context.getResources(), R.drawable.water1, 3));
		PressDrawable = new BitmapDrawable(PressWaterColorBitmap);
		UnpressDrawable = new BitmapDrawable(UnpressWaterColorBitmap);
		return imgChange(UnpressDrawable, PressDrawable);
	}
	public StateListDrawable oilPaintBtnBackground(Context context, Display disp){
		PressOilPaintBitmap= BitmapFactory.decodeResource(context.getResources(), R.drawable.oil2,BitmapOption.buttonResize(Main.disp, context.getResources(), R.drawable.oil2, 3));
		UnpressOilPaintBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.oil1 ,BitmapOption.buttonResize(Main.disp, context.getResources(), R.drawable.oil1, 3));
		PressDrawable = new BitmapDrawable(PressOilPaintBitmap);
		UnpressDrawable = new BitmapDrawable(UnpressOilPaintBitmap);
		return imgChange(UnpressDrawable, PressDrawable);
	}

	
	private StateListDrawable imgChange(Drawable img_01, Drawable img_02) {
	     StateListDrawable stateListDrawable = new StateListDrawable();
	     stateListDrawable.addState(new int[]{ android.R.attr.state_pressed}, img_02);
	     stateListDrawable.addState(new int[]{-android.R.attr.state_pressed}, img_01);
	     stateListDrawable.addState(new int[]{ android.R.attr.state_focused}, img_02);
	     return stateListDrawable;
	}
}
