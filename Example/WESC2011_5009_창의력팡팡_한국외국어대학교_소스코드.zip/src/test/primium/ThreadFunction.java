package test.primium;

import java.util.*;

import android.content.*;
import android.graphics.*;
import android.hardware.*;
import android.os.*;

public class ThreadFunction {
	final static float GRAVITY = SensorManager.STANDARD_GRAVITY;
	SensorManager m_SenserManager;
	ArrayList<AccelValue> m_arValue = new ArrayList<AccelValue>();
	final static int MAXCOUNT = 20;
	
	
	

	public static final int X = 0;
	public static final int Y = 1;
	public static final int Z = 2;
	public boolean	JNI_Finish	= false;
	float m_SenRange = 16.0f;
	int m_SenGap = 1000;
	long m_ApplyTime;
	int m_SenSpeed = 800;
	
	CustomView m_CustomView;
	GalleryViewActivity m_GV;
	Context m_Context;
	int m_nSelectItem = -1;
	int CheckThread = 100;
	
	StandradThread m_StandardThread;
	
//	public ThreadFunction(Context context, CustomView CV) {
//		
//		m_Context = context;
//		m_CustomView = CV;
//		m_SenserManager = (SensorManager) context
//				.getSystemService(Context.SENSOR_SERVICE);
//	
//		// 어플 종료시 자동 쓰레드 종료
//		m_StandardThread = new StandradThread();
//		m_StandardThread.setDaemon(true);
//		m_StandardThread.start();
//	}

	public ThreadFunction(Context context, GalleryViewActivity GV) {
		
		m_Context = context;
		m_GV = GV;
		m_CustomView = GalleryViewActivity.m_CustomView;
		
		m_SenserManager = (SensorManager) context
				.getSystemService(Context.SENSOR_SERVICE);
	
		// 어플 종료시 자동 쓰레드 종료
		m_StandardThread = new StandradThread();
		m_StandardThread.setDaemon(true);
		m_StandardThread.start();
	}
	
	// public void ThreadStart() {
	// // m_BackThread = new BackThread();
	// ThreadStart = true;
	// m_BackThread.setLoop(true);
	// m_BackThread.start();
	// System.out.println("스레드 시작.");
	// }

	// public void ThreadStop() {
	// // m_BackThread = new BackThread();
	// ThreadStart = false;
	// m_BackThread.ThreadDestoryed();
	// }

	public void SetItem(int nItemNum) {
		m_nSelectItem = nItemNum;
	}

	class StandradThread extends Thread {

		private boolean isLoop;
		
		
		public StandradThread() {
			isLoop = true;
		}

		public void setLoop(boolean bLoop) {
			isLoop = bLoop;
		}

		@Override
		public void run() {
			super.run();
			
			while (isLoop) {

				if(m_CustomView.m_MyAnimation!=null)
					m_CustomView.m_MyAnimation.inThread();
				if(m_nSelectItem == CheckThread)
				{
					if (JNI_Finish == true)
					{
						Bitmap recycleBitmap;
						recycleBitmap = m_CustomView.m_Draw.m_BackgroundBitmap;
						
//						if (recycleBitmap.getWidth() > recycleBitmap.getHeight()) {
						if (m_CustomView.JNI_Width > m_CustomView.JNI_Height) {
							m_CustomView.m_Draw.m_BackgroundBitmap= Bitmap.createScaledBitmap(
									m_CustomView.m_Draw.m_BackgroundBitmap, m_CustomView.JNI_Width, m_CustomView.JNI_Height, true);
						} else {
							m_CustomView.m_Draw.m_BackgroundBitmap= Bitmap.createScaledBitmap(
									m_CustomView.m_Draw.m_BackgroundBitmap, m_CustomView.JNI_Height, m_CustomView.JNI_Width, true);
						}
						
//						if(m_GV.bCameraImg == true)
//						{
//							File file = new File(m_GV.path);
//							file.delete();
//							file = null;
//						}
						
						if(!recycleBitmap.isRecycled())
							recycleBitmap.recycle();
						m_GV.dialog.dismiss();
						m_CustomView.postInvalidate();
						JNI_Finish = false;
						m_nSelectItem = Main.ACCELEROMETER;
						m_Handler.sendEmptyMessage(m_nSelectItem);
					}
				}
				else
				{	CheckThread = m_nSelectItem;  
					m_Handler.sendEmptyMessage(m_nSelectItem);
				}
				
				
				try {
					Thread.sleep(1000); // 1초마다 한번씩.
				} catch (ThreadDeath ouch) {
					throw (ouch);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}

		}
	}

	Handler m_Handler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			switch (msg.what) {
				
				case Main.ServiceMode:
				{
					m_CustomView.m_Draw.m_BackgroundBitmap = m_GV.jniMethods
					.Noraml(m_GV.GetBitmap(Main.disp, null, GalleryViewActivity.BaseID, Main.disp
							.getRotation()));
					JNI_Finish = true;
					break;
					
				}
				case Main.NomalMode:
				{
					m_CustomView.m_Draw.m_BackgroundBitmap = m_GV.jniMethods
					.Noraml(m_GV.GetBitmap(Main.disp, m_GV.path, -1, Main.disp
							.getRotation()));
					JNI_Finish = true;
					break;
					
				}
				case Main.GrayMode:
				{
					m_CustomView.m_Draw.m_BackgroundBitmap = m_GV.jniMethods
							.GrayEffect(m_GV.GetBitmap(Main.disp, m_GV.path, -1, Main.disp
									.getRotation()));
					JNI_Finish = true;
					break;
				}
				case Main.SketchMode1:
				{
					m_CustomView.m_Draw.m_BackgroundBitmap = m_GV.jniMethods
							.SketchEffect1(m_GV.GetBitmap(Main.disp, m_GV.path, -1,
									Main.disp.getRotation()));
					JNI_Finish = true;
					break;
				}
				case Main.SketchMode2:
				{
					m_CustomView.m_Draw.m_BackgroundBitmap = m_GV.jniMethods
							.SketchEffect2(m_GV.GetBitmap(Main.disp, m_GV.path, -1,
									Main.disp.getRotation()));
					JNI_Finish = true;
					
					break;
				}
				case Main.OilPaintingMode:
				{
					m_CustomView.m_Draw.m_BackgroundBitmap = m_GV.jniMethods
							.OilPaintEffect(m_GV.GetBitmap(Main.disp, m_GV.path, -1,
									Main.disp.getRotation()));
					JNI_Finish = true;
					break;
				}
				case Main.WaterColorMode:
				{
					m_CustomView.m_Draw.m_BackgroundBitmap = m_GV.jniMethods
							.WaterColorEffect(m_GV.GetBitmap(Main.disp, m_GV.path, -1,
									Main.disp.getRotation()));
					JNI_Finish = true;
					break;
				}
				case Main.ACCELEROMETER: // 수행되는 부분.
				{
					m_SenserManager.registerListener(m_SensorListener,
							m_SenserManager
							.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),
							SensorManager.SENSOR_DELAY_GAME); // 게임에 적합한 주기.
					
					break;
				}
			
			default:
				break;
			}
		}
	};

	class AccelValue {
		float[] value = new float[3];
		long time;
	}

	SensorEventListener m_SensorListener = new SensorEventListener() {
		@Override
		public void onAccuracyChanged(Sensor sensor, int accuracy) {
		}

		@Override
		public void onSensorChanged(SensorEvent event) {
			switch (event.sensor.getType()) {
			case Sensor.TYPE_ACCELEROMETER: {
				Accelerometer(event);
				break;
			}
			}
		}

		public void Accelerometer(SensorEvent event) {
			// 가속값 큐 방식의 배열에 누적
			AccelValue av = new AccelValue();
			av.value[X] = event.values[X];
			av.value[Y] = event.values[Y];
			av.value[Z] = event.values[Z];
			av.time = event.timestamp / 100000L;
			if (m_arValue.size() == MAXCOUNT) {
				m_arValue.remove(0);
			}
			m_arValue.add(av);

			// 인식 간격이 지나지 않았으면 무시
			long now = System.currentTimeMillis();
			if (now - m_ApplyTime < m_SenGap) {
				return;
			}

			// 지정한 기간내에 각 방향 가속값의 최소, 최대값 및 진폭 계산
			float[] min = new float[] { 100, 100, 100 };
			float[] max = new float[] { -100, -100, -100 };
			for (int i = m_arValue.size() - 1; i >= 0; i--) {
				AccelValue v = m_arValue.get(i);
				if (av.time - v.time > m_SenSpeed) {
					break;
				}
				for (int j = 0; j < 3; j++) {
					min[j] = Math.min(min[j], v.value[j]);
					max[j] = Math.max(max[j], v.value[j]);
				}
			}
			float[] diff = new float[3];
			for (int j = 0; j < 3; j++) {
				diff[j] = Math.abs(max[j] - min[j]);
			}

			// X 축 흔들기 - 증가
			if (diff[X] > m_SenRange) {
//				if (!m_CustomView.m_Draw.m_bVisiablePallete) {
					if (!m_CustomView.m_MyMozaic.m_MozaicLinkedList.isEmpty()
							|| !m_CustomView.m_MyMozaic.m_SandLinkedList
									.isEmpty() || !m_CustomView.m_MyMozaic.m_PastePath.isEmpty())
					{
						m_CustomView.m_MyMozaic.SeparateObject(m_CustomView);
					}
					else
					{
					}
					m_arValue.clear();
//				}
//				return;
			}
			return;
		}
	};

}