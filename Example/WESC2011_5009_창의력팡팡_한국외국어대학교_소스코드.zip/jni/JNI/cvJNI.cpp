#include "cvJNI.h"

JNIEXPORT void JNICALL Java_test_primium_JNIMethods_cvSketchEffect1(JNIEnv *env, jobject thiz,jintArray image,jint width,jint height)
{
	jint *sImage = env->GetIntArrayElements(image,0);
	jsize iSize = env->GetArrayLength(image);
	m_ImageProcess.SketchEffect1(sImage,width,height);
	env->ReleaseIntArrayElements(image, sImage,0);
	sImage = NULL;
}
JNIEXPORT void JNICALL Java_test_primium_JNIMethods_cvSketchEffect2(JNIEnv *env, jobject thiz,jintArray image,jint width,jint height)
{
	jint *sImage = env->GetIntArrayElements(image,0);
	jsize iSize = env->GetArrayLength(image);
	m_ImageProcess.SketchEffect2(sImage,width,height);
	env->ReleaseIntArrayElements(image, sImage,0);
	sImage = NULL;
}

JNIEXPORT void JNICALL Java_test_primium_JNIMethods_cvGrayEffect(JNIEnv *env, jobject thiz,jintArray image,jint width,jint height)
{
	jint *sImage = env->GetIntArrayElements(image,0);
	jsize iSize = env->GetArrayLength(image);
	m_ImageProcess.GrayEffect(sImage,width,height);
	env->ReleaseIntArrayElements(image, sImage,0);
	sImage = NULL;
}

JNIEXPORT void JNICALL Java_test_primium_JNIMethods_cvOilPaintEffect(JNIEnv *env, jobject thiz,jintArray image,jint width,jint height,jint nRadius, jint nDifferentIntensity)
{
	jint *sImage = env->GetIntArrayElements(image,0);
	jsize iSize = env->GetArrayLength(image);
	m_ImageProcess.OilPaintEffect(sImage,width,height,nRadius,nDifferentIntensity);
	env->ReleaseIntArrayElements(image, sImage,0);
	sImage = NULL;
}
JNIEXPORT void JNICALL Java_test_primium_JNIMethods_cvWaterColorEffect(JNIEnv *env, jobject thiz,jintArray image,jint width,jint height)
{
	jint *sImage = env->GetIntArrayElements(image,0);
	jsize iSize = env->GetArrayLength(image);
	m_ImageProcess.WaterColorEffect(sImage,width,height);
	env->ReleaseIntArrayElements(image, sImage,0);
	sImage = NULL;
}

JNIEXPORT void JNICALL Java_test_primium_JNIMethods_cvRainDropEffect(JNIEnv *env, jobject thiz,jintArray image,jint width,jint height ,jint xPoint, jint yPoint)
{
	jint *sImage = env->GetIntArrayElements(image,0);
	jsize iSize = env->GetArrayLength(image);
	m_AnimationProcess.RainDropEffect(sImage,width,height,xPoint,yPoint);
	env->ReleaseIntArrayElements(image, sImage,0);
	sImage = NULL;
}

JNIEXPORT void JNICALL Java_test_primium_JNIMethods_cvLightEffect(JNIEnv *env, jobject thiz,jintArray image,jint width,jint height ,jint xPoint, jint yPoint)
{
	jint *sImage = env->GetIntArrayElements(image,0);
	jsize iSize = env->GetArrayLength(image);
	m_AnimationProcess.LightEffect(sImage,width,height,xPoint,yPoint);
	env->ReleaseIntArrayElements(image, sImage,0);
	sImage = NULL;
}

JNIEXPORT void JNICALL Java_test_primium_JNIMethods_cvFisheyeEffect(JNIEnv *env, jobject thiz,jintArray image,jint width,jint height ,jint xPoint, jint yPoint)
{
	jint *sImage = env->GetIntArrayElements(image,0);
	jsize iSize = env->GetArrayLength(image);
	m_AnimationProcess.FisheyeEffect(sImage,width,height,xPoint,yPoint);
	env->ReleaseIntArrayElements(image, sImage,0);
	sImage = NULL;
}