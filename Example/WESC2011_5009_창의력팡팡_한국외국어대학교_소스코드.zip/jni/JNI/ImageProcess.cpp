#include "ImageProcess.h"





ImageProcess::ImageProcess(void)
{
}

ImageProcess::~ImageProcess(void)
{
	free(temp_Image);
}


IplImage* Equalization(IplImage* ppReadImage, int const &nHeight, int const &nWidth)
{
	IplImage* ppImage;
	ppImage = cvCreateImage(cvSize(nWidth, nHeight), IPL_DEPTH_8U, 1);

	unsigned int pPDF[256] = {0, };
	unsigned int nCDF = 0;

	unsigned int pMappingfunction[256] = {0, };
	unsigned int pRatioFunction[256] = {0, };

	double dNormalization = 0.0;

	dNormalization = 255.0/(nHeight*nWidth);

	// Imaged�� PDF function�� ����
	for(int nNumHeight = 0; nNumHeight < nHeight; nNumHeight++)
	{
		for(int nNumWidth = 0; nNumWidth < nWidth; nNumWidth++)
		{
			pPDF[(unsigned char)ppReadImage->imageData[nNumHeight * ppReadImage->widthStep + nNumWidth]]++;
		}
	}

	// Image�� CDF function�� ����
	for(int nCount = 0; nCount < 256; nCount++)
	{
		nCDF += pPDF[nCount];
		pMappingfunction[nCount] = nCDF;
	}

	// Image�� Mapping function�� Normalization�Ͽ� Ratio function�� ����
	for(int nCount = 0; nCount < 256; nCount++)
	{
		pRatioFunction[nCount] = floor(dNormalization*pMappingfunction[nCount]+0.5);
	}

	// Ration Function�� data�� �̿��Ͽ�, Image�� reconstruction
	for(int nNumHeight = 0; nNumHeight < nHeight; nNumHeight++)
	{
		for(int nNumWidth = 0; nNumWidth < nWidth; nNumWidth++)
		{
			ppImage->imageData[nNumHeight * ppReadImage->widthStep + nNumWidth] = pRatioFunction[(unsigned char)ppReadImage->imageData[nNumHeight * ppReadImage->widthStep + nNumWidth]];
		}
	}

	return ppImage;
}

void ImageProcess::SketchEffect1(int* ImageArray,int width, int height)
{
	temp_Image = (char*)ImageArray;
	IplImage* Image = cvCreateImage(cvSize(width,height),IPL_DEPTH_8U,3);
	IplImage* gray;
	IplImage* temp;

	IplConvKernel* element =cvCreateStructuringElementEx (9, 9, 4, 4, CV_SHAPE_RECT, NULL);

	for(int h = 0 ; h<height ; h++)
	{
		for(int w = 0 ; w<width ; w++)
		{
			Image->imageData[h * Image->widthStep + w * 3 + 0] = temp_Image[(h * width + w) * 4 + 0]; //B
			Image->imageData[h * Image->widthStep + w * 3 + 1] = temp_Image[(h * width + w) * 4 + 1]; //G
			Image->imageData[h * Image->widthStep + w * 3 + 2] = temp_Image[(h * width + w) * 4 + 2]; //R
			//Image->imageData[(h * width + w) * channel + 3] = temp_Image[(h * width + w) * channel + 3]; //A
		}
	}
	
	int level = 2;

	//IplImage* meanshift = cvCreateImage(cvGetSize(Image),IPL_DEPTH_8U,3);
	cvPyrMeanShiftFiltering (Image, Image, 3, 20 ,level,	cvTermCriteria (CV_TERMCRIT_ITER + CV_TERMCRIT_EPS, 5, 1));



	IplImage* meansiftGray = cvCreateImage(cvGetSize(Image),IPL_DEPTH_8U,1);
	cvCvtColor(Image,meansiftGray,CV_RGBA2GRAY);

	//cvReleaseImage(&meanshift);


	IplImage* Xflow = cvCreateImage(cvGetSize(Image),IPL_DEPTH_16S,1);
	IplImage* Yflow = cvCreateImage(cvGetSize(Image),IPL_DEPTH_16S,1);
	cvSobel(meansiftGray, Xflow, 1,0);
	cvSobel(meansiftGray, Yflow, 0,1);

	cvReleaseImage(&meansiftGray);


	cvNot(Xflow,Xflow);
	cvNot(Yflow,Yflow);
	IplImage* XYflow = cvCreateImage(cvGetSize(Image),IPL_DEPTH_16S,1);
	cvAdd(Xflow,Yflow,XYflow);
	cvNot(XYflow,XYflow);
	temp= cvCreateImage(cvGetSize(Image),IPL_DEPTH_8U,1);
	cvConvertScaleAbs(XYflow,temp);
	cvReleaseImage(&Xflow);
	cvReleaseImage(&Yflow);
	cvReleaseImage(&XYflow);
	cvReleaseImage(&Image);
	cvNot(temp,temp);

	unsigned char pixel;
	for(int h = 0 ; h<height ; h++)
	{
		for(int w = 0 ; w<width ; w++)
		{
			pixel = temp->imageData[h * temp->widthStep + w];
			temp_Image[(h * width + w) * 4 + 0] = 0;// Image->imageData[h * Image->widthStep + w * 3 + 0]; //R
			temp_Image[(h * width + w) * 4 + 1] = 0;//Image->imageData[h * Image->widthStep + w * 3 + 1]; //G
			temp_Image[(h * width + w) * 4 + 2] = 0;//Image->imageData[h * Image->widthStep + w * 3 + 2]; //B
			//    				if(pixel <= 200)
			//    					temp_Image[(h * width + w) * 4 + 3] =255; //A
			//  				else{
			//     				//	temp_Image[(h * width + w) * 4 + 3] = 255; //A
			temp_Image[(h * width + w) * 4 + 3] = 255-pixel; //A
			//				}
		}
	}
	temp_Image = NULL;
	cvReleaseImage(&temp);
}


void ImageProcess::SketchEffect2(int* ImageArray,int width, int height)
{
	temp_Image = (char*)ImageArray;

	IplImage* Image = cvCreateImage(cvSize(width,height),IPL_DEPTH_8U,3);
	IplImage* Gray	=  cvCreateImage(cvSize(width,height),IPL_DEPTH_8U,1);

	float** ppFilter;

	ppFilter = new float*[3];
	for(int i = 0 ; i< 3 ;i++)
		ppFilter[i] = new float[3];

	ppFilter[0][0] = -1;	ppFilter[0][1] = -1;	ppFilter[0][2] = -1;
	ppFilter[1][0] = -1;	ppFilter[1][1] = 9;		ppFilter[1][2] = -1;
	ppFilter[2][0] = -1;	ppFilter[2][1] = -1;	ppFilter[2][2] = -1;

	for(int h = 0 ; h<height ; h++)
	{
		for(int w = 0 ; w<width ; w++)
		{
			Image->imageData[h * Image->widthStep + w * 3 + 0] = temp_Image[(h * width + w) * 4 + 0]; //B
			Image->imageData[h * Image->widthStep + w * 3 + 1] = temp_Image[(h * width + w) * 4 + 1]; //G
			Image->imageData[h * Image->widthStep + w * 3 + 2] = temp_Image[(h * width + w) * 4 + 2]; //R
			//Image->imageData[(h * width + w) * channel + 3] = temp_Image[(h * width + w) * channel + 3]; //A
		}
	}


	// (1)�̹����� MeanShift�� ����Ѵ�
	// 	cvPyrMeanShiftFiltering (Image, Image, 30.0, 30.0, 2,
	// 		cvTermCriteria (CV_TERMCRIT_ITER + CV_TERMCRIT_EPS, 5, 1));

	cvPyrMeanShiftFiltering (Image, Image, 3, 10, 1,
		cvTermCriteria (CV_TERMCRIT_ITER + CV_TERMCRIT_EPS, 5, 1));

	// (2)�̹����� �о���δ�
	cvCvtColor (Image, Gray, CV_BGR2GRAY);

	Gray = RAWToJPG(SymmetricExtension(JPGToRAW(Gray) ,Gray->height, Gray->width, ppFilter,3,3),Gray->height,Gray->width);

	// (3)����þ��Ǹ�Ÿ�� ��Ȱȭ�� �ǽ��Ѵ�
	cvSmooth (Gray, Gray, CV_GAUSSIAN, 5);

	cvAdaptiveThreshold (Gray, Gray, 255, CV_ADAPTIVE_THRESH_MEAN_C,
		CV_THRESH_BINARY, 11, 10);

	unsigned char pixel;

	for(int h = 0 ; h<height ; h++)
	{
		for(int w = 0 ; w<width ; w++)
		{
			pixel= Gray->imageData[h * Gray->widthStep + w];
			temp_Image[(h * width + w) * 4 + 0] = 0;// Image->imageData[h * Image->widthStep + w * 3 + 0]; //R
			temp_Image[(h * width + w) * 4 + 1] = 0;//Image->imageData[h * Image->widthStep + w * 3 + 1]; //G
			temp_Image[(h * width + w) * 4 + 2] = 0;//Image->imageData[h * Image->widthStep + w * 3 + 2]; //B

			temp_Image[(h * width + w) * 4 + 3] = 255-pixel; //A
		}
	}
	temp_Image = NULL;

	cvReleaseImage(&Image);
	cvReleaseImage(&Gray);
}


void ImageProcess::GrayEffect(int* ImageArray,int width, int height)
{
	temp_Image = (char*)ImageArray;
	IplImage* Image = cvCreateImage(cvSize(width,height),IPL_DEPTH_8U,3);
	IplImage* gray;
	IplImage* temp;

	IplConvKernel* element =cvCreateStructuringElementEx (9, 9, 4, 4, CV_SHAPE_RECT, NULL);

	for(int h = 0 ; h<height ; h++)
	{
		for(int w = 0 ; w<width ; w++)
		{
			Image->imageData[h * Image->widthStep + w * 3 + 0] = temp_Image[(h * width + w) * 4 + 0]; //B
			Image->imageData[h * Image->widthStep + w * 3 + 1] = temp_Image[(h * width + w) * 4 + 1]; //G
			Image->imageData[h * Image->widthStep + w * 3 + 2] = temp_Image[(h * width + w) * 4 + 2]; //R
			//Image->imageData[(h * width + w) * channel + 3] = temp_Image[(h * width + w) * channel + 3]; //A
		}
	}

	gray = cvCreateImage(cvSize(width,height),IPL_DEPTH_8U,1);
	cvCvtColor(Image,gray,CV_RGBA2GRAY);
	cvReleaseImage(&Image);


	for(int h = 0 ; h<height ; h++)
	{
		for(int w = 0 ; w<width ; w++)
		{
			temp_Image[(h * width + w) * 4 + 0] = gray->imageData[h * gray->widthStep + w]; //R
			temp_Image[(h * width + w) * 4 + 1] = gray->imageData[h * gray->widthStep + w]; //G
			temp_Image[(h * width + w) * 4 + 2] = gray->imageData[h * gray->widthStep + w]; //B
			//	temp_Image[(h * width + w) * channel + 3] = Image->imageData[(h * width + w) * channel + 3]; //A
		}
	}
	temp_Image = NULL;
	cvReleaseImage(&gray);
}


void ImageProcess:: OilPaintEffect(int* ImageArray,int width, int height,int nRadius, int nDifferentIntensity)
{

	temp_Image = (char*)ImageArray;
	IplImage* Image = cvCreateImage(cvSize(width,height),IPL_DEPTH_8U,3);
	for(int h = 0 ; h<height ; h++)
	{
		for(int w = 0 ; w<width ; w++)
		{
			Image->imageData[h * Image->widthStep + w * 3 + 0] = temp_Image[(h * width + w) * 4 + 0]; //B
			Image->imageData[h * Image->widthStep + w * 3 + 1] = temp_Image[(h * width + w) * 4 + 1]; //G
			Image->imageData[h * Image->widthStep + w * 3 + 2] = temp_Image[(h * width + w) * 4 + 2]; //R
			//Image->imageData[(h * width + w) * channel + 3] = temp_Image[(h * width + w) * channel + 3]; //A
		}
	}

	if(Image != NULL)
	{

		cvSmooth(Image,Image,CV_MEDIAN,3,3,0);
		cvSmooth(Image,Image,CV_MEDIAN,3,3,0);
		cvSmooth(Image,Image,CV_MEDIAN,3,3,0);



		CvMat* kernel;

		kernel = cvCreateMat(3,3,CV_32FC1); 

		kernel->data.fl[0] =-1; kernel->data.fl[1] =-1; kernel->data.fl[2] =-1; 
		kernel->data.fl[3] =-1; kernel->data.fl[4] =9; kernel->data.fl[5] =-1; 
		kernel->data.fl[6] =-1; kernel->data.fl[7] =-1; kernel->data.fl[8] =-1; 


		cvFilter2D(Image,Image, kernel); 

		cvSmooth(Image,Image,CV_MEDIAN,3,3,0);
		cvSmooth(Image,Image,CV_MEDIAN,3,3,0);
		cvSmooth(Image,Image,CV_MEDIAN,3,3,0);

		cvFilter2D(Image,Image, kernel); 



		for(int h = 0 ; h<height ; h++)
		{
			for(int w = 0 ; w<width ; w++)
			{
				temp_Image[(h * width + w) * 4 + 0] = Image->imageData[h * Image->widthStep + w * 3 + 0]; //R
				temp_Image[(h * width + w) * 4 + 1] = Image->imageData[h * Image->widthStep + w * 3 + 1]; //G
				temp_Image[(h * width + w) * 4 + 2] = Image->imageData[h * Image->widthStep + w * 3 + 2]; //B
				//	temp_Image[(h * width + w) * channel + 3] = Image->imageData[(h * width + w) * channel + 3]; //A
			}
		}
		cvReleaseImage(&Image);
		cvReleaseMat(& kernel); 
		temp_Image = NULL;

	}
}


void ImageProcess::WaterColorEffect(int* ImageArray,int width, int height)
{
	temp_Image = (char*)ImageArray;
	IplImage* Image = cvCreateImage(cvSize(width,height),IPL_DEPTH_8U,3);

	for(int h = 0 ; h<height ; h++)
	{
		for(int w = 0 ; w<width ; w++)
		{
			Image->imageData[h * Image->widthStep + w * 3 + 0] = temp_Image[(h * width + w) * 4 + 0]; //B
			Image->imageData[h * Image->widthStep + w * 3 + 1] = temp_Image[(h * width + w) * 4 + 1]; //G
			Image->imageData[h * Image->widthStep + w * 3 + 2] = temp_Image[(h * width + w) * 4 + 2]; //R
			//Image->imageData[(h * width + w) * channel + 3] = temp_Image[(h * width + w) * channel + 3]; //A
		}
	}

	IplImage* meanshift = cvCreateImage(cvGetSize(Image), Image->depth, Image->nChannels);
	cvPyrMeanShiftFiltering(Image, meanshift, 6, 40);
	cvReleaseImage(&Image);

	for(int h = 0 ; h<height ; h++)
	{
		for(int w = 0 ; w<width ; w++)
		{
			temp_Image[(h * width + w) * 4 + 0] = meanshift->imageData[h * meanshift->widthStep + w * 3 + 0]; //R
			temp_Image[(h * width + w) * 4 + 1] = meanshift->imageData[h * meanshift->widthStep + w * 3 + 1]; //G
			temp_Image[(h * width + w) * 4 + 2] = meanshift->imageData[h * meanshift->widthStep + w * 3 + 2]; //B
			//	temp_Image[(h * width + w) * channel + 3] = Image->imageData[(h * width + w) * channel + 3]; //A
		}
	}
	cvReleaseImage(&meanshift);
	temp_Image = NULL;
}



unsigned char** ImageProcess::SymmetricExtension(unsigned char** ppReadImage, int const &nImgHeight, int const &nImgWidth, float** ppFilter, int const &nFilterHeight, int const &nFilterWidth)
{
	unsigned char** ppImage;

	int nBandHeight = nFilterHeight/2;
	int nBandWidth = nFilterWidth/2;

	int nPosition_X;
	int nPosition_Y;

	int nFilter_X;
	int nFilter_Y;

	int nMaxValue = 0;

	// ����ȭ�� Image�� �����ϱ� ���� 2���� �迭�� �����Ҵ�
	ppImage = new unsigned char*[nImgHeight];
	for(int nNumHeight = 0; nNumHeight < nImgHeight; nNumHeight++)
	{
		ppImage[nNumHeight] = new unsigned char[nImgWidth];
	}

	// Filtered Image
	for(int nNumHeight = 0; nNumHeight < nImgHeight; nNumHeight++)
	{
		for(int nNumWidth = 0; nNumWidth < nImgWidth; nNumWidth++)
		{
			float fConvolution = 0.0;

			for(int nY = -nBandHeight; nY <= nBandHeight; nY++)
			{
				for(int nX = -nBandWidth; nX <= nBandWidth; nX++)
				{
					nPosition_X = nX + nNumWidth;
					nPosition_Y = nY + nNumHeight;

					nFilter_X	= nX + nBandWidth;
					nFilter_Y	= nY + nBandHeight;

					if(nPosition_X < 0)
					{
						nPosition_X = abs(nNumWidth+nX)-1;
					}
					else if(nPosition_X >= nImgWidth)
					{
						nPosition_X = nImgWidth - ((nNumWidth+nX)%nImgWidth + 1);
					}

					if(nPosition_Y < 0)
					{
						nPosition_Y = abs(nNumHeight+nY)-1;
					}
					else if(nPosition_Y >= nImgHeight)
					{
						nPosition_Y = nImgHeight - ((nNumHeight+nX)%nImgHeight + 1);
					}

					// Filtering�� Image Pixel ��
					fConvolution += ppReadImage[nPosition_Y][nPosition_X]*ppFilter[nFilter_Y][nFilter_X];
				}
			}

			if(fConvolution < 0)
			{
				fConvolution = 0.0;
			}
			else if(fConvolution > 255.0)
			{
				fConvolution = 255.0;
			}

			ppImage[nNumHeight][nNumWidth] = (unsigned char)fConvolution;
		}
	}

	return ppImage;
}

unsigned char** ImageProcess::JPGToRAW(IplImage* pIplImage)
{
	int nHeight = pIplImage->height;
	int nWidth = pIplImage->width;

	unsigned char** ppImage;

	// Image�� �����ϱ� ���� 3���� �迭�� �����Ҵ�
	ppImage = new unsigned char*[nHeight];

	for(int nNumHeight = 0; nNumHeight < nHeight; nNumHeight++)
	{
		ppImage[nNumHeight] = new unsigned char[nWidth];
	}

	for(int y = 0; y < nHeight; y++)
	{
		for(int x = 0; x < nWidth; x++)
		{
			ppImage[y][x] = pIplImage->imageData[pIplImage->widthStep*y +x];
		}
	}

	return ppImage;
}


IplImage* ImageProcess::RAWToJPG(unsigned char** ppImage, int nHeight, int nWidth)
{
	IplImage* pIplImage = cvCreateImage(cvSize(nWidth, nHeight), IPL_DEPTH_8U, 1);

	for(int y = 0; y < nHeight; y++)
	{
		for(int x = 0; x < nWidth; x++)
		{
			pIplImage->imageData[pIplImage->widthStep*y +x] = ppImage[y][x];
		}
	}

	return pIplImage;
}