#include<AnimationProcess.h>

ColorRGB Darken(IplImage *pImage, int nHeight, int nWidth, unsigned char chDarkenLevel);
ColorRGB Lighten(IplImage *pImage, int nHeight, int nWidth, unsigned char chLightenLevel);
void ColorReplace(ColorRGB colorRGB, IplImage *pProcessingImage, int nHeight, int nWidth);
void ColorReplace(IplImage *pOriginalImage, int nOriginalHeight, int nOriginalWidth, IplImage *pProcessingImage, int nProcessingHeight, int nProcessingWidth);
void ColorReplace(IplImage *pOriginalImage, IplImage *pProcessingImage, int nHeight, int nWidth);
double Calculation (int Center_X, int Center_Y, int coordinate_X, int coordinate_Y);

AnimationProcess::AnimationProcess(void)
{
}

AnimationProcess::~AnimationProcess(void)
{
	free(temp_Image);
}

void AnimationProcess::RainDropEffect(int* ImageArray,int width,int height,int xPoint,int yPoint)
{
	temp_Image = (char*)ImageArray;
	IplImage* pOriginalImage = cvCreateImage(cvSize(width,height),IPL_DEPTH_8U,3);
	srand(time(NULL));
	for(int h = 0 ; h<height ; h++)
	{
		for(int w = 0 ; w<width ; w++)
		{
			pOriginalImage->imageData[h * pOriginalImage->widthStep + w * 3 + 0] = temp_Image[(h * width + w) * 4 + 0]; //B
			pOriginalImage->imageData[h * pOriginalImage->widthStep + w * 3 + 1] = temp_Image[(h * width + w) * 4 + 1]; //G
			pOriginalImage->imageData[h * pOriginalImage->widthStep + w * 3 + 2] = temp_Image[(h * width + w) * 4 + 2]; //R
			//Image->imageData[(h * width + w) * channel + 3] = temp_Image[(h * width + w) * channel + 3]; //A
		}
	}


	int nDivisionRadian = 200;

	int nRaindropLevel = 50; // 1 ~ 100
	int nRaindropDensity = 20; // 1 ~ 100
	bool bHighlightShadow = true; // true or false

	srand(time(NULL));

	IplImage *pProcessingImage;
	pProcessingImage = cvCreateImage(cvGetSize(pOriginalImage), IPL_DEPTH_8U, 3);

	int nRandomHeight;
	int nRandomWidth;

	double dRadius;
	double dPreRadius;
	double dAngle;

	int nConvertHeight;
	int nConvertWidth;

	int nAroundHeight;
	int nAroundWidth;

	bool bFindAnother = false;

	int nCount = 0;

	int nCurSize;
	int nHalfCurSize;
	int nMaxRadius;

	double dFisheyeCoefficients = 0.4;
	double dTransformationCoefficient;


	int nBlurRadius;

	float fRed;
	float fGreen;
	float fBlue;

	unsigned char chR;
	unsigned char chG;
	unsigned char chB;

	int nBlurNum;

	bool **ppBoolMatrix;

	ppBoolMatrix = new bool *[height];
	for(int nHeight = 0; nHeight < height; nHeight++)
	{
		ppBoolMatrix[nHeight] = new bool[width];
	}

	for(int nHeight = 0; nHeight < height; nHeight++)
	{
		for(int nWidth = 0; nWidth < width; nWidth++)
		{
			ppBoolMatrix[nHeight][nWidth] = false;

			ColorReplace(pOriginalImage, pProcessingImage, nHeight, nWidth);

		}
	}

	for(int nRainDropNum = 0; nRainDropNum < nRaindropDensity; nRainDropNum++)
	{
		nCurSize = (int)(rand()*((double)(nRaindropLevel - 5) / RAND_MAX) + 5);

		nHalfCurSize = nCurSize/2;

		nMaxRadius = nHalfCurSize;

		dTransformationCoefficient = nMaxRadius/log(dFisheyeCoefficients*nMaxRadius + 1);

		nCount = 0;

		do 
		{
			bFindAnother = false;
			int x,y;
			x = (int)((rand()%nDivisionRadian)*cos(rand()) + xPoint); 
			y = (int)((rand()%nDivisionRadian)*sin(rand()) + yPoint);
			nRandomHeight =min(max(y , 0),height-1);
			nRandomWidth = min(max(x , 0),width-1);

			LOGE("rand end xPoint : %d yPoint : %d  nRandomHeight : %d      nRandomWidth : %d  :",xPoint,yPoint ,nRandomHeight  ,nRandomWidth );
			if(ppBoolMatrix[nRandomHeight][nRandomWidth])
			{
				bFindAnother = true;
			}
			else
			{
				for(int nHeight = nRandomHeight - nHalfCurSize; nHeight <= nRandomHeight + nHalfCurSize; nHeight++)
				{
					for(int nWidth = nRandomWidth - nHalfCurSize; nWidth <= nRandomWidth + nHalfCurSize; nWidth++)
					{
						if(nHeight >= 0 && nHeight < height && nWidth >= 0 && nWidth < width)
						{
							if(ppBoolMatrix[nHeight][nWidth])
							{
								bFindAnother = true;
							}
						}

					}
				}
			}

			nCount++;

		} while (bFindAnother && (nCount < 10000));

		
		if(nCount >= 10000)
		{
			nRainDropNum = nRaindropDensity;
		}

		for(int nHeight = -nHalfCurSize; nHeight < nCurSize - nHalfCurSize; nHeight++)
		{
			for(int nWidth = -nHalfCurSize; nWidth < nCurSize - nHalfCurSize; nWidth++)
			{
				dRadius = sqrt(pow(nHeight, 2.0) + pow(nWidth, 2.0));
				dAngle = (double)atan2((double)nWidth, (double)nHeight);

				if(dRadius <= nMaxRadius)
				{
					dPreRadius = dRadius;

					dRadius = (exp(dRadius/dTransformationCoefficient) - 1)/dFisheyeCoefficients;

					nConvertHeight = nRandomHeight + (int)(dRadius*cos(dAngle));
					nConvertWidth = nRandomWidth + (int)(dRadius*sin(dAngle));

					nAroundHeight = nRandomHeight + nHeight;
					nAroundWidth = nRandomWidth + nWidth;
					
					if(nConvertHeight >= 0 && nConvertHeight < pOriginalImage->height && nConvertWidth >= 0 && nConvertWidth < pOriginalImage->width)
					{
						if(nAroundHeight >= 0 && nAroundHeight < pOriginalImage->height && nAroundWidth >= 0 && nAroundWidth < pOriginalImage->width)
						{

							chR = pOriginalImage->imageData[nConvertHeight*pOriginalImage->widthStep + nConvertWidth*CHANNEL3 + RED];
							chG = pOriginalImage->imageData[nConvertHeight*pOriginalImage->widthStep + nConvertWidth*CHANNEL3 + GREEN];
							chB = pOriginalImage->imageData[nConvertHeight*pOriginalImage->widthStep + nConvertWidth*CHANNEL3 + BLUE];
							ColorReplace(pOriginalImage, nConvertHeight, nConvertWidth, pProcessingImage, nAroundHeight, nAroundWidth);

							ppBoolMatrix[nAroundHeight][nAroundWidth] = true;

							if(bHighlightShadow)
							{
								ColorRGB colorTemp = {chR, chG, chB};

								if(dPreRadius >= 0.9 * nMaxRadius)
								{
									if((dAngle <= 0.0) && (dAngle > -2.25))
									{
										colorTemp = Darken(pProcessingImage, nAroundHeight, nAroundWidth, 80);
									}
									else if((dAngle <= -2.25) && (dAngle > -2.5))
									{
										colorTemp = Darken(pProcessingImage, nAroundHeight, nAroundWidth, 40);
									}
									else if((dAngle <= 0.25) && (dAngle > 0))
									{
										colorTemp = Darken(pProcessingImage, nAroundHeight, nAroundWidth, 40);
									}
								}

								else if(dPreRadius >= 0.8 * nMaxRadius)
								{
									if((dAngle <= -0.75) && (dAngle > -1.50))
									{
										colorTemp = Darken(pProcessingImage, nAroundHeight, nAroundWidth, 40);
									}
									else if((dAngle <= 0.10) && (dAngle > -0.75))
									{
										colorTemp = Darken(pProcessingImage, nAroundHeight, nAroundWidth, 30);
									}
									else if((dAngle <= -1.50) && (dAngle > -2.35))
									{
										colorTemp = Darken(pProcessingImage, nAroundHeight, nAroundWidth, 30);
									}
								}

								else if(dPreRadius >= 0.7 * nMaxRadius)
								{
									if((dAngle <= -0.10) && (dAngle > -2.0))
									{
										colorTemp = Darken(pProcessingImage, nAroundHeight, nAroundWidth, 20);
									}
									else if((dAngle <= 2.50) && (dAngle > 1.90))
									{
										colorTemp = Lighten(pProcessingImage, nAroundHeight, nAroundWidth, 60);
									}
								}

								else if(dPreRadius >= 0.6 * nMaxRadius)
								{
									if((dAngle <= -0.50) && (dAngle > -1.75))
									{
										colorTemp = Darken(pProcessingImage, nAroundHeight, nAroundWidth, 20);
									}
									else if((dAngle <= 0.0) && (dAngle > -0.25))
									{
										colorTemp = Lighten(pProcessingImage, nAroundHeight, nAroundWidth, 20);
									}
									else if((dAngle <= -2.0) && (dAngle > -2.25))
									{
										colorTemp = Lighten(pProcessingImage, nAroundHeight, nAroundWidth, 20);
									}
								}

								else if(dPreRadius >= 0.5 * nMaxRadius)
								{
									if((dAngle <= -0.25) && (dAngle > -0.50))
									{
										colorTemp = Lighten(pProcessingImage, nAroundHeight, nAroundWidth, 30);
									}
									else if((dAngle <= -1.75) && (dAngle > -2.0))
									{
										colorTemp = Lighten(pProcessingImage, nAroundHeight, nAroundWidth, 30);
									}
								}

								else if(dPreRadius >= 0.4 * nMaxRadius)
								{
									if((dAngle <= -0.5) && (dAngle > -1.75))
									{
										colorTemp = Lighten(pProcessingImage, nAroundHeight, nAroundWidth, 40);
									}
								}

								else if(dPreRadius >= 0.3 * nMaxRadius)
								{
									if((dAngle <= 0.0) && (dAngle > -2.25))
									{
										colorTemp = Lighten(pProcessingImage, nAroundHeight, nAroundWidth, 30);
									}
								}

								else if(dPreRadius >= 0.2 * nMaxRadius)
								{
									if((dAngle <= -0.5) && (dAngle > -1.75))
									{
										colorTemp = Lighten(pProcessingImage, nAroundHeight, nAroundWidth, 20);
									}
								}

								ColorReplace(colorTemp, pProcessingImage, nAroundHeight, nAroundWidth);

							}
						}
					}
				}
			}
		}

		if(bHighlightShadow)
		{
			nBlurRadius = nCurSize/25 + 1;

			for(int nHeight = -nHalfCurSize - nBlurRadius; nHeight < nCurSize - nHalfCurSize + nBlurRadius; nHeight++)
			{
				for(int nWidth = -nHalfCurSize - nBlurRadius; nWidth < nCurSize - nHalfCurSize + nBlurRadius; nWidth++)
				{
					dRadius = sqrt(pow(nHeight, 2.0) + pow(nWidth, 2.0));

					if(dRadius <= nMaxRadius*1.1)
					{
						fRed = 0.0;
						fGreen = 0.0;
						fBlue = 0.0;

						nBlurNum = 0;

						for(nConvertHeight = -nBlurRadius; nConvertHeight < nBlurRadius + 1; nConvertHeight++)
						{
							for(nConvertWidth = -nBlurRadius; nConvertWidth < nBlurRadius + 1; nConvertWidth++)
							{
								nAroundHeight = nRandomHeight + nHeight + nConvertHeight;
								nAroundWidth = nRandomWidth + nWidth + nConvertWidth;

								if(nAroundHeight >= 0 && nAroundHeight < pProcessingImage->height && nAroundWidth >= 0 && nAroundWidth < pProcessingImage->width)
								{
									chR = pProcessingImage->imageData[nAroundHeight*pProcessingImage->widthStep + nAroundWidth*CHANNEL3 + RED];
									chG = pProcessingImage->imageData[nAroundHeight*pProcessingImage->widthStep + nAroundWidth*CHANNEL3 + GREEN];
									chB = pProcessingImage->imageData[nAroundHeight*pProcessingImage->widthStep + nAroundWidth*CHANNEL3 + BLUE];

									fRed += chR;
									fGreen += chG;
									fBlue += chB;

									nBlurNum++;
								}
							}
						}

						nAroundHeight = nRandomHeight + nHeight;
						nAroundWidth = nRandomWidth + nWidth;

						if(nAroundHeight >= 0 && nAroundHeight < pProcessingImage->height && nAroundWidth >= 0 && nAroundWidth < pProcessingImage->width)
						{
							ColorRGB colorTemp = {(unsigned char)(fRed/nBlurNum), (unsigned char)(fGreen/nBlurNum), (unsigned char)(fBlue/nBlurNum)};

							ColorReplace(colorTemp, pProcessingImage, nAroundHeight, nAroundWidth);

						}
					}
				}
			}
		}

	}

	for(int nHeight = 0; nHeight < pOriginalImage->height; nHeight++)
	{
		delete []ppBoolMatrix[nHeight];
	}

	delete []ppBoolMatrix;

	cvReleaseImage(&pOriginalImage);

	for(int h = 0 ; h<height ; h++)
	{
		for(int w = 0 ; w<width ; w++)
		{
			temp_Image[(h * width + w) * 4 + 0] = pProcessingImage->imageData[h * pProcessingImage->widthStep + w * 3 + 0]; //R
			temp_Image[(h * width + w) * 4 + 1] = pProcessingImage->imageData[h * pProcessingImage->widthStep + w * 3 + 1]; //G
			temp_Image[(h * width + w) * 4 + 2] = pProcessingImage->imageData[h * pProcessingImage->widthStep + w * 3 + 2]; //B
			//	temp_Image[(h * width + w) * channel + 3] = Image->imageData[(h * width + w) * channel + 3]; //A
		}
	}
	cvReleaseImage(&pProcessingImage);
	temp_Image = NULL;

}



void AnimationProcess::LightEffect(int* ImageArray,int width,int height,int xPoint, int yPoint)
{

	temp_Image = (char*)ImageArray;
	IplImage* Image = cvCreateImage(cvSize(width,height),IPL_DEPTH_8U,3);

	for(int h = 0 ; h<height ; h++)
	{
		for(int w = 0 ; w<width ; w++)
		{
			Image->imageData[h * Image->widthStep + w * 3 + 0] = temp_Image[(h * width + w) * 4 + 0]; //B
			Image->imageData[h * Image->widthStep + w * 3 + 1] = temp_Image[(h * width + w) * 4 + 1]; //G
			Image->imageData[h * Image->widthStep + w * 3 + 2] = temp_Image[(h * width + w) * 4 + 2]; //R
			//Image->imageData[(h * width + w) * channel + 3] = temp_Image[(h * width + w) * channel + 3]; //A
		}
	}


	int Edge_coordinate[8] = {0, }; //index (0,1 - LeftTop), (2,3 - RightTop), (4,5 - LeftBottom), (6,7 - RightBottom)
	double Length_rad[4] = {0, };
	double Max_rad = 0;

	int rad=10; 
	int count = 0;
	int RGB_R = 150, RGB_G = 150, RGB_B = 150;
	int Duty;

	Edge_coordinate[2] = Image->width;
	Edge_coordinate[5] = Image->height;
	Edge_coordinate[6] = Image->width;
	Edge_coordinate[7] = Image->height;


	Length_rad[0] = Calculation(xPoint,yPoint, Edge_coordinate[0],Edge_coordinate[1]);
	Length_rad[1] = Calculation(xPoint,yPoint, Edge_coordinate[2],Edge_coordinate[3]);
	Length_rad[2] = Calculation(xPoint,yPoint, Edge_coordinate[4],Edge_coordinate[5]);
	Length_rad[3] = Calculation(xPoint,yPoint, Edge_coordinate[6],Edge_coordinate[7]);


	for(int i=0; i<4;i++)
	{
		if(Max_rad < Length_rad[i]) Max_rad = Length_rad[i];
	}

	Duty = (Max_rad - rad)/150;  // Count ���� ����

	IplImage* AddCircle = cvCreateImage(cvSize(Image->width,Image->height),IPL_DEPTH_8U,3); // Circle Image

	for(rad=0; rad<Max_rad;rad++)
	{

		cvCircle(AddCircle,cvPoint(xPoint,yPoint),rad,CV_RGB(RGB_R,RGB_G,RGB_B),2);
		count++;
		if(count==Duty)
		{
			RGB_B-=1;
			RGB_G-=1;
			RGB_R-=1;
			count=0;
		}

	}

	cvAdd(Image,AddCircle,Image,NULL);
	cvReleaseImage(&AddCircle);
	for(int h = 0 ; h<height ; h++)
	{
		for(int w = 0 ; w<width ; w++)
		{
			temp_Image[(h * width + w) * 4 + 0] = Image->imageData[h * Image->widthStep + 3 * w + 0]; //R
			temp_Image[(h * width + w) * 4 + 1] = Image->imageData[h * Image->widthStep + 3 * w + 1]; //G
			temp_Image[(h * width + w) * 4 + 2] = Image->imageData[h * Image->widthStep + 3 * w + 2]; //B
			//	temp_Image[(h * width + w) * channel + 3] = Image->imageData[(h * width + w) * channel + 3]; //A
		}
	}
	temp_Image = NULL;

	cvReleaseImage(&Image);



}



void AnimationProcess::FisheyeEffect(int* ImageArray,int width,int height,int xPoint,int yPoint)
{
	temp_Image = (char*)ImageArray;
	IplImage* pOriginalImage = cvCreateImage(cvSize(width,height),IPL_DEPTH_8U,3);

	double dCurvature = 200;
	bool bInverseFisheye = false;


	unsigned int nMaxiumRadius;
	double dTransformationCoefficient;

	int nHalfHeight;
	int nHalfWidth;

	double dRadius;
	double dAngle;

	int nOriginalHeight;
	int nOriginalWidth;

	int nNewHeight;
	int nNewWidth;


	LOGI("test");
	for(int h = 0 ; h<height ; h++)
	{
		for(int w = 0 ; w<width ; w++)
		{
			pOriginalImage->imageData[h * pOriginalImage->widthStep + w * 3 + 0] = temp_Image[(h * width + w) * 4 + 0]; //B
			pOriginalImage->imageData[h * pOriginalImage->widthStep + w * 3 + 1] = temp_Image[(h * width + w) * 4 + 1]; //G
			pOriginalImage->imageData[h * pOriginalImage->widthStep + w * 3 + 2] = temp_Image[(h * width + w) * 4 + 2]; //R
			//Image->imageData[(h * width + w) * channel + 3] = temp_Image[(h * width + w) * channel + 3]; //A
		}
	}

	 	IplImage *pProcessingImage;
	 	pProcessingImage = cvCreateImage(cvGetSize(pOriginalImage), IPL_DEPTH_8U, CHANNEL3);

		cvCopy(pOriginalImage,pProcessingImage);

	nHalfHeight = (height)/2;
	nHalfWidth = (width)/2;

	nMaxiumRadius = (min(width, height))/2;

	dCurvature *= 0.001;

	dTransformationCoefficient = nMaxiumRadius/log(dCurvature*nMaxiumRadius + 1);


	

	for(int nHeight = -nHalfHeight; nHeight < nHalfHeight; nHeight++)
	{
		for(int nWidth = -nHalfWidth; nWidth < nHalfWidth; nWidth++)
		{
			dRadius = sqrt(pow(nHeight, 2.0) + pow(nWidth, 2.0));
			dAngle  = atan2((double)nWidth, (double)nHeight);

			if(dRadius <= nMaxiumRadius)
			{
				if(!bInverseFisheye)
				{
					dRadius = (exp(dRadius/dTransformationCoefficient) - 1)/dCurvature;
				}
				else
				{
					dRadius = dTransformationCoefficient*log(1 + dCurvature*dRadius);
				}

				nNewHeight = (int)(dRadius*cos(dAngle));
				nNewWidth = (int)(dRadius*sin(dAngle));


				
				nNewHeight += yPoint;//nHalfHeight;
				nNewWidth += xPoint;//nHalfWidth;

				nOriginalHeight = nHeight + yPoint;//nHalfHeight;
				nOriginalWidth = nWidth + xPoint;//nHalfWidth;


				if(nNewHeight >= 0 && nNewHeight < height && nNewWidth >= 0 && nNewWidth < width )
					if(nOriginalHeight >= 0 && nOriginalHeight < height && nOriginalWidth >= 0 && nOriginalWidth < width)
						ColorReplace(pOriginalImage, nNewHeight, nNewWidth, pProcessingImage, nOriginalHeight, nOriginalWidth);

				// 				chR = pOriginalImage->imageData[nNewHeight*pOriginalImage->widthStep + nNewWidth*CHANNEL3 + RED];
				// 				chG = pOriginalImage->imageData[nNewHeight*pOriginalImage->widthStep + nNewWidth*CHANNEL3 + GREEN];
				// 				chB = pOriginalImage->imageData[nNewHeight*pOriginalImage->widthStep + nNewWidth*CHANNEL3 + BLUE];
				// 
				// 				pProcessingImage->imageData[nOriginalHeight*pProcessingImage->widthStep + nOriginalWidth*CHANNEL3 + RED] = chR;
				// 				pProcessingImage->imageData[nOriginalHeight*pProcessingImage->widthStep + nOriginalWidth*CHANNEL3 + GREEN] = chG;
				// 				pProcessingImage->imageData[nOriginalHeight*pProcessingImage->widthStep + nOriginalWidth*CHANNEL3 + BLUE] = chB;
			}
			else
			{
				nOriginalHeight = nHeight + yPoint;//nHalfHeight;
				nOriginalWidth = nWidth + xPoint;//nHalfWidth;

				if(nOriginalHeight >= 0 && nOriginalHeight < height && nOriginalWidth >= 0 && nOriginalWidth < width)
					ColorReplace(pOriginalImage, pProcessingImage, nOriginalHeight, nOriginalWidth);

				// 				chR = pOriginalImage->imageData[nOriginalHeight*pOriginalImage->widthStep + nOriginalWidth*CHANNEL3 + RED];
				// 				chG = pOriginalImage->imageData[nOriginalHeight*pOriginalImage->widthStep + nOriginalWidth*CHANNEL3 + GREEN];
				// 				chB = pOriginalImage->imageData[nOriginalHeight*pOriginalImage->widthStep + nOriginalWidth*CHANNEL3 + BLUE];
				// 
				// 				pProcessingImage->imageData[nOriginalHeight*pProcessingImage->widthStep + nOriginalWidth*CHANNEL3 + RED] = chR;
				// 				pProcessingImage->imageData[nOriginalHeight*pProcessingImage->widthStep + nOriginalWidth*CHANNEL3 + GREEN] = chG;
				// 				pProcessingImage->imageData[nOriginalHeight*pProcessingImage->widthStep + nOriginalWidth*CHANNEL3 + BLUE] = chB;
			}
		}
	}


	for(int h = 0 ; h<height ; h++)
	{
		for(int w = 0 ; w<width ; w++)
		{
			temp_Image[(h * width + w) * 4 + 0] = pProcessingImage->imageData[h * pProcessingImage->widthStep + 3 * w + 0]; //R
			temp_Image[(h * width + w) * 4 + 1] = pProcessingImage->imageData[h * pProcessingImage->widthStep + 3 * w + 1]; //G
			temp_Image[(h * width + w) * 4 + 2] = pProcessingImage->imageData[h * pProcessingImage->widthStep + 3 * w + 2]; //B
			//	temp_Image[(h * width + w) * channel + 3] = Image->imageData[(h * width + w) * channel + 3]; //A
		}
	}
	temp_Image = NULL;
	cvReleaseImage(&pOriginalImage);
	cvReleaseImage(&pProcessingImage);
}
















double Calculation (int Center_X, int Center_Y, int coordinate_X, int coordinate_Y)
{
	double dis_x=0, dis_y=0, dis_length=0;

	dis_x = (Center_X - coordinate_X); //x�� �Ÿ����
	dis_x = dis_x * dis_x;

	dis_y = (Center_Y - coordinate_Y); //y�� �Ÿ� ���
	dis_y = dis_y * dis_y;

	dis_length = sqrt(dis_x+dis_y);

	return dis_length;

}







































void ColorReplace(IplImage *pOriginalImage, IplImage *pProcessingImage, int nHeight, int nWidth)
{
	unsigned char chR;
	unsigned char chG;
	unsigned char chB;

	chR = pOriginalImage->imageData[nHeight*pOriginalImage->widthStep + nWidth*CHANNEL3 + RED];
	chG = pOriginalImage->imageData[nHeight*pOriginalImage->widthStep + nWidth*CHANNEL3 + GREEN];
	chB = pOriginalImage->imageData[nHeight*pOriginalImage->widthStep + nWidth*CHANNEL3 + BLUE];

	pProcessingImage->imageData[nHeight*pProcessingImage->widthStep + nWidth*CHANNEL3 + RED]	= chR;
	pProcessingImage->imageData[nHeight*pProcessingImage->widthStep + nWidth*CHANNEL3 + GREEN]	= chG;
	pProcessingImage->imageData[nHeight*pProcessingImage->widthStep + nWidth*CHANNEL3 + BLUE]	= chB;
}

void ColorReplace(IplImage *pOriginalImage, int nOriginalHeight, int nOriginalWidth, IplImage *pProcessingImage, int nProcessingHeight, int nProcessingWidth)
{
	unsigned char chR;
	unsigned char chG;
	unsigned char chB;

	chR = pOriginalImage->imageData[nOriginalHeight*pOriginalImage->widthStep + nOriginalWidth*CHANNEL3 + RED];
	chG = pOriginalImage->imageData[nOriginalHeight*pOriginalImage->widthStep + nOriginalWidth*CHANNEL3 + GREEN];
	chB = pOriginalImage->imageData[nOriginalHeight*pOriginalImage->widthStep + nOriginalWidth*CHANNEL3 + BLUE];

	pProcessingImage->imageData[nProcessingHeight*pProcessingImage->widthStep + nProcessingWidth*CHANNEL3 + RED]	= chR;
	pProcessingImage->imageData[nProcessingHeight*pProcessingImage->widthStep + nProcessingWidth*CHANNEL3 + GREEN]	= chG;
	pProcessingImage->imageData[nProcessingHeight*pProcessingImage->widthStep + nProcessingWidth*CHANNEL3 + BLUE]	= chB;
}

void ColorReplace(ColorRGB colorRGB, IplImage *pProcessingImage, int nHeight, int nWidth)
{
	pProcessingImage->imageData[nHeight*pProcessingImage->widthStep + nWidth*CHANNEL3 + RED]	= colorRGB.chColorR;
	pProcessingImage->imageData[nHeight*pProcessingImage->widthStep + nWidth*CHANNEL3 + GREEN]	= colorRGB.chColorG;
	pProcessingImage->imageData[nHeight*pProcessingImage->widthStep + nWidth*CHANNEL3 + BLUE]	= colorRGB.chColorB;
}




ColorRGB Lighten(IplImage *pImage, int nHeight, int nWidth, unsigned char chLightenLevel)
{
	unsigned char chColor[3];
	ColorRGB colorTemp;

	for(int nColor = 0; nColor < CHANNEL3; nColor++)
	{
		chColor[nColor] = pImage->imageData[nHeight*pImage->widthStep + nWidth*CHANNEL3 + nColor];

		if(chColor[nColor] >= 255 - chLightenLevel)
		{
			chColor[nColor] = 255;
		}
		else
		{
			chColor[nColor] += chLightenLevel;
		}
	}

	colorTemp.chColorR = chColor[RED];
	colorTemp.chColorG = chColor[GREEN];
	colorTemp.chColorB = chColor[BLUE];

	return colorTemp;
}

ColorRGB Darken(IplImage *pImage, int nHeight, int nWidth, unsigned char chDarkenLevel)
{
	unsigned char chColor[3];
	ColorRGB colorTemp;

	for(int nColor = 0; nColor < CHANNEL3; nColor++)
	{
		chColor[nColor] = pImage->imageData[nHeight*pImage->widthStep + nWidth*CHANNEL3 + nColor];

		if(chColor[nColor] <= chDarkenLevel)
		{
			chColor[nColor] = 0;
		}
		else
		{
			chColor[nColor] -= chDarkenLevel;
		}
	}

	colorTemp.chColorR = chColor[RED];
	colorTemp.chColorG = chColor[GREEN];
	colorTemp.chColorB = chColor[BLUE];

	return colorTemp;
}