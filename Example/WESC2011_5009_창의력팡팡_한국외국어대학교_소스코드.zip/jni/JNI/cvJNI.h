#pragma once
#include <jni.h>
#include <AndroidLog.h>
#include<ImageProcess.h>
#include<AnimationProcess.h>
#ifndef _Included_MyOpenCV_JNI
#define _Included_MyOpenCV_JNI
#ifdef __cplusplus
extern "C" {
#endif

	JNIEXPORT void JNICALL Java_test_primium_JNIMethods_cvSketchEffect1(JNIEnv *env, jobject thiz,jintArray image,jint width,jint height);
	JNIEXPORT void JNICALL Java_test_primium_JNIMethods_cvSketchEffect2(JNIEnv *env, jobject thiz,jintArray image,jint width,jint height);
	JNIEXPORT void JNICALL Java_test_primium_JNIMethods_cvGrayEffect(JNIEnv *env, jobject thiz,jintArray image,jint width,jint height);
	JNIEXPORT void JNICALL Java_test_primium_JNIMethods_cvOilPaintEffect(JNIEnv *env, jobject thiz,jintArray image,jint width,jint height,jint nRadius, jint nDifferentIntensity);
	JNIEXPORT void JNICALL Java_test_primium_JNIMethods_cvWaterColorEffect(JNIEnv *env, jobject thiz,jintArray image,jint width,jint height);

	JNIEXPORT void JNICALL Java_test_primium_JNIMethods_cvRainDropEffect(JNIEnv *env, jobject thiz,jintArray image,jint width,jint height ,jint xPoint, jint yPoint);
	JNIEXPORT void JNICALL Java_test_primium_JNIMethods_cvLightEffect(JNIEnv *env, jobject thiz,jintArray image,jint width,jint height ,jint xPoint, jint yPoint);
	JNIEXPORT void JNICALL Java_test_primium_JNIMethods_cvFisheyeEffect(JNIEnv *env, jobject thiz,jintArray image,jint width,jint height ,jint xPoint, jint yPoint);
	

	ImageProcess m_ImageProcess;	
	AnimationProcess m_AnimationProcess;
#ifdef __cplusplus
}
#endif
#endif