#pragma once
#include <cv.h>
#include <cxcore.h>
#include <cvaux.h>
#include <highgui.h>
#include <ml.h>
#include <AndroidLog.h>
#include <cmath>
#include<ctime>

#define max(a,b) (((a) > (b)) ? (a) : (b))
#define min(a,b) (((a) < (b)) ? (a) : (b))

enum COLOR {BLUE, GREEN, RED};
enum CHANNEL {CHANNEL1 = 1, CHANNEL2, CHANNEL3};
typedef struct _ColorRGB
{
	unsigned char chColorR;
	unsigned char chColorG;
	unsigned char chColorB;
}
ColorRGB;

class AnimationProcess
{
public:
	AnimationProcess(void);
	~AnimationProcess(void);
	void RainDropEffect(int* ImageArray,int width,int height,int xPoint,int yPoint);
	void LightEffect(int* ImageArray,int width,int height,int xPoint, int yPoint);
	void FisheyeEffect(int* ImageArray,int width,int height,int xPoint, int yPoint);
private:
		char* temp_Image;
};