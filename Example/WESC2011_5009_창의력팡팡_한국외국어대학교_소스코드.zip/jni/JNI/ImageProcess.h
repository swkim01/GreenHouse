#pragma once
#pragma once
#include <cv.h>
#include <cxcore.h>
#include <cvaux.h>
#include <highgui.h>
#include <ml.h>
#include <AndroidLog.h>
#include <cmath>
#include<ctime>



class ImageProcess
{
public:
	ImageProcess(void);
	~ImageProcess(void);
	void SketchEffect1(int* ImageArray,int width, int height);
	void SketchEffect2(int* ImageArray,int width, int height);
	void GrayEffect(int* ImageArray,int width, int height);
	void OilPaintEffect(int* ImageArray,int width, int height,int nRadius, int nDifferentIntensity);
	void WaterColorEffect(int* ImageArray,int width, int height);

	unsigned char** SymmetricExtension(unsigned char** ppReadImage, int const &nImgHeight, int const &nImgWidth, float** ppFilter, int const &nFilterHeight, int const &nFilterWidth);
	unsigned char** JPGToRAW(IplImage* pIplImage);
	IplImage* RAWToJPG(unsigned char** ppImage, int nHeight, int nWidth);
	//ColorRGB MostFrequentColor(IplImage *pOriginalImage, int nCurHeight, int nCurWidth, int nRadius, int nDifferentIntensity);


	// curvature = [1, 1000]
	//void FishEyeEffect(int* ImageArray, int width, int height, int curvature, bool inverseFishEye);

private:
	char* temp_Image;

};
