/** Automatically generated file. DO NOT MODIFY */
package app.eth.mytestdialog;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}