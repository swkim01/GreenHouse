package deu.sw.greenhouse.ar;

public interface IGLPlane {
	public void registerComponent(InfoCircle circle);
}
